// Per-blur state shared by every level's draw: one draw per level, so it
// lives in push constants rather than in each quad. A mask without alpha
// samples as opaque through its view's swizzle.

#include "bindless.glsl"

const uint MASK_ENABLED = 1u;
const uint MASK_LINEAR = 2u;
// The first level is a quarter of the target: each tap averages the 4x4 pixels a texel
// covers, where one bilinear sample would skip half of them and alias into blocks.
const uint PREFILTER = 4u;

layout(push_constant) uniform Push {
    vec2 ndc_scale;       // quad.vert's
    vec2 pixel;           // one source texel in uv
    vec2 blur_max;        // uv extent of the source level
    float radius;
    float passes;
    float contrast;
    float vibrancy;
    float vibrancy_darkness;
    float brightness;
    float noise;
    float mask_alpha;
    float mask_threshold;
    uint mask_transform;  // api.Transform tag
    vec4 mask_src;        // uv box in the mask texture
    vec4 mask_dst;        // target box the mask maps onto
    uint source;          // bindless images
    uint mask;
    uint flags;           // MASK_*
} push;

vec4 sampleBlur(vec2 uv) {
    return texture(sampler2D(images[push.source], samplers[1]), clamp(uv, push.pixel * 0.5, push.blur_max - push.pixel * 0.5));
}
