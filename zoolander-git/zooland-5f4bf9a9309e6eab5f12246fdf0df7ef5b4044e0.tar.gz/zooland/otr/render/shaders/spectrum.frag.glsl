#version 460
// Levels drawn outward from the outline of a rounded box; spectrum.otr is the
// same maths on the CPU and documents the shapes. Change both together.
// p0, p1: premultiplied inner and outer colours; p2, p3: the 24 levels, three
// 8-bit ones to a float as v0 + 256 v1 + 65536 v2; clip_box: the box;
// misc: corner radius, corner power, reach, phase;
// idx.x: shape | mirror << 8 | fill (8 bits) << 16 | segment << 24;
// idx.y: the bits of the period, a whole number of which fit the perimeter.
// The pass clip only cuts the geometry, so CLIP is never set.
#include "common.glsl"
#include "color.glsl"

layout(location = 0) out vec4 outColor;

// SpectrumShape, in its order; the last, line, is what remains.
const uint BARS = 0u;
const uint WAVE = 1u;
const uint GLOW = 2u;
const float TAU = 6.2831855;
const float QUARTER_TURN = 1.5707964;

float levelValue(Quad q, uint i) {
    uint word = i / 3u;
    float triple = word < 4u ? q.p2[word] : q.p3[word - 4u];
    return float((uint(triple) >> (8u * (i % 3u))) & 255u) / 255.0;
}

// Value i sits at (i + 0.5) / 24; smoothstep between neighbours.
float levelAt(Quad q, float u) {
    float x = clamp(u * 24.0 - 0.5, 0.0, 23.0);
    uint i = uint(x);
    float f = x - float(i);
    return mix(levelValue(q, i), levelValue(q, min(i + 1u, 23u)), f * f * (3.0 - 2.0 * f));
}

// Pixels along the outline, clockwise from the left end of the top straight
// edge, of the outline point nearest `d` (relative to the box centre). A
// corner is its angle times the radius, whatever the corner power.
float perimeterAt(vec2 d, vec2 straight, float radius) {
    vec2 q = abs(d) - straight;
    float quarter = QUARTER_TURN * radius;
    float a = straight.x;
    float b = straight.y;
    if (q.x > 0.0 && q.y > 0.0) {
        float arc = radius * ((d.x > 0.0) == (d.y < 0.0) ? atan(q.x, q.y) : atan(q.y, q.x));
        if (d.y < 0.0) return d.x > 0.0 ? 2.0 * a + arc : 4.0 * a + 4.0 * b + 3.0 * quarter + arc;
        return d.x > 0.0 ? 2.0 * a + 2.0 * b + quarter + arc : 4.0 * a + 2.0 * b + 2.0 * quarter + arc;
    }
    if (q.y > q.x) return d.y < 0.0 ? d.x + a : 3.0 * a + 2.0 * b + 2.0 * quarter - d.x;
    return d.x > 0.0 ? 2.0 * a + quarter + b + d.y : 4.0 * a + 3.0 * b + 3.0 * quarter - d.y;
}

float sinTurns(float turns) {
    return sin(TAU * fract(turns));
}

void main() {
    Quad q = flatQuad();
    float reach = q.misc.z;
    float e = roundedBoxDistance(gl_FragCoord.xy, q.clip_box, q.misc.x, q.misc.y);
    if (e <= -0.5 || e >= reach) discard;
    float outside = max(e, 0.0);
    vec2 halfSize = q.clip_box.zw * 0.5;
    vec2 straight = halfSize - vec2(q.misc.x);
    float perimeter = 4.0 * (straight.x + straight.y) + TAU * q.misc.x;
    float along = perimeterAt(gl_FragCoord.xy - (q.clip_box.xy + halfSize), straight, q.misc.x);
    uint shape = q.idx.x & 255u;
    bool mirror = (q.idx.x >> 8 & 1u) != 0u;
    float fill = float(q.idx.x >> 16 & 255u) / 255.0;
    float segment = float(q.idx.x >> 24);
    float phase = q.misc.w;
    float cells = max(round(perimeter / uintBitsToFloat(q.idx.y)), 1.0);
    // Where the level is read: the bar's centre for bars, the pixel otherwise.
    float period = perimeter / cells;
    float cell = floor((along + phase) / period);
    float probe = shape == BARS ? (cell + 0.5) * period - phase : along;
    float u = mirror ? abs(2.0 * fract((probe - straight.x) / perimeter) - 1.0) : fract(probe / perimeter);
    float level = levelAt(q, u);
    float lit = 0.0;
    float blend = level;
    if (shape == BARS) {
        float local = ((along + phase) / period - cell) * period;
        float width = fill * period;
        lit = max(clamp(width * 0.5 - abs(local - period * 0.5) + 0.5, 0.0, 1.0), 1.0 - (period - width));
        float h = level * reach;
        if (segment > 0.0) {
            h = floor(h / segment) * segment;
            float t = outside - floor(outside / segment) * segment;
            lit *= clamp(min(t, segment * (2.0 / 3.0) - t) + 0.5, 0.0, 1.0);
        }
        lit *= clamp(h - outside + 0.5, 0.0, 1.0) * min(h, 1.0);
        blend = outside / reach;
    } else if (shape == WAVE) {
        float ripple = 0.5 + 0.25 * sinTurns(cells * (along + phase) / perimeter) +
            0.25 * sinTurns(round(cells / 0.43) * (along - 1.25 * phase) / perimeter);
        float h = level * reach * ripple;
        if (h > outside) {
            lit = clamp((1.0 - outside / h) / max(1.0 - fill, 1.0 / h), 0.0, 1.0);
            blend = outside / h;
        }
    } else if (shape == GLOW) {
        float f = clamp(1.0 - outside / (reach * (0.25 + 0.75 * level)), 0.0, 1.0);
        lit = f * f * (f + (1.0 - f) * fill) * level * (2.0 - level);
    } else {
        float at = (0.12 + 0.76 * level) * reach;
        float under = outside < at ? 0.18 * (1.0 - outside / at) : 0.0;
        lit = max(clamp(max(0.75, fill * 3.0) - abs(outside - at) + 0.5, 0.0, 1.0), under) * min(level * 8.0, 1.0);
    }
    lit *= min(e + 0.5, 1.0);
    if (!(lit > 0.0)) discard;
    vec4 c = mix(q.p0, q.p1, clamp(blend, 0.0, 1.0)) * lit;
    if (CONVERT) c = convertColor(c, q.idx.z);
    outColor = c;
}
