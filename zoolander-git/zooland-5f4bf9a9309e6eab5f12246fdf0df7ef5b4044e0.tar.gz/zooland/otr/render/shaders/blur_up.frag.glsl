#version 460
// One dual-Kawase upsample. FINISH is the last level, drawn into the
// target: mask test, brightness and noise, and the clip with CLIP.
#extension GL_EXT_nonuniform_qualifier : require
#include "common.glsl"
#include "blur.glsl"

layout(constant_id = 4) const bool FINISH = false;

layout(location = 0) in vec2 vUV;
layout(location = 0) out vec4 outColor;

// `q` (0..1 across the mask's target box) to mask uv under `transform`.
vec2 maskCoord(vec2 q, uint transform) {
    switch (transform) {
        case 1u: return vec2(1.0 - q.y, q.x);
        case 2u: return vec2(1.0 - q.x, 1.0 - q.y);
        case 3u: return vec2(q.y, 1.0 - q.x);
        case 4u: return vec2(1.0 - q.x, q.y);
        case 5u: return vec2(q.y, q.x);
        case 6u: return vec2(q.x, 1.0 - q.y);
        case 7u: return vec2(1.0 - q.y, 1.0 - q.x);
        default: return q;
    }
}

void main() {
    float coverage = 1.0;
    if (CLIP) {
        coverage = clipCoverage(flatQuad(), gl_FragCoord.xy);
        if (coverage <= 0.0) discard;
    }
    // The dual filter's upsample taps half a source texel per unit of
    // radius along the axes and a quarter on the diagonals. Wider taps
    // leave unsampled texels between them and the kernel turns into a
    // blocky ring.
    vec2 o = push.pixel * push.radius * 0.25;
    vec4 c = sampleBlur(vUV + vec2(-2.0 * o.x, 0.0));
    c += sampleBlur(vUV + vec2(-o.x, o.y)) * 2.0;
    c += sampleBlur(vUV + vec2(0.0, 2.0 * o.y));
    c += sampleBlur(vUV + vec2(o.x, o.y)) * 2.0;
    c += sampleBlur(vUV + vec2(2.0 * o.x, 0.0));
    c += sampleBlur(vUV + vec2(o.x, -o.y)) * 2.0;
    c += sampleBlur(vUV + vec2(0.0, -2.0 * o.y));
    c += sampleBlur(vUV + vec2(-o.x, -o.y)) * 2.0;
    c /= 12.0;
    if (FINISH) {
        if ((push.flags & MASK_ENABLED) != 0u) {
            vec2 st = maskCoord((gl_FragCoord.xy - push.mask_dst.xy) / push.mask_dst.zw, push.mask_transform);
            vec4 m = texture(sampler2D(images[push.mask], samplers[(push.flags & MASK_LINEAR) != 0u ? 1 : 0]), push.mask_src.xy + st * push.mask_src.zw);
            if (m.a * push.mask_alpha <= push.mask_threshold) discard;
        }
        float n = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
        c.rgb = c.rgb * push.brightness + vec3(n * push.noise);
    }
    outColor = vec4(clamp(c.rgb, vec3(0.0), vec3(c.a)), c.a) * coverage;
}
