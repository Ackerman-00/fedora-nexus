// Colour conversion from a source encoding to the target's, mirroring
// color.otr. One table entry per distinct conversion in the frame; quads
// name theirs by index.

// Transfers as color.otr's `Transfer` tags.
const uint TRANSFER_BT1886 = 0u;
const uint TRANSFER_PQ = 1u;
const uint TRANSFER_HLG = 2u;
const uint TRANSFER_POWER = 3u;
const uint TRANSFER_SRGB = 4u;
const uint TRANSFER_LINEAR = 5u;
const uint TRANSFER_ST240 = 6u;
const uint TRANSFER_LOG100 = 7u;
const uint TRANSFER_LOG316 = 8u;
const uint TRANSFER_XVYCC = 9u;
const uint TRANSFER_ST428 = 10u;

// color.otr's decode_relative/encode_relative constants.
const float LN10 = 2.302585092994046;
const float ST240_ALPHA = 1.1115;
const float ST240_BETA = 0.0228;
const float BT709_ALPHA = 1.099296826809442;
const float BT709_BETA = 0.018053968510807;
const float LOG316_FLOOR = 0.0031622776601683794;
const float ST428_SCALE = 52.37 / 48.0;

struct Conversion {
    uvec4 transfer; // input, output
    vec4 src;       // reference, maximum, power
    vec4 dst;       // reference, maximum, power, SDR black
    vec4 sdr;       // brightness, saturation, black luminance
    vec4 row0;      // linear source RGB to output primaries, row-major
    vec4 row1;
    vec4 row2;
    vec4 tonemap;   // source peak, target peak, knee; off unless source > target
    vec4 luma;      // linear output RGB to luminance
};

layout(std430, set = 1, binding = 1) readonly buffer Conversions { Conversion conversions[]; };

const float pqM1 = 2610.0 / 16384.0;
const float pqM2 = 2523.0 / 32.0;
const float pqC1 = 3424.0 / 4096.0;
const float pqC2 = 2413.0 / 128.0;
const float pqC3 = 2392.0 / 128.0;

float decodeChannel(float v, Conversion c) {
    uint t = c.transfer.x;
    if (t == TRANSFER_LINEAR) return v * c.src.x;
    if (t == TRANSFER_XVYCC) {
        float m = abs(v);
        float light = m < 4.5 * BT709_BETA ? m / 4.5 : pow((m + BT709_ALPHA - 1.0) / BT709_ALPHA, 1.0 / 0.45);
        return sign(v) * light * c.src.x;
    }
    v = clamp(v, 0.0, 1.0);
    if (t == TRANSFER_BT1886) return pow(v, 2.4) * c.src.x;
    if (t == TRANSFER_PQ) {
        float p = pow(v, 1.0 / pqM2);
        return pow(max((p - pqC1) / max(pqC2 - pqC3 * p, 0.000001), 0.0), 1.0 / pqM1) * 10000.0;
    }
    if (t == TRANSFER_HLG) {
        float scene = v <= 0.5 ? v * v / 3.0 : (exp((v - 0.55991073) / 0.17883277) + 0.28466892) / 12.0;
        return scene * c.src.y;
    }
    if (t == TRANSFER_POWER) return pow(v, c.src.z) * c.src.x;
    if (t == TRANSFER_SRGB) return (v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4)) * c.src.x;
    if (t == TRANSFER_ST240) return (v < 4.0 * ST240_BETA ? v / 4.0 : pow((v + ST240_ALPHA - 1.0) / ST240_ALPHA, 1.0 / 0.45)) * c.src.x;
    if (t == TRANSFER_LOG100) return v <= 0.0 ? 0.0 : exp((v - 1.0) * 2.0 * LN10) * c.src.x;
    if (t == TRANSFER_LOG316) return v <= 0.0 ? 0.0 : exp((v - 1.0) * 2.5 * LN10) * c.src.x;
    if (t == TRANSFER_ST428) return pow(v, 2.6) * ST428_SCALE * c.src.x;
    return 0.0;
}

float encodeChannel(float v, Conversion c) {
    uint t = c.transfer.y;
    if (t == TRANSFER_PQ) {
        float p = pow(clamp(v, 0.0, 10000.0) / 10000.0, pqM1);
        return pow((pqC1 + pqC2 * p) / (1.0 + pqC3 * p), pqM2);
    }
    if (t == TRANSFER_HLG) {
        float scene = clamp(v / c.dst.y, 0.0, 1.0);
        return scene <= 1.0 / 12.0 ? sqrt(3.0 * scene) : 0.17883277 * log(12.0 * scene - 0.28466892) + 0.55991073;
    }
    if (t == TRANSFER_LINEAR) return clamp(v, -10000.0, 10000.0) / c.dst.x;
    float relative = (v - c.dst.w) / (c.dst.x - c.dst.w);
    if (t == TRANSFER_XVYCC) {
        float m = abs(relative);
        return sign(relative) * (m < BT709_BETA ? 4.5 * m : BT709_ALPHA * pow(m, 0.45) - (BT709_ALPHA - 1.0));
    }
    if (t == TRANSFER_ST428) return pow(clamp(relative, 0.0, ST428_SCALE) / ST428_SCALE, 1.0 / 2.6);
    float linear = clamp(relative, 0.0, 1.0);
    if (t == TRANSFER_ST240) return linear < ST240_BETA ? 4.0 * linear : ST240_ALPHA * pow(linear, 0.45) - (ST240_ALPHA - 1.0);
    if (t == TRANSFER_LOG100) return linear < 0.01 ? 0.0 : 1.0 + log(linear) / LN10 / 2.0;
    if (t == TRANSFER_LOG316) return linear < LOG316_FLOOR ? 0.0 : 1.0 + log(linear) / LN10 / 2.5;
    if (t == TRANSFER_BT1886) return pow(linear, 1.0 / 2.4);
    if (t == TRANSFER_POWER) return pow(linear, 1.0 / c.dst.z);
    if (t == TRANSFER_SRGB) return linear <= 0.0031308 ? linear * 12.92 : 1.055 * pow(linear, 1.0 / 2.4) - 0.055;
    return 0.0;
}

bool isHdr(uint t) {
    return t == TRANSFER_PQ || t == TRANSFER_HLG || t == TRANSFER_LINEAR;
}

vec4 convertColor(vec4 premul, uint index) {
    if (premul.a <= 0.0) return vec4(0.0);
    Conversion c = conversions[index];
    // Extended linear and xvYCC codes outside 0..1 are colours; decodeChannel clamps every other transfer.
    vec3 straight = premul.rgb / premul.a;
    vec3 rgb = vec3(decodeChannel(straight.r, c), decodeChannel(straight.g, c), decodeChannel(straight.b, c));
    bool sdrOnHdr = !isHdr(c.transfer.x) && isHdr(c.transfer.y);
    // Lifting black keeps reference white in place: nits = black + (white - black) * linear.
    if (sdrOnHdr) rgb = vec3(c.sdr.z) + rgb * (1.0 - c.sdr.z / c.src.x);
    rgb = vec3(dot(c.row0.xyz, rgb), dot(c.row1.xyz, rgb), dot(c.row2.xyz, rgb));
    if (sdrOnHdr) {
        float luma = max(dot(rgb, vec3(0.2627, 0.6780, 0.0593)), 0.0);
        rgb = (vec3(luma) + (rgb - vec3(luma)) * c.sdr.y) * c.sdr.x;
    }
    // color.otr's tone_map: Hyprland's extended Reinhard over the excess above the knee. Colours outside
    // the output's primaries move toward their own grey until they fit; ones over its peak dim until they do.
    if (c.tonemap.x > c.tonemap.y) {
        float luminance = max(dot(rgb, c.luma.rgb), 0.0);
        float lowest = min(rgb.r, min(rgb.g, rgb.b));
        if (lowest < 0.0) {
            float toward = luminance > 0.0 ? luminance / (luminance - lowest) : 0.0;
            rgb = vec3(luminance) + (rgb - vec3(luminance)) * toward;
        }
        float scale = 1.0;
        if (luminance > c.tonemap.z) {
            float headroom = c.tonemap.y - c.tonemap.z;
            float s = (c.tonemap.x - c.tonemap.z) / headroom;
            float r = (min(luminance, c.tonemap.x) - c.tonemap.z) / headroom;
            scale = (c.tonemap.z + headroom * r * (1.0 + r / (s * s)) / (1.0 + r)) / luminance;
        }
        float highest = max(rgb.r, max(rgb.g, rgb.b)) * scale;
        if (highest > c.tonemap.y) scale *= c.tonemap.y / highest;
        rgb *= scale;
        rgb = min(rgb, vec3(c.tonemap.y));
    }
    return vec4(encodeChannel(rgb.r, c), encodeChannel(rgb.g, c), encodeChannel(rgb.b, c), 1.0) * premul.a;
}
