#version 460
// One dual-Kawase downsample. PREP is the first level, which applies the
// contrast.
#extension GL_EXT_nonuniform_qualifier : require
#include "common.glsl"
#include "blur.glsl"

layout(constant_id = 3) const bool PREP = false;

layout(location = 0) in vec2 vUV;
layout(location = 0) out vec4 outColor;

vec4 tap(vec2 uv) {
    if ((push.flags & PREFILTER) == 0u) {
        return sampleBlur(uv);
    }
    vec2 p = push.pixel;
    return 0.25 * (sampleBlur(uv - p) + sampleBlur(uv + vec2(p.x, -p.y)) + sampleBlur(uv + vec2(-p.x, p.y)) + sampleBlur(uv + p));
}

void main() {
    vec2 o = push.pixel * push.radius;
    vec4 c = tap(vUV) * 4.0;
    c += tap(vUV + vec2(-o.x, -o.y));
    c += tap(vUV + vec2(o.x, -o.y));
    c += tap(vUV + vec2(-o.x, o.y));
    c += tap(vUV + vec2(o.x, o.y));
    c *= 0.125;
    // Contrast as a gain curve, 0.5·(2x)^k mirrored about the midpoint: a
    // straight line through 0.5 clips every dark pixel to black once k > 1.
    if (PREP && push.contrast != 1.0) {
        vec3 x = clamp(c.rgb / max(c.a, 1e-6), 0.0, 1.0);
        vec3 upper = step(0.5, x);
        vec3 g = 0.5 * pow(max(2.0 * mix(x, 1.0 - x, upper), 1e-6), vec3(push.contrast));
        c.rgb = mix(g, 1.0 - g, upper) * c.a;
    }
    // Rec. 601 luma.
    float luma = dot(c.rgb, vec3(0.299, 0.587, 0.114));
    float boost = push.vibrancy * (1.0 - push.vibrancy_darkness * (1.0 - clamp(luma, 0.0, 1.0))) / max(push.passes, 1.0);
    c.rgb += (c.rgb - vec3(luma)) * boost;
    outColor = vec4(clamp(c.rgb, vec3(0.0), vec3(c.a)), c.a);
}
