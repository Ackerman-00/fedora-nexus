#!/bin/sh
# Lavapipe only, never a real GPU: bwrap gives each test file a fresh /dev without GPU nodes
# and an environment in which the loader sees lvp and no layer; lvp.run refuses any other.
set -eu
cd "$(dirname "$0")/../tests"
otr=$(command -v otr)
status=0
all="render/vk_lvp_test.otr render/vk_resource_lvp_test.otr render/vk_render_lvp_test.otr render/vk_pass_lvp_test.otr render/vk_pipeline_lvp_test.otr render/vk_blur_lvp_test.otr"
for file in ${*:-$all}; do
    bwrap --dev-bind / / --dev /dev --proc /proc --unshare-pid --unshare-net --unshare-ipc --die-with-parent \
        --clearenv --setenv PATH "$PATH" --setenv HOME "$HOME" \
        --setenv VK_DRIVER_FILES /usr/share/vulkan/icd.d/lvp_icd.json --setenv VK_LOADER_LAYERS_DISABLE '~all~' \
        --setenv NODEVICE_SELECT 1 --setenv MESA_SHADER_CACHE_DISABLE true \
        "$otr" test "$file" || status=1
done
exit $status
