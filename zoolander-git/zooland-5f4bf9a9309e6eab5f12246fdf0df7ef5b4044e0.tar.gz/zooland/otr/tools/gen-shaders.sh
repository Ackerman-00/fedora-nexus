#!/bin/sh
# Rebuilds otr/render/shaders/spv/ from the GLSL with glslc and spirv-val, the manifest of
# what they were built from, and otr/render/shaders/generated/, the SPIR-V as otr word
# arrays. `--modules <dir>` only writes the word arrays of the checked-in SPIR-V to <dir>.
set -eu
export LC_ALL=C
shaders=$(cd "$(dirname "$0")/../render/shaders" && pwd)
cd "$shaders"

# <name> <source> <stage> [defines]: spv/<name>.spv, and generated/<name with _ for .>.otr.
programs='quad.vert quad.vert.glsl vert
solid.frag solid.frag.glsl frag
gradient.frag gradient.frag.glsl frag
shadow.frag shadow.frag.glsl frag
spectrum.frag spectrum.frag.glsl frag
texture.frag texture.frag.glsl frag
texture_ycbcr.frag texture.frag.glsl frag -DYCBCR
blur_down.frag blur_down.frag.glsl frag
blur_up.frag blur_up.frag.glsl frag'

write_modules() {
    mkdir -p "$1"
    echo "$programs" | while read -r name _; do
        od -An -v -tx4 -w4 "spv/$name.spv" | awk '{ w[NR] = $1 } END {
            printf "pub const words = [%d]u32{\n", NR
            for (i = 1; i <= NR; i++) {
                printf "%s0x%s,%s", (i % 12 == 1 ? "    " : " "), w[i], (i % 12 == 0 || i == NR ? "\n" : "")
            }
            print "}"
        }' > "$1/$(echo "$name" | tr . _).otr"
    done
}

if [ "${1:-}" = --modules ]; then
    write_modules "$2"
    exit
fi

echo "$programs" | while read -r name source stage defines; do
    glslc --target-env=vulkan1.3 -O "-fshader-stage=$stage" $defines "$source" -o "spv/$name.spv"
    spirv-val --target-env vulkan1.3 "spv/$name.spv"
done
# Sources by name, this script among them since it holds the program table, then each
# module, so committing GLSL without its rebuilt SPIR-V shows too.
{
    sha256sum ./*.glsl ../../tools/gen-shaders.sh | sed 's|  \./|  |'
    echo "$programs" | while read -r name _; do
        sha256sum "spv/$name.spv"
    done
} > manifest.txt
rm -rf generated
write_modules generated
