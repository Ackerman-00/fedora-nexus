#!/bin/sh
# Regenerates the protocol bindings, otr/protocols/generated.otr and otr/protocols/generated/,
# from the XML in protocols/, the caps in docs/interface-versions.tsv and the enum-arg errors in
# docs/enum-errors.tsv; with a directory argument, writes them there instead.
set -eu
repo=$(cd "$(dirname "$0")/../.." && pwd)
out=$(mkdir -p "${1:-$repo/otr/protocols}" && cd "${1:-$repo/otr/protocols}" && pwd)
cd "$repo"
rm -rf "$out/generated" "$out/generated.otr"
# The XML order sets the interface indices (wl_display is 126).
otr run otr/tools/scanner/scanner.otr -- \
    docs/interface-versions.tsv \
    docs/enum-errors.tsv \
    "$out/generated.otr" \
    protocols/alpha-modifier-v1.xml \
    protocols/appmenu.xml \
    protocols/color-management-v1.xml \
    protocols/color-representation-v1.xml \
    protocols/commit-timing-v1.xml \
    protocols/content-type-v1.xml \
    protocols/cursor-shape-v1.xml \
    protocols/drm-lease-v1.xml \
    protocols/ext-data-control-v1.xml \
    protocols/ext-background-effect-v1.xml \
    protocols/ext-image-capture-source-v1.xml \
    protocols/ext-image-copy-capture-v1.xml \
    protocols/ext-foreign-toplevel-list-v1.xml \
    protocols/ext-idle-notify-v1.xml \
    protocols/ext-session-lock-v1.xml \
    protocols/ext-transient-seat-v1.xml \
    protocols/ext-workspace-v1.xml \
    protocols/fifo-v1.xml \
    protocols/fractional-scale-v1.xml \
    protocols/frog-color-management-v1.xml \
    protocols/gtk-shell.xml \
    protocols/hyprland-global-shortcuts-v1.xml \
    protocols/hyprland-toplevel-mapping-v1.xml \
    protocols/hyprland-workspace-image-capture-source-v1.xml \
    protocols/idle-inhibit-unstable-v1.xml \
    protocols/input-method-unstable-v1.xml \
    protocols/input-method-unstable-v2.xml \
    protocols/input-timestamps-unstable-v1.xml \
    protocols/keyboard-shortcuts-inhibit-unstable-v1.xml \
    protocols/linux-dmabuf-v1.xml \
    protocols/linux-drm-syncobj-v1.xml \
    protocols/pointer-constraints-unstable-v1.xml \
    protocols/pointer-gestures-unstable-v1.xml \
    protocols/pointer-warp-v1.xml \
    protocols/presentation-time.xml \
    protocols/primary-selection-unstable-v1.xml \
    protocols/relative-pointer-unstable-v1.xml \
    protocols/security-context-v1.xml \
    protocols/server-decoration.xml \
    protocols/single-pixel-buffer-v1.xml \
    protocols/tablet-v2.xml \
    protocols/tearing-control-v1.xml \
    protocols/text-input-unstable-v1.xml \
    protocols/text-input-unstable-v2.xml \
    protocols/text-input-unstable-v3.xml \
    protocols/viewporter.xml \
    protocols/virtual-keyboard-unstable-v1.xml \
    protocols/wayland-drm.xml \
    protocols/wayland.xml \
    protocols/wlr-data-control-unstable-v1.xml \
    protocols/wlr-export-dmabuf-unstable-v1.xml \
    protocols/wlr-foreign-toplevel-management-unstable-v1.xml \
    protocols/wlr-gamma-control-unstable-v1.xml \
    protocols/wlr-layer-shell-unstable-v1.xml \
    protocols/wlr-output-management-unstable-v1.xml \
    protocols/wlr-output-power-management-unstable-v1.xml \
    protocols/wlr-screencopy-unstable-v1.xml \
    protocols/wlr-virtual-pointer-unstable-v1.xml \
    protocols/xdg-activation-v1.xml \
    protocols/xdg-decoration-unstable-v1.xml \
    protocols/xdg-dialog-v1.xml \
    protocols/xdg-foreign-unstable-v1.xml \
    protocols/xdg-foreign-unstable-v2.xml \
    protocols/xdg-output-unstable-v1.xml \
    protocols/xdg-session-management-v1.xml \
    protocols/xdg-shell.xml \
    protocols/xdg-system-bell-v1.xml \
    protocols/xdg-toplevel-drag-v1.xml \
    protocols/xdg-toplevel-icon-v1.xml \
    protocols/xdg-toplevel-tag-v1.xml \
    protocols/xwayland-shell-v1.xml \
    protocols/zoolander-image-copy-capture-size-v1.xml \
    protocols/zoolander-xwayland-bypass-v1.xml
