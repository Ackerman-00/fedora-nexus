#!/bin/sh
# Fails when the checked-in generated code is stale: the protocol bindings differ from what
# the scanner writes now, the GLSL or SPIR-V differ from the shader manifest, or the
# shader word arrays differ from the SPIR-V.
set -eu
otr_dir=$(cd "$(dirname "$0")/.." && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
"$otr_dir/tools/gen-protocols.sh" "$tmp/protocols"
otr fmt --check "$tmp/protocols/generated.otr" "$tmp"/protocols/generated/*.otr
diff -r "$tmp/protocols/generated" "$otr_dir/protocols/generated"
diff "$tmp/protocols/generated.otr" "$otr_dir/protocols/generated.otr"
(cd "$otr_dir/render/shaders" && sha256sum --quiet -c manifest.txt)
test "$(wc -l < "$otr_dir/render/shaders/manifest.txt")" -eq "$(($(ls "$otr_dir"/render/shaders/*.glsl | wc -l) + 1 + $(ls "$otr_dir"/render/shaders/spv/*.spv | wc -l)))"
"$otr_dir/tools/gen-shaders.sh" --modules "$tmp/shaders"
diff -r "$tmp/shaders" "$otr_dir/render/shaders/generated"
echo "generated code is current"
