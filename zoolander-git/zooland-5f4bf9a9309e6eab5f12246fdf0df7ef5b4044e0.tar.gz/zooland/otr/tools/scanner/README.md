# Wayland protocol scanner

Generates the server bindings in `otr/protocols/` (`generated.otr` and `generated/`) from the XML in `protocols/`. Version caps come from `docs/interface-versions.tsv`, and the protocol errors of out-of-range enum args from `docs/enum-errors.tsv`. `otr/protocols/wire/` is the hand-written wire runtime the bindings import; the scanner does not write it.

Regenerate with `otr/tools/gen-protocols.sh`, which lists the XML in the order that sets the interface indices. `otr/tools/check-generated.sh` regenerates into a temporary directory and fails when the committed bindings differ.
