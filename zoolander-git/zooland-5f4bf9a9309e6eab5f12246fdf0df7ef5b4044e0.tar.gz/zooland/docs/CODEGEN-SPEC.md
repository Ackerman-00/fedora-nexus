# Generated protocol bindings

The server bindings in `otr/protocols/` are generated from the vendored XML corpus in `protocols/` and checked in. They contain interface descriptors, typed request payloads and unions, request decoders, enum types, and event senders. The scanner that writes them lives in `otr/tools/scanner/`. `otr/tools/gen-protocols.sh` regenerates them with the XML in order, and `otr/tools/check-generated.sh` fails when the committed files are not current.

`otr/protocols/wire/` is the hand-written codec the bindings import. The scanner does not write it.

## Inputs

The scanner receives:

1. `docs/interface-versions.tsv`
2. `docs/enum-errors.tsv`
3. the output path `otr/protocols/generated.otr`
4. all 70 XML files in `protocols/`, in the order listed in `otr/tools/gen-protocols.sh`

The XML order sets the interface indices, so reordering it changes every generated file.

Each nonempty TSV row has four tab-separated columns:

```text
xml-file.xml    protocol_name    interface_name    advertised_version
```

The file and protocol columns must name the same input, and the interface must be defined in it. A row naming neither a file nor a protocol given is skipped. A cap must be a positive decimal no greater than the XML interface version, and an interface may be capped once. A cap becomes the generated `version` of that interface only. An interface absent from the TSV uses its XML version.

Each nonempty row of the enum-errors TSV has five tab-separated columns:

```text
interface_name    request_name    enum_arg_name    error_interface_name    error_entry_name
```

It names the protocol error a request posts when that enum arg holds a value outside its enum, which the XML does not say. Every name must exist, and an arg may have one row. The request's payload then declares `enum_errors`, one `?u32` per arg, which the decoder uses; see below.

## Files

The scanner writes:

- `generated/<protocol>.otr`, one module per XML file (`xdg-shell.xml` is `generated/xdg_shell.otr`) holding a namespace per interface. It imports only the protocol modules whose interfaces or enums its payloads name.
- `generated.otr`, which re-exports every interface by its XML name (`wl_surface`, `xdg_toplevel`, ...), maps interface indices to keys with `interface_key`, and resolves the interface of a message's object argument with `object_type(desc, arg)`

Library code imports the facade as `import protocols.generated`, and consumers as `import zooland.protocols.generated`.

## Generated interface shape

Each interface namespace contains:

- `name`, `version`, `id` (its index), and `key`, its `InterfaceKey`
- `requests` and `events`, the descriptor arrays
- one type per enum of the interface
- one payload type function per request, taking `Object` and `Created`; a request without arguments uses `decode.NoArgs`
- `Request(Object, Created)`, a union with one payload per request
- `decode_request_as(Object, Created, op, body, ctx)`
- one `send_<event>` function per event

An interface with no requests has a `Request` union with only `none`, and its decoder returns `UnknownOpcode`.

`InterfaceKey` is `&static Interface`, and interface identity is the descriptor's address, not its name or index. The facade reaches each interface as `generated.<name>`, so `generated.wl_surface.key` is the key the server compares resources against.

Protocol enums become exhaustive `enum (u32)` values: the decoder admits only the values they list, so switches over them need no `else` arm. Bitfields become `packed struct { bits: u32 }` with one constant per entry and `known_bits`, the union of the entries.

The decoder rejects a request whose enum arg holds no named value, or whose bitfield arg has a bit outside `known_bits`, so handlers only see values of the enum. The dispatcher posts the error the payload's `enum_errors` names for that arg on the target object, or `wl_display.invalid_method` when it names none. Whether a value is allowed at the object's version is the handler's to check.

Names that are Otr keywords or primitive type names get a trailing `_`, and names starting with a digit a leading one, as `transform._90`.

## Wire signatures

`MsgDesc.sig` uses one character per wire argument. Decoded payload fields have these types:

| Character | Wire value | Payload field |
|---|---|---|
| `i` | signed word | `i32` or enum |
| `u` | unsigned word | `u32`, enum, or bitfield |
| `f` | fixed point | `types.Fixed` |
| `s` | string | `[:0]u8` |
| `o` | object | `Object` |
| `n` | typed new id | `Created` |
| `N` | `wl_registry.bind` new id | `types.BindNewId` |
| `a` | byte array | `[]u8` |
| `h` | file descriptor | `linux.Fd` |

`?` may prefix only `s` or `o`, and makes the field optional. `protocols/wire/sig.otr` parses and checks signatures. `h` consumes an SCM_RIGHTS entry and no message-body bytes.

A message descriptor stores name, signature, minimum version, `deprecated_since`, destructor status, and the interface indices of typed object and new-id arguments. Each payload type also carries its `signature` and the `object_types` keys.

## Dispatch contract

`protocols/wire/dispatch.otr` runs a request against a generated interface: it checks the opcode bounds and the request's `since` against the target's version, decodes through `decode_request_as`, calls the handler, and on any error posts the protocol error and undoes pre-created objects.

The decoder checks argument framing, string NUL termination, zero new ids, trailing bytes, object identity and interface, zombie objects, and fd availability. It resolves `o` arguments, pre-creates `n` arguments, and pops fds through the client layer passed as `ctx`, which supplies `resolve_object`, `create_object`, `rollback_object`, `post_error`, and `pop_fd`.

Typed new ids are created before the handler runs. On a decode or handler error, dispatch rolls back only resources that remain unimplemented; rollback does not run a destroy hook. A resource the handler implemented before a later error stays live until the fatal client reap runs its normal destructor. The handler owns the decoded request, fds included, and consumes them on every path.

## Event senders

Each event gets a `send_<name>(w, target, ...)` function taking the event's arguments in order, named as in the XML (keywords and the names the sender uses get a trailing `_`). Arrays are `[]u8`, strings `str`, fds owned `linux.Fd`. Senders call `encode.send_owned_event` with the generated descriptor.

A sender returns without emitting when `target.version` is below the event's `since`. Events with `deprecated-since` also return when the version is at or above that version. A skipped or failed send still closes every fd argument.

A destructor event sender queues only the event. Its generated doc comment states that the caller retires the resource through normal teardown afterwards, so map retirement, `delete_id`, and object teardown happen in the normal order.
