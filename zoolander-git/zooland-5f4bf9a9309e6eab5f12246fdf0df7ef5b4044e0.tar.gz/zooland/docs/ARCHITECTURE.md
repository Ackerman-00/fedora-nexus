# zooland architecture

zooland is an Otr package for building a Wayland compositor. The library owns wire decoding, protocol objects, client lifetimes, and reusable renderer and backend interfaces. A compositor supplies policy through a typed `Backing` and hooks, and decides which globals to register.

## Package layers

The package root is `otr/`, and consumers import modules by path:

| Area | Entry | Responsibility |
|---|---|---|
| server | `server.otr`, `library.otr`, `shared_host.otr` | wire, event loop, server, protocol state, shells, seat, dmabuf, extensions |
| `render` | `render/api.otr` | renderer contract, software renderer, Vulkan renderer |
| `backend` | `backend/api.otr` | backend contract, headless, nested, DRM/KMS, libinput |

Generated protocol modules sit below the server. They are checked in under `otr/protocols/`, produced from the vendored XML and `docs/interface-versions.tsv` by the scanner in `otr/tools/scanner/`; see [`CODEGEN-SPEC.md`](CODEGEN-SPEC.md).

The public interface is Otr modules and types; there is no parallel C ABI.

## Ownership and shutdown

Everything is generic over a compositor-owned root struct. Its `server` field holds `Server(Root)`, its `event_loop` field `Loop(Root)`, and its `runtime` field the `Library(Host)` value whose stores own core, seat and shell, extension, and renderer state. Backends keep their pools in the root's `backend_state` field. Library calls take the root, or a short-lived `shared_host.Host` made from it with `init(root, client)` or `init_system(root)`; persistent state stores generational IDs, never the host.

The allocator passed to `Library.init`, `Loop.init` and `Server.init` owns their state. Pools may move their storage when they grow, so code copies what it needs out of a pool entry before calling a hook or growing a pool, and resolves the ID again afterwards. Client resources may refer to library stores by ID until the client teardown cascade finishes.

Shutdown must preserve these dependencies:

1. Stop backend, input, and other external callbacks.
2. Close compositor-owned objects that module teardown requires to be gone. Destroy clients early with `Server.destroy_client` when their teardown needs live backend handles.
3. Retire output, capture, backend, and renderer consumers that hold `Buffer` locks.
4. Call `Server.shutdown` while the library stores remain alive; it destroys remaining clients, runs resource destroy hooks, and closes the listener.
5. Call `Loop.shutdown`, which runs the deferred calls still queued, including calls appended while it runs, then deinitialize the server, loop, library, and backend state.

`Server.deinit` panics if `Server.shutdown` has not run. Zoolander's `otr/composition.otr` and `otr/comp_lifecycle.otr` show the full order.

## Event loop and server

`Loop` uses epoll, one timerfd, generational source and timer IDs, a timer heap, and a deferred-call queue. `tick(root, timeout_ms)` executes one bounded iteration; `run(root)` blocks until `quit()`. `add_timer` returns a `TimerId`, `defer_call` fails with `OutOfMemory` or `Closed`, and `valid` checks whether a source ID still names the same generation. Each tick runs source callbacks, due timers, deferred calls, the flush hook, and the reap hook, in that order. Deferred calls queued in source or timer callbacks run in the same tick, including calls appended while the deferred queue runs. Calls queued during the flush or reap hooks or outside a tick run on the next tick.

`Server.listen` creates a nonblocking Unix socket and lock file under an explicit runtime directory or `XDG_RUNTIME_DIR`. `.auto` tries `wayland-0` through `wayland-31`. One loop may own one server because the server installs the loop's flush and reap hooks. If accepting a connection fails for a reason other than `WouldBlock`, the listener stops reading and retries after `accept_retry_ms`, or as soon as a dead client is reaped.

Each tick reads and dispatches bounded client input, runs timers and deferred work, flushes clients, reaps dead clients, and resets the server scratch arena.

`Server.add_client` adopts a connected fd and creates the implicit `wl_display@1`. Protocol errors kill only that client. Teardown walks client resources newest first, which lets dependent child objects disappear before older manager objects.

## Wire and generated dispatch

The wire codec lives in `otr/protocols/wire`, beside the generated bindings that import it:

- `types.otr` defines `Fixed`, `Header`, `InterfaceKey`, `MsgDesc`, and the wire limits.
- `sig.otr` parses and checks message signatures.
- `decode.otr` validates message size, signature, object type, string termination, and fd count.
- `encode.otr` marshals events and closes fd arguments a send does not deliver.
- `dispatch.otr` runs a request: opcode bounds, the since-gate, decoding, the handler, and rollback on error.

`otr/wire` adds `conn.otr`, which owns bounded receive and send queues and SCM_RIGHTS accounting, and `map.otr`, which tracks client-range and server-range object ids with zombie retirement. `wire.otr` re-exports both layers.

Each resource holds a `resource.Dispatch(Root)`, a function plus an eight-byte plain datum:

```text
fn(&mut Root, datum, ResourceId, opcode: u16, body: []u8) DispatchError!void
```

Generated `Request` unions carry decoded values. The dispatcher pre-creates typed `new_id` resources before calling the handler. After a handler error, still-unimplemented resources are rolled back without a destroy hook; resources the handler implemented remain live until the fatal client reap runs their normal destructors. The handler owns the decoded request, file descriptors included, and consumes them on every path.

`Server.destroy_resource` sends `wl_display.delete_id` for client-range ids, runs the resource's destroy hook, unlinks it, retires its map entry, and frees its pool slot. Generated destructor-event senders state that the caller retires the resource through normal teardown after sending. Client destructor requests use the same method.

Hook fanout uses lists of `HookId` records in the core store, one list per target: surface destroy, buffer destroy, buffer release, output, and the ordered compositor commit list. A record names its owning module through `HookOwner` rather than holding a callback pointer, and iteration reads the next record before running the current one. No generic signal bus exists; `loop/signal.otr` handles POSIX signals only.

## Registry lifecycle

`Server.Directory.add_global` stores a global and announces it to every visible registry binding. A filter decides visibility per client. Advertised versions are capped by the generated interface version.

`remove_global` sends `global_remove` and begins a grace period. With `wl_fixes`, visible registry bindings acknowledge removal before the entry is retired. A late bind during the grace period creates an inert object instead of reaching module state. If acknowledgement tracking cannot allocate, retirement waits while registry bindings remain. `destroy_global` is the explicit immediate-retirement operation.

Global names are monotonic and never reused. New registry bindings receive live globals in creation order.

## Surfaces, roles, and commits

The core store (`core/store.otr`) owns surface, buffer, SHM pool, region, subsurface, output, and callback storage, plus the ordered extension commit-hook list. The dma-buf store (`dmabuf/store.otr`), held by the `Library` next to it, owns linux-dmabuf params and feedback, the dmabuf and wl_drm managers, and the syncobj timelines, surfaces and buffer releases; the dmabuf modules depend on core and reach it through the host, and core reaches dma-buf work only through host methods (`dmabuf/host_methods.otr`) and request handlers (`dmabuf/request_handlers.otr`) that the shared host composes, so core never imports dmabuf. A surface has `pending`, `current`, and optional `cached` `SurfaceState` values. The state includes buffer attachment, damage, regions, transform, scale, viewport-related extension state, and acquire-fence ownership.

A commit proceeds through validation, role precommit, `Backing.precommit`, barrier/cache handling, state apply, ordered extension hooks, role postcommit, and `Backing.commit`. Synchronised subsurfaces, fifo, commit timing, explicit sync, and transactions use barriers so related state becomes current atomically.

Role class is sticky. Destroying a role object releases its live object but does not let the surface change to a different role class. XDG toplevels and popups belong to the XDG shell, layer surfaces to the layer shell, and subsurfaces to the subcompositor.

Subsurface and popup trees have depth limits of 64. Subsurface state and stacking apply on the parent commit. Popup parenting uses live typed XDG roles. Popup grabs are bookkeeping in `shell/xdg_popup.otr`: they control popup-chain dismissal and keyboard focus. They do not install a pointer grab.

An installed pointer grab (`seat/grab.otr`) receives pointer enter, motion, axis, and button events in place of the default path; drag-and-drop installs one, and installing a grab replaces the current one. Seat augment modules register their globals against a seat and read pointer or keyboard state directly. Keyboard focus is shared state with hooks; there is no general typed seat event stream.

## SHM and buffers

`core.setup.register` copies the advertised SHM format list, which must include ARGB8888 and XRGB8888. Each pool owns one mapping and may grow but never shrink. Buffer bounds use checked arithmetic. Pool mappings may move during resize, so consumers resolve bytes at access time rather than cache a pointer.

Pools map their fd through the std `linux.Guarded` mapping. Readers take a lease with `shm.begin_read` and end it with `finish_read`. If the client truncated the file while it was mapped, the mapping reports a fault, the pool is marked defunct, and the access returns `PoolDefunct`, allowing the caller to post a protocol error.

`buffer.lock` and `unlock` keep storage alive across client destruction and frame submission. SHM uploads may send `wl_buffer.release` early through `release_storage_early` once pixels have been copied into a texture; the final unlock stays quiet for that release cycle. Acquire fences move with `SurfaceState` and are consumed or duplicated through the `core/acquire_fence.otr` helpers.

## dmabuf and explicit sync

The dmabuf manager validates plane count, indices, dimensions, stride, offset, modifier consistency, and fd ownership. Plane fds move into a successful `Buffer`; failed or abandoned params close all still-owned fds exactly once.

The manager builds one sealed feedback table from its copied format list. Every feedback object receives one full-state burst and its own duplicate of the table fd. Default and per-surface feedback use the same immutable state. A surface feedback becomes inert when its surface dies. If fd duplication fails, the burst omits the table and sends an empty tranche-format index list.

`dmabuf.wl_drm` serves Mesa's legacy wl_drm on top of the dmabuf manager. It names the device's render node, advertises the manager's formats that have an implicit-modifier entry, answers `authenticate` at once, and imports `create_prime_buffer` through the same import hook as linux-dmabuf. Flink-name requests fail with a protocol error.

A buffer with the implicit layout (`DRM_FORMAT_MOD_INVALID`) asks `Backing.resolve_dmabuf_modifier` for its real modifier before import. The DRM backend answers on amdgpu and i915 by adding a framebuffer for the buffer and reading its modifier back with GETFB2.

The syncobj manager attaches acquire and release timeline points to surface commits. A commit applies only once its acquire point has signalled, or, without explicit sync, once its dma-buf's implicit write fences have. Neither the renderer nor KMS ever waits on a client fence. Commits that arrive while an earlier one is still waiting are queued behind it. Only the newest is kept; the ones between are dropped, their buffers and release points returned at once and their feedback discarded. The compositor signals each release point after the submitted frame no longer uses the buffer. A fence that never signals holds that surface's updates indefinitely, as it would hold the client's own GPU work; other surfaces are unaffected. An implicit fence whose sync file reports an error lets the update apply without its buffer ever being sampled.

## Renderer contract

`render.api.RendererVTable` has eleven operations, two capability flags, and an optional guarded-SHM entry:

```text
import_shm     update_shm     destroy_texture  import_dmabuf
read_pixels    formats        begin_pass       create_target
destroy_target clear_target   read_target
samples_after_end  fences_dmabuf_reads  guarded_shm
```

Imports take plain `ShmSource` and `DmabufSource` descriptors. Their `from_buffer` functions adapt a core buffer. SHM descriptors are valid only inside the pool access window. Dmabuf fds remain owned by the core buffer and cannot be retained or closed by the importer. An SHM source that carries a fault guard is accepted only through `guarded_shm`; a renderer without it fails such imports with `InvalidBuffer`.

`begin_pass` accepts overlapping damage rectangles. Renderers clip and de-overlap them, and may conservatively widen coverage to a bounding box. Draw order is submission order. `PassVTable` supports solid rectangles, gradients, rounded borders, shadows, textures, blur, `occlude` and `end`.

`occlude` names target rectangles that later draws cover opaquely; until the next call, draws skip them. A blur still reads them, so the caller keeps each one a blur's reach clear of any blurred pixel left visible. A texture draw's `opaque_box` is the part of its destination the content declares opaque: drawn at alpha 1 without blending when the draw is at full alpha. Both renderers derive the culled and unblended areas from `render/pass_clip.otr`, so the software renderer stays the pixel reference.

A 1:1 texture draw samples nearest. The software renderer uses nearest sampling for scaled draws; Vulkan filters them linearly. Vulkan uses a dual-Kawase blur while the software renderer uses separable box passes, so blur output is not pixel-identical. Software drawing reuses pass state; blur scratch may allocate on first use.

`update_shm` may come mid-pass: draws already made keep the old texels. `read_pixels` and `read_target` are for bounded CPU consumers such as hardware cursor uploads and screen capture, and return top-down native-endian `0xAARRGGBB` rows whatever the target's format. The Vulkan renderer also has `start_read`, which copies all of a target into a host buffer of its own without waiting, handing back the copy's sync_file; the target may be destroyed meanwhile, and `finish_read` copies the rows out once it signals. The last finished read's host buffer is kept for the next read that fits in it. Normal composition stays on the renderer. Renderer-owned targets (`create_target`) back window capture. `copy_target` draws an area of one target into all of another, turned and scaled to fit, writing only the destination rects it is given; both renderers have it. Below half size each destination pixel averages the source pixels it covers, so a thumbnail of a busy screen does not alias: Vulkan with a grid of linear taps two texels apart, the software renderer with an exact area average. Renderers with `dmabuf_targets` (Vulkan) also turn a client's dma-buf into a target with `import_target` and hand out the sync_file of the last pass into a target with `take_fence`; that pass also leaves its fence on the dma-buf for implicit-sync readers. `target_formats` lists the single-plane layouts this works for. `samples_after_end` says whether the GPU may still read a pass's textures after `Pass.end`: when it may, buffer locks last until presentation. `fences_dmabuf_reads` says whether the renderer attaches its read fence to the client dma-bufs a frame samples.

### Vulkan renderer

`render/vk_renderer.otr` owns one Vulkan 1.3 device and everything frames share; `render/vk_record.otr` is the only path to the queue. Each frame is one submission: copies and layout transitions first, then the pass's instanced draws, one per run of quads with the same pipeline and, for textures, the same image. Textures are sampled through one bindless descriptor array, and pipelines are built on first use and kept in a disk cache under `zooland/` in a cache directory the compositor supplies (Zoolander passes `$XDG_CACHE_HOME`, or `~/.cache`). A timeline semaphore decides when images, memory and bindless slots are freed. Shm damage is copied through a staging ring before `update_shm` returns, so the client's storage is free at once; on an integrated or CPU device a texture may instead live in a host-visible image the CPU writes. After ten seconds without a pass the staging ring, blur scratch images and those CPU-written textures go back, so an idle compositor holds none of them.

The DRM backend creates the renderer on the Vulkan device whose DRM node is the KMS device; it never falls back to another GPU. A backend created with `Options.primary` is a second GPU that only drives connectors, such as the one behind a hybrid laptop's external ports: it opens its device on the primary backend's session, creates no renderer, and presents what the primary's renderer drew. Each frame is drawn in the renderer's own memory and copied once on the GPU into a buffer of that device: a GBM buffer in a layout the renderer draws into, else one of the device's dumb buffers, exported and imported as LINEAR, which is what is left when GBM there allocates nothing another vendor's driver renders to. NVIDIA's dumb buffers are never offered: they are video memory no other driver maps, and the export says nothing of it. When the renderer imports neither, a device with a Vulkan driver of its own shows the frames itself (`backend/drm_present.otr`): the renderer draws each frame into memory it exports in a layout both drivers know, and a second renderer on the device, the presenter, samples it and draws the frame's damage into the device's own scanout buffers, after waiting for the frame's fence. Neither GPU writes the other's memory, which is the only way onto a GPU that scans out nothing foreign and shares none of its own (NVIDIA). The presenter is made for the device's first output and closed with its last, and before an output depends on it a whole frame is drawn through it and waited for; any refusal leaves the device on the readback: only then are frames read back into its dumb buffers, on the CPU. The presenter waits for each frame on the GPU, through the frame's fence imported into a semaphore of its submission, so the compositor does not. Either way only the frame's damage crosses, which covers the previous frame's too: the copy is clipped to the damage rects, and the readback takes their bounding box in one wait. It starts after the primary and closes before it. While the instance is created, the loader is pinned to that device's driver through `VK_LOADER_DRIVERS_SELECT`, unless the environment already selects drivers, and implicit layers are disabled through `VK_LOADER_LAYERS_DISABLE`, so no other driver or overlay layer is loaded. Without a usable device the backend renders in software, into a shadow image in ordinary memory: dumb buffers are mapped write-combined, where each read that blending makes costs about a hundred times what it costs in memory, so a frame is drawn in the shadow and its damage, which covers the previous frame's too, is copied in whole rows into the dumb buffer it is shown from. Outputs a GPU may still take draw into their dumb buffers directly and have no shadow. Scanout images are allocated with libgbm from the modifiers the plane and the driver share and imported into Vulkan; with none in common, each frame is copied on the GPU into GBM buffers in a layout the plane lists and the driver imports and renders to, preferring tiled layouts and trying LINEAR when GBM cannot allocate those, then into dumb buffers the renderer imports, and only when it imports none of these are frames read back into dumb buffers.

On NVIDIA (proprietary driver, `nvidia-drm`) the driver selection is `*nvidia*`, and the EGL vendor library is pinned to NVIDIA's `10_nvidia.json` when the environment does not choose one. Modifiers compare as whole values; NVIDIA encodings are never normalized. When the driver lacks `VK_EXT_queue_family_foreign` the renderer uses `VK_QUEUE_FAMILY_EXTERNAL`; without a sync_file export the CPU waits for each frame before the commit.

User-facing environment variables:

| Variable | Effect |
|---|---|
| `ZOOLAND_VK_VALIDATION=1` | Load the Khronos validation layer. |
| `ZOOLAND_VK_TIMING=1` | Log GPU time per part of a submit and per-frame counters once a second. |

Developer switches, for measurement only (`render/vk_timing.otr`):

| Variable | Effect |
|---|---|
| `ZOOLAND_VK_DEBUG_NO_FOREIGN=1` | Never acquire or release dma-buf images. Breaks the ownership rules. |
| `ZOOLAND_VK_DEBUG_FULL_DAMAGE=1` | Every pass redraws its whole target. |
| `ZOOLAND_VK_DEBUG_NO_HOST_TEXTURES=1` | Keep shm textures in device memory, filled by staging copies. |
| `ZOOLAND_VK_DEBUG_SOLID_TEXTURES=1` | Draw every texture as an opaque grey fill of the same area. |
| `ZOOLAND_VK_DEBUG_NONUNIFORM_TEXTURES=1` | Batch quads of different textures into one draw, sampled by a per-quad index. |
| `ZOOLAND_VK_ALLOW_UNMATCHED=1` | Test VMs only: render on any Vulkan device, such as lavapipe. |

## Backend contract

`backend.api.BackendVTable` has exactly three operations:

```text
start  commit_frame  test_configuration
```

Install `Sinks` before `start`. Initial outputs are announced during start. `commit_frame` presents the newest image in an output target; commits coalesce while one present is pending. A `Frame` carries damage, adaptive-sync, content-type, and output-color state, and may name a client dma-buf for direct scanout. A direct-scanout buffer may also carry a `PlaneLut`, the SDR-to-PQ conversion composition would apply, which DRM programs into the primary plane's colour pipeline (kernel 6.19 colorops): a shaper 1D LUT and a 3D LUT on amdgpu, or on NVIDIA a decode 1D LUT, multiplier and 3x4 matrix with the CRTC's `NV_CRTC_REGAMMA_TF` set to PQ for those frames, where `Info.plane_color_capable` says one exists; while that pipeline runs the hardware cursor shows from an untagged-SDR copy of its image (`set_converted_cursor`) where `Info.cursor_in_plane_color` says the display engine blends it ahead of the pipeline (amdgpu DMU 4.0.1), and stays off the plane elsewhere. `test_configuration` validates a complete multi-output proposal without applying it. DRM implements it as an atomic TEST_ONLY commit.

`OutputDev` exposes output information, the render target and its optional dmabuf export, pending-frame state, retirement, mode and custom-mode changes, power, adaptive sync, cursor-plane capability, cursor upload and drawing, cursor movement, repaint-window scheduling, and scanout formats. Mode changes call `retire` first and fail without proof that prior output-owned resources are no longer in flight. Unsupported adaptive sync accepts only the disabled state.

A `Present` reports the kernel sequence, extended 64-bit MSC, monotonic timestamp, refresh interval, and whether the flip tore. Buffer locks and scanout ownership remain live until the backend proves retirement or reports completion.

DRM cursor planes accept CPU pixels through `set_cursor_image`, or a renderer's texture through `draw_cursor`, optionally over a second texture such as a drag icon, placed from the pointer: the plane's dumb buffer is imported once as a LINEAR target of that renderer, and both are drawn on the GPU into a target of the renderer's own and copied over all of that buffer in one pass, so the plane never scans it cleared or half drawn, without waiting for the GPU. When the driver cannot render to that buffer (NVIDIA renders no LINEAR), they are read back from that target with `start_read` instead, and the buffer is not offered to that renderer again until it is replaced: the plane keeps its previous image until the read's fence signals in the event loop, then the rows are copied into the dumb buffer. Together larger than the plane, `draw_cursor` refuses. The reference compositor uploads SHM cursor bytes, composing an SHM cursor with a drag icon on the CPU, and draws dma-buf cursors with the drag icon uploaded as a texture, reading the cursor back with `Renderer.read_pixels` only for an output that refuses the draw, or for a CPU screen capture of the cursor. Plane or size refusal falls back to compositing the cursor.

## Capture

wlr-screencopy, the ext output and foreign-toplevel image-copy sources, the Hyprland workspace source, and ext-image-copy-capture are separate globals. Screencopy and image-copy capture share one `capture.Hooks` value, installed with the host's `configure_capture`.

For output capture:

1. A client queues a frame. Once the frame has damage to report, `Hooks.schedule` asks the compositor to repaint the output.
2. Each repaint first reports what changed with `ext.capture.screencopy.damage(host, output, rects, cursor)`, in upright output pixels: the scene's damage with `cursor` false, and separately the pointer cursor's old and new rects with `cursor` true, which reach only captures that show the cursor. A compositor repaints on cursor motion while `capture_waiting(host, true)` says such a capture is queued, even when a plane alone shows the cursor, and when what a plane shows goes into every capture, such as a drag icon, while `capture_waiting(host, false)` says any is.
3. Before drawing the cursor, the compositor checks `ext.capture.screencopy.has_pending(host, output, false)` and calls `capture_pending(host, output, false)`.
4. After drawing the cursor, it does the same with `true`.
5. A successful page flip calls `presented(host, output, time_ns)`; a failed frame calls `fail_pending(host, output)`.

An image-copy session collects the damage since its last frame was copied, mapped onto its buffer; a new session, and the next frame after changed constraints or a failure, starts with all of it. A queued frame is pending only once that damage is not empty, so `has_pending` and `needs_frame` stay false while nothing changed. The session also keeps, for the last eight buffers it filled, what changed since each was filled: a client rotating buffers hands each back missing every change since, not only the last frame's. The copy writes that and the frame's own `damage_buffer` rects, the client's account of what is stale in that buffer, and reports all it writes; a buffer the session has not filled, or no longer remembers, is written and reported whole. A wlr-screencopy `copy_with_damage` frame waits the same way on damage collected per manager binding, output and cursor flag that the binding's frames have not taken, each taking what lies in its region, reports it inside the frame's region, and still copies the whole region, since the client cannot say what its buffer lacks. Without `Hooks.schedule`, copies are made at once and report all of the buffer. Toplevel frames are copied at once and workspace frames at every repaint of their output, both whole: a window's commits are not tracked as capture damage.

`ext.screencopy` forwards `needs_frame`, `capture_pending`, `presented`, and `fail_pending` to ext-image-copy-capture and wlr-export-dmabuf. A queued wlr-export-dmabuf frame takes the rendered target through the root's `export_frame` at the with-cursor pass, as new dmabuf fds, and sends them with `ready` at presentation. The frame is the scanout image, so it holds a cursor only when the compositor drew it into the frame. The backend describes a target with `OutputDev.export_target`; DRM supports it for Vulkan scanout images and the GBM buffers frames are copied into, not for dumb buffers.

`Hooks.copy` receives the output, a rectangle in transformed output pixels, the size to scale it to, an include-cursor flag, the format, the destination rects to write, a destination slice, and byte stride; only those rects reach the client's buffer. It returns whether rows are bottom-up. Toplevel capture calls `prepare_toplevel` before destination SHM access, then `copy_toplevel` consumes the prepared frame. This separation prevents nested source and destination SHM access windows. Workspace capture is paced like output capture on the output the workspace is on when the session starts, but always at the with-cursor pass, after the output's own pass has ended; `copy_workspace` renders the workspace offscreen into the destination, which starts zeroed, so returning without drawing gives a transparent image. Pointer-cursor capture sessions are currently stopped immediately.

A compositor whose renderer draws into client dma-bufs installs `Hooks.dmabuf_format` and `Hooks.copy_dmabuf`. Session constraints and wlr-screencopy v3 frames then also offer the device and the single-plane modifiers `dmabuf_format` lists for the session's format, and a frame accepts a one-plane dma-buf of that format, size and one of those modifiers; any other dma-buf fails with `buffer_constraints` (wlr-screencopy: `failed`). `copy_dmabuf` draws the output, toplevel or workspace upright into the buffer on the GPU, an output only inside the damage rects it is given, so such frames report transform `normal` and no y-invert. It returns whether the GPU may still be writing; the frame's `ready` then waits, past presentation if need be, until the compositor calls `ext.capture.screencopy.dmabuf_written(host, buffer)`, which it does from its event loop once the write's fence signals.

`zoolander_image_copy_capture_size_manager_v1` (`protocols/zoolander-image-copy-capture-size-v1.xml`) gives an image-copy session a maximum size for thumbnails. The session keeps the source's own size and advertises it fitted inside the maximum with the aspect ratio kept and never scaled up, sending the constraints again whenever the fitted size changes. Frames are then drawn scaled: `Hooks.copy` and `copy_dmabuf` get the whole output as their rectangle and a smaller destination, and the toplevel and workspace hooks get a target of the fitted size to draw the source into.

## Foreign toplevel mapping

`ext/toplevel/foreign_toplevel.otr` serves ext-foreign-toplevel-list, wlr-foreign-toplevel-management, and `hyprland_toplevel_mapping_manager_v1`. One internal toplevel record fronts both standard handles. The mapping global returns the same opaque 64-bit value for either handle, allowing a shell to join them without exposing a process pointer. Closed or invalid handles return `failed`.

## Text input and input methods

`ext/text_input/text_input.otr` keeps one `Hub` per seat, pairing its text inputs with the seat's one input method. `ext/text_input/text_input_legacy.otr` adds text-input v1 and v2 objects to the same hubs as text inputs of their own version, and `ext/text_input/input_method_v1.otr` adds input-method v1 binds to the input-method manager as input methods of kind `.v1`, so any input method serves any text input. A bind or `get_input_method` made while the seat has an input method gets nothing (v1) or `unavailable` (v2).

v3 and v2 text inputs follow keyboard focus. A v1 text input enters only the surface it activated, while that surface has keyboard focus, and losing the focus ends the activation. v2 enables input per surface and commits on an `update_state` that cites the latest enter serial. v1 and v2 number content purposes without v3's `pin`, and their hints share v3's low ten bits.

An input method delivers an edit (preedit, deletion, commit string). v3 gets it as one `done`; v1 and v2 get their own events, where a commit string replaces the preedit. An input-method v1 context's requests reach v1 and v2 text inputs unchanged. For v3 each preedit or commit string becomes one edit with the preceding preedit cursor or deletion folded in, and a keysym goes to the input-method v1 `Hooks.keysym`. A context's keyboard grab is a `wl_keyboard` that ends with the context; its `key` and `modifiers` requests reach the focused client as physical input. Input-method v1 panel surfaces are input popups whose `placement` is a keyboard at the bottom of an output or an overlay at the text cursor.

## Toplevel drags and sessions

`ext/toplevel/toplevel_drag.otr` binds at most one toplevel drag to a `wl_data_source`, which makes the source drag-only. The compositor finds it from a running drag with `toplevel_drag.of_source` and hears of later attaches through its toplevel-drag attach hook; moving the window is its job. An attached toplevel that unmaps or dies is detached.

`ext/toplevel/session_mgmt.otr` owns session ids, toplevel names and their errors. A session is restored when the id is live in another client, which then gets `replaced`, or when `Hooks.exists` knows it; any other id gets a fresh random one. Storage is compositor policy: `Hooks.restore` stages a restored toplevel's first configure, `Hooks.detached` stores a toplevel when its tracking ends, and `Hooks.remove` and `Hooks.rename` forget or move stored state. `session_mgmt.toplevel_snapshot` reads the tracking session of a toplevel.

## Tests and hardware boundaries

Files with `test` blocks run with `otr test`: `loop/loop.otr`, `loop/timer.otr`, `runtime_test.otr`, the codec in `protocols/wire/`, `render/color_test.otr`, and `render/vk_staging.otr`. The integration checks live in Zoolander's `otr/tests/` package and build the full compositor root against this library.

Checks that open render or DRM devices, or take session or DRM master ownership, are VM-only. They must not run on an active host session.
