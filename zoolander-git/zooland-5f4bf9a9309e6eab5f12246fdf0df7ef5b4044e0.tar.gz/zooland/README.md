# zooland

zooland is an Otr Wayland compositor library with its own wire implementation. It provides protocol state machines, a Linux event loop, software and Vulkan renderers, and headless, nested, and DRM/KMS backends. It does not depend on libwayland.

The package lives in [`otr/`](otr) and requires otr 0.2.2 or later. Declare it in the consumer's `otr.toml` using the path selected by your project:

```toml
[dependencies]
zooland = "../zooland/otr"
```

The identifiers, regions, colour data and SHM mappings every layer shares live in the `zooland_types` leaf package in [`otr/types/`](otr/types), which imports nothing from zooland; a consumer that names those types declares it too (`zooland_types = "../zooland/otr/types"`) and imports `zooland_types.identity`, `zooland_types.region` and so on.

Modules are imported by their path inside the package, for example `import zooland.server`, `import zooland.render.api` or `import zooland.backend.headless`. The package has three areas:

- the server: `wire/`, `protocols/`, `loop/`, `server.otr`, `core/`, `shell/`, `seat/`, `dmabuf/` and `ext/` hold the wire, generated bindings, event loop, core protocols, shells, input, and extensions
  - `ext/` groups the extension protocols by feature: `capture/`, `color/`, `idle/`, `input/`, `output/`, `registry/` (the global descriptors and bindings), `security/`, `selection/`, `surface/`, `tablet/`, `text_input/` and `toplevel/`. The store every extension shares (`state_store`, `state_root`, `state_class`, `value_hooks`, `external_hooks`) and the helpers they call (`common`, `core_access`, `file_read`, `control_methods`, `extension_policy`) stay at the top of `ext/`.
- `render/`: the renderer API in `render/api.otr`, the software renderer (`swrender*.otr`), and the Vulkan renderer (`vk_*.otr`)
- `backend/`: the backend API in `backend/api.otr`, headless, nested, DRM/KMS, and libinput

The package declares no C link set; the consumer's `otr.toml` supplies it. Consumers using `seat/xkb.otr` link `xkbcommon`. The Vulkan renderer loads `libvulkan.so.1` when it is created and needs a Vulkan 1.3 driver for the display's GPU, with the dma-buf and DRM-modifier extensions. The DRM backend links libdrm, libgbm, libinput, libudev, and libseat; without a usable Vulkan device it renders in software into dumb buffers. Zoolander's `otr/otr.toml` shows a complete link set.

## Starting a server

The library is generic over a root struct owned by the compositor. Persistent state holds generational IDs such as `ClientId`, `ResourceId` and `SurfaceId` rather than pointers, and every call takes the root or a short-lived host made from it. The root has these fields:

- `server`: `server.Server(Root)`
- `event_loop`: `loop.loop.Loop(Root)`
- `signals`: a `?loop.signal.Signals(Root)`, when the compositor handles signals through the loop
- `runtime`: a `library.Library(Host)` value, which owns the core, seat and shell, extension, and renderer stores
- `backend_state`: the backend pools from `backend/owners.otr`, when a backend is used, together with the declaration `pub const BackendAccess = backend.access.Access(Root)` through which the backend modules and the compositor reach those pools

`shared_host.Host(Root, Backing)` is the host type that protocol handlers run with. `Host.init(root, client)` makes one for a client request and `Host.init_system(root)` one for compositor-initiated work. [`runtime_test.otr`](otr/runtime_test.otr) builds the smallest root for a server and loop; Zoolander's `otr/comp.otr` and `otr/composition.otr` assemble the full one. Setup follows these steps:

1. Initialize the `Library`, `Loop` and `Server` into the root.
2. Call `Server.listen(root, options)`. It uses `options.runtime_dir` or reads `XDG_RUNTIME_DIR` from `options.env`. `root.server.listener.?.name()` is the value to expose as `WAYLAND_DISPLAY` to child processes.
3. Register the globals your compositor supports: `Server.register_fixes`, `core.setup.register` for `wl_compositor`, `wl_subcompositor`, `wl_shm` and optionally the syncobj manager, `seat.seat.register`, the shell host methods (`register_xdg_shell`, `register_layer_shell`, `register_session_lock`, `register_xwayland_shell`), `dmabuf.dmabuf.register`, `dmabuf.wl_drm.register`, and extension globals through `Server.Directory.add_global` with `ext.registry.globals.bind` as the bind hook. Call `ext.registry.globals.init` before publishing an extension global so its compositor surface hook is installed, and `ext.registry.globals.deinit_all` once the last client is gone.
4. Start the chosen backend after installing its sinks.
5. Run `Loop.run(root)` or drive `Loop.tick(root, timeout_ms)` from an embedding host.
6. Stop external event sources and retire backend and renderer consumers that hold buffer locks, call `Server.shutdown(root)` while the library stores remain alive, then `Loop.shutdown(root)`, then deinitialize.

`Server.shutdown` must run before the library stores are deinitialized because client destruction calls resource destroy hooks that reach those stores; `Server.deinit` panics if it has not run. A client whose teardown needs live backend handles may be destroyed explicitly with `Server.destroy_client` before the backend is retired.

## Host and hooks

zooland owns protocol validation and resource lifetimes. The compositor owns policy and presentation. The two talk through explicit interfaces that zooland declares and the compositor implements; zooland never looks a hook up on the root by name.

- **Root fields.** The root has the fixed fields listed under "Starting a server". `Server`, `Loop` and `Signals` are generic over the root type only and reach `root.server`, `root.event_loop` and `root.signals` directly, so a root without them fails to compile with the missing field's name.
- **Root hooks.** The root declares `pub const hooks = zooland.hooks.Set{ ... }`. Each field of `hooks.Set` is one area, such as `gamma`, `lease`, `foreign_toplevel`, `gtk_shell` or `workspace`, and holds a namespace type whose functions implement it. The protocol module that calls an area declares its spec next to its protocol state, as `pub fn Hooks(comptime H: type) type` over the host type, a struct whose fields name each hook and give its signature, for example `size: fn(&H.Context, H.OutputId) ?u32`, and reaches the root's namespace only through its `Root(H)`, which is `hooks.area(H.Context, "gamma", Hooks(H))`. A missing area is a compile error naming the field of `hooks.Set`, and a missing hook one naming the hook, with the protocol module in the instantiation notes. A hook whose type is concrete must match the spec exactly; a generic one is checked where zooland calls it. An area is checked when the protocol that uses it is compiled in, so a root built for a few protocols needs only theirs; `default_hooks.with(Host, Overrides)` builds a full `Set` from the namespaces `Overrides` declares and zooland's defaults for the rest, which test roots use. Each protocol module sees only its own area.
- **Host methods.** `shared_host.Host(Ctx, Backing)` is the host type every protocol module receives. It composes per-area method namespaces (`ShellMethods`, `SeatInputMethods`, `StorageMethods` and so on, listed in `shared_host_composition.otr`), and because Otr has no mixins `shared_host.otr` binds each method a module calls through the host as a `pub const`, so `host.lock_read(id)` names one function in one namespace. A namespace function the host does not bind is called through `Host.Domains.<Namespace>`. A new method goes into its area's namespace and, if callers use method syntax, one line of that table.
- **Backing.** The `Backing` type passed to `shared_host.Host` receives new surfaces and commit stages (`new_surface`, `precommit`, `commit`) and supplies dma-buf import, scanout tranches, the timeline operations behind explicit sync and `input_method_changed`. A missing operation is a compile error naming it where zooland calls it.
- **Shell options** carry policy hooks that create and configure compositor windows while the shell modules retain protocol role state.
- The seat modules (`seat/pointer.otr`, `seat/keyboard.otr`, `seat/touch.otr`) deliver physical input. Extension modules read seat state or call their area's hooks.
- Each extension module declares its globals as descriptors listed in `ext/registry/globals.otr`; the compositor chooses which to publish and which to filter, for example through `ext.security.security_ctx.visible`. The layer-shell and session-lock globals filter through their `authorize` options, and the Xwayland shell global is always filtered through the host's Xwayland authorization.
- Backend sinks announce outputs and input, open repaint windows, and report presentation.
- **Core state** belongs to zooland. A compositor reads and changes it only through the owning module's functions, such as `core.buffer.lock` and `unlock`, `core.buffer.mark_import_failed`, the host's barrier methods and `ext.external_hooks.register`; it never writes a store or pool field itself.

`tests/fixture.otr` builds its root's hooks with `default_hooks.with`; a protocol suite replaces an area by declaring a namespace of the same name in the `Hooks` type it passes.

If an input method holds a keyboard grab, apply compositor key bindings and interactive cancel keys before forwarding an unconsumed physical key through `ext.text_input.input_method.feed_key`. This lets compositor bindings and an Escape that cancels move or resize take precedence over IME input.

## Rendering and backends

`render.api.Renderer` imports SHM or dmabuf images, updates SHM textures, reads rare CPU copies, reports supported formats, starts passes, and waits on acquire fences. A pass records rectangles, gradients, borders, shadows, textures, blur, occluders, and its final `end`. See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for ownership and synchronization details.

`backend.api.Backend` has three operations: `start`, `commit_frame`, and whole-configuration `test_configuration`. Each `OutputDev` supplies its target plus mode, power, adaptive-sync, pacing, and cursor-plane operations. A compositor renders into `OutputDev.target()`, calls `commit_frame`, and releases frame-owned buffer locks only after retirement or presentation as described by the backend API.

Headless is suitable for deterministic tests. Nested connects to another Wayland compositor. DRM/KMS and libinput require a controlled session and their system libraries.

## Protocols

The vendored XML files in [`protocols/`](protocols) are compiled into the bindings under [`otr/protocols/`](otr/protocols), which are checked in. [`otr/tools/gen-protocols.sh`](otr/tools/gen-protocols.sh) regenerates them, [`otr/tools/gen-shaders.sh`](otr/tools/gen-shaders.sh) rebuilds the shader SPIR-V under `otr/render/shaders/`, and [`otr/tools/check-generated.sh`](otr/tools/check-generated.sh) fails when either is stale. [`docs/interface-versions.tsv`](docs/interface-versions.tsv) caps advertised versions. [`docs/hyprland-matrix.json`](docs/hyprland-matrix.json) records the Hyprland-compatible global set covered by zooland, including the toplevel mapping bridge served by `ext/toplevel/foreign_toplevel.otr`.

`ext.capture.screencopy.capture_pending`, `presented`, and `fail_pending` drive wlr-screencopy, ext-image-copy-capture, and wlr-export-dmabuf frames together, and `ext.capture.screencopy.damage` tells them what changed on an output: image-copy and `copy_with_damage` frames wait for damage, report it, and image-copy writes only it and the client's own buffer damage. Screencopy and image-copy capture share one `capture.Hooks` value, installed with the host's `configure_capture`. Pointer-cursor capture sessions are currently reported as stopped; output capture with or without the composited cursor is supported. wlr-export-dmabuf hands clients the scanout dmabuf, taken from the root's `export_frame`, instead of a copy. Through two more hooks a compositor whose renderer draws into client dma-bufs, as the Vulkan renderer does, takes screencopy and image-copy clients' own dma-bufs and fills them on the GPU; see the capture section of the architecture notes.

## Checks

Every test, in both repositories, runs through Zoolander's `tests/run.sh`; see the Zoolander README. A single file runs with `otr test` from its package directory, `otr/` or the `otr/tests/` package:

```sh
otr test loop/loop.otr
cd tests && otr test harness_test.otr
```

`otr/tests/` holds the protocol test support: `wclient.otr`, a raw-wire client over the generated interface tables; `harness.otr`, an in-process server with socketpair clients and deterministic ticks; `fixture.otr`, a library-only compositor context with zooland's default hooks, for protocol suites; and `backend_root.otr`, a root with only a loop, the backend pools and a software renderer, for driving the headless backend and a DRM backend with no device. These start servers or touch backends, so they run only in the test VM.

Further references:

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md): module boundaries, lifetimes, rendering, backends, and capture
- [`docs/CODEGEN-SPEC.md`](docs/CODEGEN-SPEC.md): generated protocol bindings
