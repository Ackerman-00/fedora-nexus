#!/bin/bash
# Runs workspace_protocol.py against a fresh zoolander inside the test VM.
# Never run this on a workstation: it starts a compositor on the local seat
# and forces a DRM connector on and off.
#
# usage: run_workspace_protocol.sh <zoolander binary> [connector status file]
# The VM needs two outputs (VM_OUTPUTS=2), seatd, and passwordless sudo for
# the connector status writes and udevadm.
set -u
BIN=$(realpath "$1")
STATUS=${2:-/sys/class/drm/card0-Virtual-2/status}
HERE=$(cd "$(dirname "$0")" && pwd)
WORK=$(mktemp -d)
mkdir -m700 "$WORK/rt"
mkdir -p "$WORK/cfg"
cp -r "$HERE/../config/ferreo" "$WORK/cfg/zoolander"
# The stock startup hook spawns the desktop clients; the checks want a bare session.
printf 'zl.on("startup", function() end)\n' > "$WORK/cfg/zoolander/exec.lua"
sudo -n sh -c "echo on > $STATUS"
export XDG_RUNTIME_DIR=$WORK/rt XDG_CONFIG_HOME=$WORK/cfg LIBSEAT_BACKEND=seatd SEATD_SOCK=/run/seatd.sock XDG_SESSION_TYPE=wayland
"$BIN" > "$WORK/zoolander.log" 2>&1 &
COMPOSITOR=$!
for _ in $(seq 1 40); do ls "$WORK"/rt/wayland-? > /dev/null 2>&1 && break; sleep 0.5; done
WAYLAND_DISPLAY=$(basename "$(ls "$WORK"/rt/wayland-? | head -1)")
export WAYLAND_DISPLAY
sleep 2
UNPLUG=$STATUS python3 "$HERE/workspace_protocol.py"
RC=$?
kill $COMPOSITOR
wait $COMPOSITOR 2> /dev/null
sudo -n sh -c "echo detect > $STATUS"
[ $RC -eq 0 ] || tail -20 "$WORK/zoolander.log"
rm -rf "$WORK"
exit $RC
