#!/usr/bin/env python3
"""First start with the starter config, against a real zoolander on the headless backend.

usage: starter_config_e2e.py ZOOLANDER STARTER_DIR [CASE...]

The binary is copied into a scratch prefix whose share/zoolander/config is STARTER_DIR,
so it finds the in-repo starter where an installed one finds /usr/share's. Each case
starts it without --config against a scratch HOME. Run it in the test VM only.
"""
import filecmp
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

import config_e2e

STARTER_FILES = ("init.lua", "monitors.lua", "keybinds.lua", "windows.lua", "exec.lua")
# What a config that loads cleanly never logs.
CONFIG_TROUBLE = ("unknown field", "initial config load failed", "emergency config", "does nothing before compositor startup",
                  "reading the starter config", "no starter config", "first start: reading", "first start: creating",
                  "first start: writing")


class FirstStart(config_e2e.Compositor):
    """A compositor started from PREFIX/bin with HOME (and XDG_CONFIG_HOME when given) and no --config."""

    def __init__(self, prefix, home, xdg_config_home=None):
        self.dir = tempfile.mkdtemp(prefix="zl-starter-e2e-")
        self.runtime = os.path.join(self.dir, "rt")
        os.mkdir(self.runtime, 0o700)
        env = dict(os.environ, XDG_RUNTIME_DIR=self.runtime, HOME=home)
        for name in ("WAYLAND_DISPLAY", "DISPLAY", "XDG_CONFIG_HOME"):
            env.pop(name, None)
        if xdg_config_home:
            env["XDG_CONFIG_HOME"] = xdg_config_home
        self.log = open(os.path.join(self.dir, "compositor.log"), "w")
        self.proc = subprocess.Popen([os.path.join(prefix, "bin", "zoolander"), "--headless", "--headless-size=1280x720"],
                                     env=env, stdout=self.log, stderr=subprocess.STDOUT)
        self.clients = []
        self.display = None
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline and self.proc.poll() is None:
            names = os.listdir(self.runtime)
            if any(n.startswith("zoolander-") for n in names):
                self.display = next(n for n in names if n.startswith("wayland-") and not n.endswith(".lock"))
                break
            time.sleep(0.1)
        if self.display is None:
            raise RuntimeError("compositor did not start:\n" + self.output())


def clean_load(comp):
    log = comp.output()
    trouble = [line for line in log.splitlines() if any(t in line for t in CONFIG_TROUBLE)]
    assert not trouble, trouble


def binds(comp):
    listed = comp.eval("local o={} for _,b in ipairs(zl.bindings()) do o[#o+1]=b.mods..' '..b.key..' '..b.description end return table.concat(o,';')")
    return listed.split(";")


def starter_binds_registered(comp):
    got = binds(comp)
    for want in ("SUPER Return Terminal", "SUPER d Application launcher", "SUPER q Close window", "SUPER f Fullscreen",
                 "SUPER+SHIFT q Log out", "SUPER Left Focus left", "SUPER+SHIFT Down Move window down",
                 "SUPER 1 Workspace 1", "SUPER 9 Workspace 9", "SUPER+SHIFT 9 Move to workspace 9", "SUPER mouse:272 Move window"):
        assert want in got, (want, got)
    assert len(got) == 35, got


def floats(comp, app_id):
    comp.clients.append(config_e2e.Toplevel(comp.runtime, comp.display, app_id, app_id=app_id))
    time.sleep(0.3)
    return next(w["floating"] for w in comp.layout()["windows"] if w["title"] == app_id)


def copied(starter, config_dir, names):
    for name in names:
        target = os.path.join(config_dir, name)
        assert filecmp.cmp(os.path.join(starter, name), target, shallow=False), f"{target} differs from the starter"


def case_fresh_home(prefix, starter, home):
    """An empty HOME gets the whole starter in ~/.config/zoolander, which then loads cleanly."""
    comp = FirstStart(prefix, home)
    try:
        config_dir = os.path.join(home, ".config", "zoolander")
        assert sorted(os.listdir(config_dir)) == sorted(STARTER_FILES), os.listdir(config_dir)
        copied(starter, config_dir, STARTER_FILES)
        log = comp.output()
        for name in STARTER_FILES:
            assert f'first start: copied "{os.path.join(prefix, "share/zoolander/config", name)}" to "{os.path.join(config_dir, name)}"' in log, log
        clean_load(comp)
        starter_binds_registered(comp)
        # A helper rule and a direct rule are both live.
        assert floats(comp, "zoolander-settings")
        assert floats(comp, "Picture-in-Picture")
        assert not floats(comp, "steam_app_42")
    finally:
        assert comp.stop(), "compositor died:\n" + comp.output()
    # Second start: init.lua is there, so nothing is copied again.
    comp = FirstStart(prefix, home)
    try:
        assert "first start" not in comp.output(), comp.output()
        clean_load(comp)
    finally:
        assert comp.stop()


def case_existing_init_untouched(prefix, starter, home):
    """An existing init.lua, under XDG_CONFIG_HOME, is loaded as it is and nothing is copied beside it."""
    xdg = os.path.join(home, "xdg")
    config_dir = os.path.join(xdg, "zoolander")
    os.makedirs(config_dir)
    mine = 'zl.set_layout("grid")\nzl.bind(zl.MOD_LOGO, "y", function() end, { description = "Mine" })\n'
    with open(os.path.join(config_dir, "init.lua"), "w") as f:
        f.write(mine)
    comp = FirstStart(prefix, home, xdg)
    try:
        assert os.listdir(config_dir) == ["init.lua"], os.listdir(config_dir)
        with open(os.path.join(config_dir, "init.lua")) as f:
            assert f.read() == mine
        assert binds(comp) == ["SUPER y Mine"], binds(comp)
        assert not os.path.exists(os.path.join(home, ".config", "zoolander", "init.lua"))
    finally:
        assert comp.stop()


def case_partial_dir_gets_missing(prefix, starter, home):
    """A config directory without init.lua gets only the starter files it lacks; its own windows.lua is kept and used."""
    config_dir = os.path.join(home, ".config", "zoolander")
    os.makedirs(config_dir)
    mine = 'zl.add_window_rule("app_id", "^(mine)$", { float = true })\n'
    with open(os.path.join(config_dir, "windows.lua"), "w") as f:
        f.write(mine)
    comp = FirstStart(prefix, home)
    try:
        with open(os.path.join(config_dir, "windows.lua")) as f:
            assert f.read() == mine
        copied(starter, config_dir, [n for n in STARTER_FILES if n != "windows.lua"])
        assert "windows.lua\" to" not in comp.output(), comp.output()
        clean_load(comp)
        starter_binds_registered(comp)
        assert floats(comp, "mine")
        assert not floats(comp, "zoolander-settings")
    finally:
        assert comp.stop()


def case_read_only_home_loads_installed(prefix, starter, home):
    """When nothing can be written, the installed starter is loaded where it is."""
    if os.geteuid() == 0:
        print("SKIP root ignores directory permissions")
        return
    os.chmod(home, 0o500)
    try:
        comp = FirstStart(prefix, home)
        try:
            entry = os.path.join(prefix, "share/zoolander/config", "init.lua")
            assert f'loading the starter config "{entry}"' in comp.output(), comp.output()
            starter_binds_registered(comp)
            assert floats(comp, "zoolander-settings")
            assert os.listdir(home) == []
        finally:
            assert comp.stop()
    finally:
        os.chmod(home, 0o700)


def case_schema_names_starter(prefix, starter, home):
    """--config-schema tells a settings app where the installed starter is."""
    schema = json.loads(subprocess.run([os.path.join(prefix, "bin", "zoolander"), "--config-schema"], check=True,
                                       capture_output=True, text=True).stdout)
    assert schema["starter_dir"] == os.path.join(prefix, "share/zoolander/config"), schema["starter_dir"]


CASES = {
    "schema_names_starter": case_schema_names_starter,
    "fresh_home": case_fresh_home,
    "existing_init_untouched": case_existing_init_untouched,
    "partial_dir_gets_missing": case_partial_dir_gets_missing,
    "read_only_home_loads_installed": case_read_only_home_loads_installed,
}


def main():
    binary, starter = sys.argv[1], os.path.abspath(sys.argv[2])
    selected = sys.argv[3:] or list(CASES)
    scratch = tempfile.mkdtemp(prefix="zl-starter-prefix-")
    prefix = os.path.join(scratch, "prefix")
    os.makedirs(os.path.join(prefix, "bin"))
    os.makedirs(os.path.join(prefix, "share", "zoolander"))
    shutil.copy2(binary, os.path.join(prefix, "bin", "zoolander"))
    os.symlink(starter, os.path.join(prefix, "share", "zoolander", "config"))
    failed = []
    for name in selected:
        print(f"case {name}")
        home = tempfile.mkdtemp(prefix="zl-starter-home-")
        try:
            CASES[name](prefix, starter, home)
        except Exception as err:
            failed.append(name)
            print(f"  FAIL {type(err).__name__}: {err}")
    shutil.rmtree(scratch, ignore_errors=True)
    print("FAILED: " + ", ".join(failed) if failed else "all passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
