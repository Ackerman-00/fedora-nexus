zl.set_presentation({ direct_scanout = true })
zl.set_animations_enabled(false)
