zl.set_keyboard({ layout = "us,gb", options = "grp:alt_shift_toggle" })
zl.bind(0, zl.KEY_F1, function() zl.exec_command('echo fire >> "$XDG_RUNTIME_DIR/input-devices-e2e-fires"') end)
