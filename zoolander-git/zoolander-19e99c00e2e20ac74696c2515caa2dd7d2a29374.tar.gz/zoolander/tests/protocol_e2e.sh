#!/bin/bash
# Run every protocol_e2e.py test, then bind_all_globals.py, each against its own
# compositor, and require the compositor to survive the test and stop cleanly.
#
#   protocol_e2e.sh ZOOLANDER [test-name ...]
#
# The compositor takes the DRM device, so run this only in the project VM.
# LIBSEAT_BACKEND, SEATD_SOCK and ZL_E2E_CONNECTOR pass through from the caller.
set -u
bin=$(realpath "$1")
shift
here=$(cd "$(dirname "$0")" && pwd)
tests=("$@")
if [ ${#tests[@]} -eq 0 ]; then
	read -ra tests < <(python3 -c "import sys; sys.path.insert(0, '$here'); import protocol_e2e; print(*(t.__name__ for t in protocol_e2e.TESTS))")
	tests+=(bind_all_globals)
fi
failed=0
for test in "${tests[@]}"; do
	run=$(mktemp -d)
	mkdir -m700 "$run/rt" "$run/cfg"
	# A previous test may have unplugged it.
	if [ -n "${ZL_E2E_CONNECTOR:-}" ]; then echo on | sudo tee "$ZL_E2E_CONNECTOR/status" >/dev/null; fi
	XDG_RUNTIME_DIR="$run/rt" XDG_CONFIG_HOME="$run/cfg" "$bin" >"$run/log" 2>&1 &
	compositor=$!
	for _ in $(seq 1 40); do
		[ -S "$run/rt/wayland-0" ] && break
		sleep 0.5
	done
	if [ "$test" = bind_all_globals ]; then
		XDG_RUNTIME_DIR="$run/rt" WAYLAND_DISPLAY=wayland-0 python3 "$here/bind_all_globals.py"
	else
		XDG_RUNTIME_DIR="$run/rt" WAYLAND_DISPLAY=wayland-0 python3 "$here/protocol_e2e.py" "$test"
	fi
	rc=$?
	if kill -0 "$compositor" 2>/dev/null; then
		kill -TERM "$compositor"
		wait "$compositor"
		status=$?
		[ "$status" -eq 0 ] || { echo "FAIL $test: compositor stopped with status $status"; rc=1; }
	else
		wait "$compositor"
		echo "FAIL $test: compositor exited with status $? during the test"
		rc=1
	fi
	grep -m1 panic "$run/log" && rc=1
	if [ "$rc" -eq 0 ]; then rm -rf "$run"; else
		failed=1
		echo "log: $run/log"
	fi
done
if [ -n "${ZL_E2E_CONNECTOR:-}" ]; then echo detect | sudo tee "$ZL_E2E_CONNECTOR/status" >/dev/null; fi
exit "$failed"
