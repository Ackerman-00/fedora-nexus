#!/usr/bin/env python3
"""ext-workspace-v1 behaviour checks against a live compositor.

Run with WAYLAND_DISPLAY and XDG_RUNTIME_DIR pointing at zoolander, or
through run_workspace_protocol.sh inside the test VM. The unplug checks need
two outputs and UNPLUG naming a writable DRM connector status file (for
example /sys/class/drm/card0-Virtual-2/status); they are skipped when UNPLUG
is unset. Every workspace the script creates is removed again and the
connector is forced back on, so it can be rerun against the same session.
"""
import os
import struct
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bind_all_globals import DISPLAY, REGISTRY, Connection, message, read_string, string  # noqa: E402

MANAGER, GROUP, WORKSPACE, OUTPUT = "ext_workspace_manager_v1", "ext_workspace_group_handle_v1", "ext_workspace_handle_v1", "wl_output"
ACTIVE, HIDDEN = 1, 4
CAP_DEACTIVATE = 2


class Client:
    def __init__(self):
        self.conn = Connection()
        self.globals = {}
        self.kinds = {}
        self.next_id = 3
        self.manager = None
        self.groups = {}
        self.workspaces = {}
        self.output_names = {}
        self.events = []
        self.conn.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.sync()

    def bind(self, interface, version, name=None):
        if name is None:
            name = next(n for n, (i, _) in self.globals.items() if i == interface)
        advertised = self.globals[name][1]
        obj = self.next_id
        self.next_id += 1
        self.kinds[obj] = interface
        self.conn.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", min(version, advertised), obj)))
        if interface == MANAGER:
            self.manager = obj
        return obj

    def request(self, obj, opcode, payload=b""):
        self.conn.send(message(obj, opcode, payload))

    def sync(self):
        self.events = []
        callback = self.next_id
        self.next_id += 1
        self.conn.roundtrip(callback, self.on_event)

    def on_event(self, obj, opcode, body):
        kind = self.kinds.get(obj)
        self.events.append((kind, obj, opcode))
        if obj == REGISTRY and opcode == 0:
            (name,) = struct.unpack_from("<I", body)
            interface, at = read_string(body, 4)
            self.globals[name] = (interface, struct.unpack_from("<I", body, at)[0])
        elif obj == REGISTRY and opcode == 1:
            self.globals.pop(struct.unpack_from("<I", body)[0], None)
        elif kind == MANAGER and opcode in (0, 1):
            (new,) = struct.unpack_from("<I", body)
            if opcode == 0:
                self.kinds[new] = GROUP
                self.groups[new] = {"outputs": set(), "workspaces": set(), "removed": False}
            else:
                self.kinds[new] = WORKSPACE
                self.workspaces[new] = {"name": None, "state": 0, "caps": 0}
        elif kind == GROUP:
            group = self.groups[obj]
            if opcode in (1, 2, 3, 4):
                (arg,) = struct.unpack_from("<I", body)
                target = group["outputs" if opcode in (1, 2) else "workspaces"]
                (target.add if opcode in (1, 3) else target.discard)(arg)
            elif opcode == 5:
                group["removed"] = True
        elif kind == WORKSPACE:
            ws = self.workspaces[obj]
            if opcode == 1:
                ws["name"], _ = read_string(body, 0)
            elif opcode in (3, 4):
                ws["state" if opcode == 3 else "caps"] = struct.unpack_from("<I", body)[0]
        elif kind == OUTPUT and opcode == 4:
            self.output_names[obj], _ = read_string(body, 0)

    def group_of(self, workspace):
        return next((g for g, value in self.groups.items() if workspace in value["workspaces"]), None)

    def named(self, name):
        return [w for w, value in self.workspaces.items() if value["name"] == name and self.group_of(w) is not None]

    def create(self, group, name):
        before = set(self.workspaces)
        self.request(group, 0, string(name))
        self.request(self.manager, 0)
        self.sync()
        return [w for w in self.workspaces if w not in before]

    def remove_named(self, names):
        for name in names:
            for workspace in self.named(name):
                self.request(workspace, 4)
        self.request(self.manager, 0)
        self.sync()


TEST_NAMES = ("wf-fresh", "special:wf", "wf-assign", "wf-parked")


failures = []


def check(label, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + label + (f": {detail}" if detail and not ok else ""))
    if not ok:
        failures.append(label)


def output_enter_after_late_bind(label):
    """A bar binds the manager before wl_output; every group must still get output_enter."""
    client = Client()
    client.bind(MANAGER, 1)
    client.sync()
    outputs = [client.bind(OUTPUT, 4, name) for name, (i, _) in sorted(client.globals.items()) if i == OUTPUT]
    client.sync()
    live = [g for g, value in client.groups.items() if value["outputs"]]
    check(label, len(live) == len(outputs) and all(len(value["outputs"]) <= 1 and value["outputs"] <= set(outputs) for value in client.groups.values()),
          f"{len(outputs)} outputs, groups {client.groups}")


def create_requests(client):
    group = next(g for g, value in client.groups.items() if value["outputs"])
    existing = next(w for w in client.groups[group]["workspaces"] if not client.workspaces[w]["state"] & HIDDEN)
    name = client.workspaces[existing]["name"]
    check("create_workspace with an existing name is ignored", client.create(group, name) == [], f"name {name!r}")
    fresh = client.create(group, "wf-fresh")
    check("create_workspace with a new name adds one regular workspace", len(fresh) == 1 and client.workspaces[fresh[0]]["caps"] & CAP_DEACTIVATE == 0, str([client.workspaces[w] for w in fresh]))
    special = client.create(group, "special:wf")
    ok = len(special) == 1 and client.workspaces[special[0]]["caps"] & CAP_DEACTIVATE != 0 and client.workspaces[special[0]]["state"] & HIDDEN != 0
    check("create_workspace special:<name> adds a hidden scratchpad", ok, str([client.workspaces[w] for w in special]))
    check("create_workspace with an existing scratchpad name is ignored", client.create(group, "special:wf") == [])


def assign_ignored(client):
    live = [g for g, value in client.groups.items() if value["outputs"]]
    if len(live) < 2:
        print("SKIP assign: needs two outputs")
        return
    source, target = live
    moving = client.create(source, "wf-assign")[0]
    client.request(moving, 3, struct.pack("<I", target))
    client.request(client.manager, 0)
    client.sync()
    moved = [e for e in client.events if e[0] == GROUP and e[2] in (3, 4)]
    check("assign request is ignored", moved == [] and client.group_of(moving) == source, f"events {moved}")


def set_connector(client, unplug, value, settled):
    # A forced connector state raises no uevent, so announce the change by hand.
    subprocess.run(["sudo", "-n", "sh", "-c", f"echo {value} > {unplug}"], check=True)
    subprocess.run(["sudo", "-n", "udevadm", "trigger", "--action=change", "--subsystem-match=drm"], check=True)
    deadline = time.time() + 10
    while time.time() < deadline:
        client.sync()
        if settled():
            return
        time.sleep(0.2)


def unplug_checks(client, unplug):
    live = [g for g, value in client.groups.items() if value["outputs"]]
    if len(live) < 2 or not unplug:
        print("SKIP unplug checks: needs two outputs and UNPLUG")
        return
    names = {g: {client.output_names.get(o) for o in client.groups[g]["outputs"]} for g in live}
    connector = os.path.basename(os.path.dirname(unplug)).split("-", 1)[1]
    parked_group = next(g for g in live if connector in names[g])
    primary = next(g for g in live if g != parked_group)
    parked = client.create(parked_group, "wf-parked")[0]
    # Holds the registry from before the unplug so it can still bind the departing output's name.
    stale = Client()
    stale.bind(MANAGER, 1)
    stale.sync()
    try:
        set_connector(client, unplug, "off", lambda: not client.groups[parked_group]["outputs"])
        check("unplugged output leaves its group", not client.groups[parked_group]["outputs"])
        departed = next(n for n, (i, _) in stale.globals.items() if i == OUTPUT and n not in client.globals)
        late = stale.bind(OUTPUT, 4, departed)
        stale.sync()
        entered = [value["outputs"] for value in stale.groups.values() if late in value["outputs"]]
        check("wl_output bound after its group left gets no output_enter", entered == [], f"groups {stale.groups}")
        client.request(parked, 1)
        client.request(client.manager, 0)
        client.sync()
        state = client.workspaces[parked]["state"]
        check("activating a parked workspace shows it on a live output", client.group_of(parked) == primary and state & ACTIVE != 0,
              f"group {client.group_of(parked)} (primary {primary}), state {state}")
    finally:
        bound = {name for name, (i, _) in client.globals.items() if i == OUTPUT}
        set_connector(client, unplug, "on", lambda: any(i == OUTPUT and n not in bound for n, (i, _) in client.globals.items()))
    for name in [n for n, (i, _) in client.globals.items() if i == OUTPUT and n not in bound]:
        client.bind(OUTPUT, 4, name)
    client.sync()
    check("replugged output rejoins its group", bool(client.groups[parked_group]["outputs"]), f"groups {client.groups}")
    output_enter_after_late_bind("manager bound before wl_output after replug: groups get output_enter")


def main():
    output_enter_after_late_bind("manager bound before wl_output: groups get output_enter")
    client = Client()
    outputs = [client.bind(OUTPUT, 4, name) for name, (i, _) in sorted(client.globals.items()) if i == OUTPUT]
    client.bind(MANAGER, 1)
    client.sync()
    entered = sorted(o for value in client.groups.values() for o in value["outputs"])
    check("wl_output bound before manager: groups get output_enter", entered == outputs, f"outputs {outputs}, entered {entered}")
    try:
        create_requests(client)
        assign_ignored(client)
        unplug_checks(client, os.environ.get("UNPLUG"))
    finally:
        client.remove_named(TEST_NAMES)
    left = [name for name in TEST_NAMES if client.named(name)]
    check("test workspaces are removed again", left == [], f"left {left}")
    print("RESULT: " + ("all passed" if not failures else f"{len(failures)} failed"))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
