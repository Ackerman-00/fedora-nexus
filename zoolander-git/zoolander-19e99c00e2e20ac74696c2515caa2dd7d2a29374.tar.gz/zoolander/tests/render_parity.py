#!/usr/bin/env python3
"""Scene-drawing checks against a live zoolander, from raw Wayland wire.

Each scenario starts its own compositor (the binary given with --compositor)
with a scenario config, drives it as a client, takes a screenshot with grim
and checks pixels or protocol events. Needs a seat (seatd) and a DRM device:
run it inside the test VM, never on a desktop session.

    render_parity.py --compositor ./zoolander [--shots DIR] [scenario...]
"""
import argparse
import array
import mmap
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time

RED, GREEN, BLUE = (255, 0, 0), (0, 255, 0), (0, 0, 255)
YELLOW, MAGENTA, CYAN, WHITE, BLACK = (255, 255, 0), (255, 0, 255), (0, 255, 255), (255, 255, 255), (0, 0, 0)
BLUE_BORDER = (0, 0, 160)

BASE_CONFIG = """
zl.set_animations_enabled(false)
zl.set_layout("floating")
zl.set_window_style({ gaps_in = 0, gaps_out = 0, border_size = 2, rounding = 20, rounding_power = 2,
    active_border = "#ff0000ff", active_border_end = "#ff0000ff", inactive_border = "#ff0000ff", inactive_border_end = "#ff0000ff",
    active_opacity = 1.0, inactive_opacity = 1.0, fullscreen_opacity = 1.0, shadow = { enabled = false } })
zl.set_ssd({ enabled = true, floating_workspaces_only = false, include_floating_windows = true, follow_theme = false, show_title = false,
    border = 2, titlebar = 30, active_titlebar = "#00ff00ff", inactive_titlebar = "#00ff00ff" })
zl.set_blur({ enabled = false })
zl.set_dim({ inactive = false, strength = 0, special = 0, around = 0 })
"""

DRAG_STYLE = """
zl.set_window_style({ gaps_in = 0, gaps_out = 0, border_size = 4, rounding = 0, rounding_power = 2,
    active_border = "#ff0000ff", active_border_end = "#ff0000ff", inactive_border = "#0000a0ff", inactive_border_end = "#0000a0ff",
    active_opacity = 1.0, inactive_opacity = 1.0, fullscreen_opacity = 1.0, shadow = { enabled = false } })
zl.set_ssd({ enabled = true, floating_workspaces_only = false, include_floating_windows = true, follow_theme = false, show_title = true,
    border = 4, titlebar = 30, active_titlebar = "#00ff00ff", inactive_titlebar = "#00ff00ff", title_align = "right",
    title_color = "#ffffffff", inactive_title_color = "#ffffffff", title_font_size = 18,
    active_border = "#ff0000ff", active_border_end = "#ff0000ff", inactive_border = "#0000a0ff", inactive_border_end = "#0000a0ff" })
"""


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


def u32(*values):
    return struct.pack("<" + "I" * len(values), *values)


def i32(*values):
    return struct.pack("<" + "i" * len(values), *values)


class Client:
    """A minimal client: objects are integers, events go to per-object handlers."""

    def __init__(self, runtime, display):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(os.path.join(runtime, display))
        self.buffer = b""
        self.next_id = 2
        self.handlers = {}
        self.globals = {}
        self.events = []
        registry = self.new(lambda op, body: self._global(op, body))
        self.send(message(1, 1, u32(registry)))
        self.registry = registry
        self.roundtrip()

    def _global(self, op, body):
        if op == 0:
            (name,) = struct.unpack_from("<I", body)
            interface, at = read_string(body, 4)
            (version,) = struct.unpack_from("<I", body, at)
            self.globals[interface] = (name, version)

    def new(self, handler=None):
        obj = self.next_id
        self.next_id += 1
        self.handlers[obj] = handler
        return obj

    def bind(self, interface, version, handler=None):
        name, advertised = self.globals[interface]
        obj = self.new(handler)
        self.send(message(self.registry, 0, u32(name) + string(interface) + u32(min(version, advertised), obj)))
        return obj

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
        else:
            self.sock.sendall(data)

    def dispatch_until(self, done, timeout=5.0):
        deadline = time.monotonic() + timeout
        while not done():
            while len(self.buffer) >= 8:
                obj, word = struct.unpack_from("<II", self.buffer)
                size = word >> 16
                if len(self.buffer) < size:
                    break
                body, self.buffer = self.buffer[8:size], self.buffer[size:]
                opcode = word & 0xFFFF
                if obj == 1 and opcode == 0:
                    failed, code = struct.unpack_from("<II", body)
                    text, _ = read_string(body, 8)
                    raise RuntimeError(f"protocol error on object {failed} code {code}: {text}")
                self.events.append((obj, opcode, body))
                handler = self.handlers.get(obj)
                if handler:
                    handler(opcode, body)
                if done():
                    return
            if time.monotonic() > deadline:
                raise TimeoutError("compositor did not answer in time")
            self.sock.settimeout(max(deadline - time.monotonic(), 0.01))
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * 4))
            for level, kind, payload in ancillary:
                if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                    for fd in array.array("i", payload[:len(payload) - len(payload) % 4]):
                        os.close(fd)
            if not data:
                raise ConnectionError("compositor closed the connection")
            self.buffer += data

    def roundtrip(self):
        state = {"done": False}
        callback = self.new(lambda op, body: state.update(done=True))
        self.send(message(1, 0, u32(callback)))
        self.dispatch_until(lambda: state["done"])

    def buffer_of(self, shm, width, height, paint, format=0):
        """An ARGB8888 (or XRGB8888 with format=1) buffer whose pixel (x, y) is
        paint(x, y) -> (r, g, b, a), premultiplied."""
        stride = width * 4
        size = stride * height
        fd = os.memfd_create("render-parity")
        os.ftruncate(fd, size)
        with mmap.mmap(fd, size) as data:
            pixels = bytearray(size)
            for y in range(height):
                for x in range(width):
                    r, g, b, a = paint(x, y)
                    at = y * stride + x * 4
                    pixels[at:at + 4] = bytes((b, g, r, a))
            data[:] = pixels
        pool = self.new()
        self.send(message(shm, 0, u32(pool) + i32(size)), fds=[fd])
        os.close(fd)
        buffer = self.new()
        self.send(message(pool, 0, u32(buffer) + i32(0, width, height, stride) + u32(format)))
        self.send(message(pool, 1))
        return buffer


def solid(color, alpha=255):
    r, g, b = color
    return lambda x, y: (r * alpha // 255, g * alpha // 255, b * alpha // 255, alpha)


class Scene:
    """Globals every scenario uses, plus helpers that map roles and wait for configures."""

    def __init__(self, client):
        self.c = client
        self.compositor = client.bind("wl_compositor", 6)
        self.shm = client.bind("wl_shm", 1)
        self.wm_base = client.bind("xdg_wm_base", 5, self._ping)
        self.decorations = client.bind("zxdg_decoration_manager_v1", 1) if "zxdg_decoration_manager_v1" in client.globals else None
        self.layer_shell = client.bind("zwlr_layer_shell_v1", 4) if "zwlr_layer_shell_v1" in client.globals else None

    def _ping(self, op, body):
        if op == 0:
            self.c.send(message(self.wm_base, 3, body[:4]))

    def surface(self, handler=None):
        surface = self.c.new(handler)
        self.c.send(message(self.compositor, 0, u32(surface)))
        return surface

    def toplevel(self, width, height, paint, server_side=True, title="render-parity"):
        surface = self.surface()
        configured = {"serial": None}
        xdg = self.c.new(lambda op, body: configured.update(serial=struct.unpack_from("<I", body)[0]) if op == 0 else None)
        self.c.send(message(self.wm_base, 2, u32(xdg, surface)))
        top = self.c.new()
        self.c.send(message(xdg, 1, u32(top)))
        self.c.send(message(top, 2, string(title)))
        self.c.send(message(top, 3, string(title)))
        if server_side and self.decorations:
            deco = self.c.new()
            self.c.send(message(self.decorations, 1, u32(deco, top)))
            self.c.send(message(deco, 1, u32(2)))
        self.c.send(message(surface, 6))
        self.c.dispatch_until(lambda: configured["serial"] is not None)
        self.c.send(message(xdg, 4, u32(configured["serial"])))
        self.c.send(message(surface, 1, u32(self.c.buffer_of(self.shm, width, height, paint)) + i32(0, 0)))
        self.c.send(message(surface, 9, i32(0, 0, width, height)))
        self.c.send(message(surface, 6))
        self.c.roundtrip()
        return {"surface": surface, "xdg": xdg, "toplevel": top}

    def positioner(self, width, height, anchor_rect, offset=(0, 0)):
        positioner = self.c.new()
        self.c.send(message(self.wm_base, 1, u32(positioner)))
        self.c.send(message(positioner, 1, i32(width, height)))
        self.c.send(message(positioner, 2, i32(*anchor_rect)))
        self.c.send(message(positioner, 3, u32(5)))  # anchor top_left
        self.c.send(message(positioner, 4, u32(8)))  # gravity bottom_right
        self.c.send(message(positioner, 6, i32(*offset)))
        return positioner

    def popup(self, parent_xdg, positioner, buffer_size, paint, geometry=None, layer=None):
        """A popup on an xdg parent, or on a layer surface when `layer` is given."""
        surface = self.surface()
        configured = {"serial": None, "box": None}

        def on_xdg(op, body):
            if op == 0:
                configured["serial"] = struct.unpack_from("<I", body)[0]

        def on_popup(op, body):
            if op == 0:
                configured["box"] = struct.unpack_from("<iiii", body)

        xdg = self.c.new(on_xdg)
        self.c.send(message(self.wm_base, 2, u32(xdg, surface)))
        popup = self.c.new(on_popup)
        self.c.send(message(xdg, 2, u32(popup, parent_xdg or 0, positioner)))
        if layer is not None:
            self.c.send(message(layer, 5, u32(popup)))
        if geometry:
            self.c.send(message(xdg, 3, i32(*geometry)))
        self.c.send(message(surface, 6))
        self.c.dispatch_until(lambda: configured["serial"] is not None)
        self.c.send(message(xdg, 4, u32(configured["serial"])))
        width, height = buffer_size
        self.c.send(message(surface, 1, u32(self.c.buffer_of(self.shm, width, height, paint)) + i32(0, 0)))
        self.c.send(message(surface, 9, i32(0, 0, width, height)))
        self.c.send(message(surface, 6))
        self.c.roundtrip()
        return {"surface": surface, "xdg": xdg, "popup": popup, "box": configured["box"]}

    def layer(self, kind, namespace, width, height, anchor, paint, keyboard=0):
        surface = self.surface()
        configured = {"serial": None}

        def on_layer(op, body):
            if op == 0:
                serial, w, h = struct.unpack_from("<III", body)
                configured.update(serial=serial, width=w or width, height=h or height)

        layer = self.c.new(on_layer)
        self.c.send(message(self.layer_shell, 0, u32(layer, surface, 0, kind) + string(namespace)))
        self.c.send(message(layer, 0, u32(width, height)))
        self.c.send(message(layer, 1, u32(anchor)))
        self.c.send(message(layer, 4, u32(keyboard)))
        self.c.send(message(surface, 6))
        self.c.dispatch_until(lambda: configured["serial"] is not None)
        self.c.send(message(layer, 6, u32(configured["serial"])))
        width, height = configured["width"], configured["height"]
        self.c.send(message(surface, 1, u32(self.c.buffer_of(self.shm, width, height, paint)) + i32(0, 0)))
        self.c.send(message(surface, 9, i32(0, 0, width, height)))
        self.c.send(message(surface, 6))
        self.c.roundtrip()
        return {"surface": surface, "layer": layer}


class Image:
    def __init__(self, data):
        assert data.startswith(b"P6"), "grim did not write a PPM"
        fields = []
        at = 2
        while len(fields) < 3:
            while data[at:at + 1].isspace():
                at += 1
            end = at
            while not data[end:end + 1].isspace():
                end += 1
            fields.append(int(data[at:end]))
            at = end
        self.width, self.height, _ = fields
        self.pixels = data[at + 1:]

    def at(self, x, y):
        i = (y * self.width + x) * 3
        return tuple(self.pixels[i:i + 3])

    def find(self, color, tolerance=8):
        """Bounding box (x0, y0, x1, y1) of pixels close to `color`, or None."""
        xs, ys = [], []
        for y in range(0, self.height):
            row = self.pixels[y * self.width * 3:(y + 1) * self.width * 3]
            for x in range(self.width):
                p = row[x * 3:x * 3 + 3]
                if all(abs(p[k] - color[k]) <= tolerance for k in range(3)):
                    xs.append(x)
                    ys.append(y)
        if not xs:
            return None
        return min(xs), min(ys), max(xs), max(ys)

    def count(self, color, box, tolerance=8):
        x0, y0, x1, y1 = box
        n = 0
        for y in range(max(y0, 0), min(y1, self.height)):
            for x in range(max(x0, 0), min(x1, self.width)):
                p = self.at(x, y)
                if all(abs(p[k] - color[k]) <= tolerance for k in range(3)):
                    n += 1
        return n


def near(p, color, tolerance=24):
    return all(abs(p[k] - color[k]) <= tolerance for k in range(3))


class Compositor:
    def __init__(self, binary, config, workdir, args=(), files=None):
        self.runtime = os.path.join(workdir, "rt")
        os.makedirs(self.runtime, mode=0o700)
        conf = os.path.join(workdir, "cfg", "zoolander")
        os.makedirs(conf)
        for name, text in (files or {}).items():
            os.makedirs(os.path.dirname(os.path.join(workdir, "cfg", name)), exist_ok=True)
            with open(os.path.join(workdir, "cfg", name), "w") as f:
                f.write(text)
        with open(os.path.join(conf, "init.lua"), "w") as f:
            f.write(BASE_CONFIG + config)
        env = dict(os.environ, XDG_RUNTIME_DIR=self.runtime, XDG_CONFIG_HOME=os.path.join(workdir, "cfg"),
                   LIBSEAT_BACKEND="seatd", SEATD_SOCK="/run/seatd.sock", XDG_SESSION_TYPE="wayland")
        env.pop("WAYLAND_DISPLAY", None)
        self.log = open(os.path.join(workdir, "compositor.log"), "w")
        self.proc = subprocess.Popen([binary, *args], env=env, stdout=self.log, stderr=subprocess.STDOUT)
        for _ in range(100):
            names = [n for n in os.listdir(self.runtime) if n.startswith("wayland-") and not n.endswith(".lock")]
            if names:
                self.display = names[0]
                break
            time.sleep(0.1)
        else:
            raise RuntimeError("compositor socket never appeared")
        time.sleep(1.0)
        self.env = dict(os.environ, XDG_RUNTIME_DIR=self.runtime, WAYLAND_DISPLAY=self.display)

    def client(self):
        return Client(self.runtime, self.display)

    def ctl(self, lua):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect(os.path.join(self.runtime, f"zoolander-{self.display}.sock"))
        sock.sendall(f"eval {lua}\n".encode())
        sock.shutdown(socket.SHUT_WR)
        reply = b""
        while chunk := sock.recv(4096):
            reply += chunk
        return reply.decode()

    def shot(self, save=None, output=None):
        time.sleep(0.4)
        data = subprocess.run(["grim", *(["-o", output] if output else []), "-t", "ppm", "-"], env=self.env, check=True, capture_output=True).stdout
        if save:
            with open(save, "wb") as f:
                f.write(data)
        return Image(data)

    def stop(self):
        self.proc.terminate()
        try:
            self.proc.wait(5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()
        self.log.close()


def ssd_corners(comp, shot):
    """The titlebar stays inside the border's inner curve: on the corner diagonal the
    ring between radius r - border and r is border, never titlebar."""
    scene = Scene(comp.client())
    scene.toplevel(300, 200, solid(BLUE))
    image = shot()
    box = image.find(RED)
    assert box, "no border found"
    x0, y0, x1, y1 = box
    rounding, border = 20, 2
    bad = []
    for cx, cy, sx, sy in ((x0 + rounding, y0 + rounding, -1, -1), (x1 + 1 - rounding, y0 + rounding, 1, -1)):
        for d10 in range(int((rounding - border + 0.5) * 10), int((rounding - 0.5) * 10) + 1, 3):
            d = d10 / 10 / 2 ** 0.5
            x, y = int(cx + sx * d), int(cy + sy * d)
            p = image.at(x, y)
            if near(p, GREEN, 60):
                bad.append((x, y, p))
    assert not bad, f"titlebar paints over the border ring at {bad[:4]}"
    return f"window {box}: corner ring is border/background, no titlebar"


def popup_geometry(comp, shot):
    """A popup is drawn through its xdg window geometry: its margins stay off screen
    and the geometry box keeps its 1:1 size."""
    scene = Scene(comp.client())
    window = scene.toplevel(400, 300, solid(BLUE))

    def paint(x, y):
        return (*YELLOW, 255) if 20 <= x < 120 and 20 <= y < 80 else (*MAGENTA, 255)

    scene.popup(window["xdg"], scene.positioner(100, 60, (40, 40, 1, 1)), (140, 100), paint, geometry=(20, 20, 100, 60))
    image = shot()
    magenta = image.find(MAGENTA)
    yellow = image.find(YELLOW)
    assert yellow, "popup not drawn"
    w, h = yellow[2] - yellow[0] + 1, yellow[3] - yellow[1] + 1
    assert magenta is None, f"popup margins drawn at {magenta}"
    assert (w, h) == (100, 60), f"popup geometry drawn {w}x{h}, want 100x60"
    return f"popup geometry box {yellow} is 100x60 with no margins"


def popup_hidden_parent(comp, shot):
    """A popup belongs to its window: on another workspace neither shows."""
    scene = Scene(comp.client())
    window = scene.toplevel(400, 300, solid(BLUE))
    scene.popup(window["xdg"], scene.positioner(100, 60, (40, 40, 1, 1)), (100, 60), solid(YELLOW))
    before = shot()
    assert before.find(YELLOW), "popup not drawn while its window shows"
    reply = comp.ctl('zl.workspace("2")')
    scene.c.roundtrip()
    image = shot()
    assert image.find(BLUE) is None, f"window still drawn after switching workspace ({reply.strip()})"
    yellow = image.find(YELLOW)
    assert yellow is None, f"popup of a hidden window drawn at {yellow}"
    return "popup hidden with its window on workspace 2"


def layer_popup_order(comp, shot):
    """A bottom-layer surface's popup sits with its layer, below windows."""
    scene = Scene(comp.client())
    bar = scene.layer(1, "parity-dock", 120, 40, 1, solid(CYAN))
    scene.popup(None, scene.positioner(120, 120, (0, 0, 1, 1), (0, 250)), (120, 120), solid(YELLOW), layer=bar["layer"])
    shown = shot().find(YELLOW)
    assert shown, "layer popup not drawn"
    scene.toplevel(800, 600, solid(BLUE))
    image = shot()
    left = image.count(YELLOW, (shown[0], shown[1], shown[2] + 1, shown[3] + 1))
    window = image.find(BLUE)
    covered = window and window[0] <= shown[0] and window[1] <= shown[1] and window[2] >= shown[2] and window[3] >= shown[3]
    assert covered, f"window {window} does not cover the popup {shown}"
    assert left == 0, f"{left} popup pixels drawn above the window"
    return f"bottom-layer popup {shown} hidden under window {window}"


def layer_blur_scope(comp, shot):
    """Global blur reaches a layer only through a blur rule: a translucent overlay
    without one leaves a sharp backdrop."""
    scene = Scene(comp.client())
    scene.toplevel(600, 400, lambda x, y: (*(WHITE if (x // 2 + y // 2) % 2 else BLACK), 255), server_side=False)
    # The window opens under the pointer, which is not the centre of a
    # multi-output layout.
    x0, y0, x1, y1 = shot().find(WHITE)
    cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
    scene.layer(3, "parity-overlay", 0, 0, 1 | 2 | 4 | 8, lambda x, y: (0, 0, 0, 64))
    image = shot()
    contrast = 0
    for y in range(cy - 40, cy + 40):
        for x in range(cx - 40, cx + 40):
            contrast = max(contrast, abs(image.at(x, y)[0] - image.at(x + 2, y)[0]))
    assert contrast > 100, f"backdrop under the overlay is blurred (max contrast {contrast})"
    return f"backdrop under an unruled overlay stays sharp (contrast {contrast})"


def inactive_dim(comp, shot):
    """The inactive dim covers the whole frame, and keyboard focus on a layer surface
    keeps the output's focused window undimmed."""
    scene = Scene(comp.client())
    scene.toplevel(300, 200, solid(BLUE), title="first")
    comp.ctl("zl.move_floating(-350, 0)")
    scene.toplevel(300, 200, solid(BLUE), title="second")
    image = shot()
    border_colors = sorted({image.at(x, y) for (x, y) in border_samples(image)})
    assert any(near(p, (128, 0, 0), 30) for p in border_colors), f"unfocused border not dimmed: {border_colors}"
    assert any(near(p, RED, 30) for p in border_colors), f"focused border lost: {border_colors}"
    scene.layer(2, "parity-launcher", 100, 100, 1, solid(CYAN), keyboard=1)
    image = shot()
    border_colors = sorted({image.at(x, y) for (x, y) in border_samples(image)})
    assert any(near(p, RED, 30) for p in border_colors), f"every window dimmed while a layer has focus: {border_colors}"
    return f"border colours {border_colors}"


def border_samples(image):
    """Midpoints of the left border column of every red-ish frame on screen."""
    samples = []
    for y in (image.height // 2,):
        x = 0
        while x < image.width:
            p = image.at(x, y)
            if p[0] > 90 and p[1] < 30 and p[2] < 30:
                samples.append((x, y))
                x += 4
            x += 1
    return samples


def surface_leave_hidden(comp, shot):
    """A window on an inactive workspace leaves its output."""
    client = comp.client()
    scene = Scene(client)
    # The window opens on the focused output, which need not be the last one advertised.
    for obj, op, body in client.events:
        if obj == client.registry and op == 0 and read_string(body, 4)[0] == "wl_output":
            client.send(message(client.registry, 0, body[:4] + string("wl_output") + u32(4, client.new())))
    state = {"enter": 0, "leave": 0}
    window = scene.toplevel(300, 200, solid(BLUE))
    surface = window["surface"]
    def on_surface(op, body):
        if op < 2:
            state[("enter", "leave")[op]] += 1

    client.handlers[surface] = on_surface
    for obj, op, body in client.events:
        if obj == surface:
            on_surface(op, body)
    client.roundtrip()
    assert state["enter"] >= 1, f"surface never entered an output: {state}"
    comp.ctl('zl.workspace("2")')
    time.sleep(0.5)
    client.roundtrip()
    assert state["leave"] >= 1, f"hidden window never left its output: {state}"
    return f"events {state}"


def pointer_to(client, x, y, extent):
    """Moves the seat pointer to layout point (x, y) through a virtual pointer."""
    if not hasattr(client, "virtual_pointer"):
        manager = client.bind("zwlr_virtual_pointer_manager_v1", 1)
        client.virtual_pointer = client.new()
        client.send(message(manager, 0, u32(0, client.virtual_pointer)))
    client.send(message(client.virtual_pointer, 1, u32(int(time.monotonic() * 1000) & 0xFFFFFFFF, x, y, *extent)))
    client.send(message(client.virtual_pointer, 4))
    client.roundtrip()


def popup_hit_topmost(comp, shot):
    """Of two overlapping popups the one mapped last takes the pointer."""
    client = comp.client()
    scene = Scene(client)
    seat = client.bind("wl_seat", 5)
    entered = []
    pointer = client.new(lambda op, body: entered.append(struct.unpack_from("<I", body, 4)[0]) if op == 0 else None)
    client.send(message(seat, 0, u32(pointer)))
    window = scene.toplevel(400, 300, solid(BLUE))
    below = scene.popup(window["xdg"], scene.positioner(100, 100, (20, 20, 1, 1)), (100, 100), solid(YELLOW))
    above = scene.popup(below["xdg"], scene.positioner(60, 60, (40, 40, 1, 1)), (60, 60), solid(MAGENTA))
    image = shot()
    box = image.find(MAGENTA)
    assert box and image.find(YELLOW), "popups not drawn"
    pointer_to(client, (box[0] + box[2]) // 2, (box[1] + box[3]) // 2, (image.width, image.height))
    client.dispatch_until(lambda: entered, 2.0)
    names = {below["surface"]: "first popup", above["surface"]: "second popup", window["surface"]: "window"}
    assert entered[-1] == above["surface"], f"pointer entered the {names.get(entered[-1], entered[-1])}"
    return f"pointer at {box} entered the second popup"


def ime_popup_over_overlay(comp, shot):
    """An input-method popup draws above overlay layer surfaces."""
    client = comp.client()
    scene = Scene(client)
    seat = client.bind("wl_seat", 5)
    methods = client.bind("zwp_input_method_manager_v2", 1)
    text_inputs = client.bind("zwp_text_input_manager_v3", 1)
    state = {"enter": False, "activate": False, "done": 0}
    method = client.new(lambda op, body: state.update(activate=state["activate"] or op == 0, done=state["done"] + (op == 5)))
    client.send(message(methods, 0, u32(seat, method)))
    text_input = client.new(lambda op, body: state.update(enter=True) if op == 0 else None)
    client.send(message(text_inputs, 1, u32(text_input, seat)))
    scene.toplevel(400, 300, solid(BLUE))
    client.dispatch_until(lambda: state["enter"])
    client.send(message(text_input, 1))
    client.send(message(text_input, 6, i32(20, 20, 1, 20)))
    client.send(message(text_input, 7))
    client.dispatch_until(lambda: state["activate"] and state["done"])
    client.send(message(method, 3, u32(state["done"])))
    surface = scene.surface()
    client.send(message(method, 4, u32(client.new(), surface)))
    client.send(message(surface, 1, u32(client.buffer_of(scene.shm, 80, 40, solid(CYAN))) + i32(0, 0)))
    client.send(message(surface, 9, i32(0, 0, 80, 40)))
    client.send(message(surface, 6))
    client.roundtrip()
    popup = shot().find(CYAN)
    assert popup, "input-method popup not drawn"
    scene.layer(3, "parity-overlay", 0, 0, 1 | 2 | 4 | 8, solid(WHITE))
    image = shot()
    left = image.count(CYAN, (popup[0], popup[1], popup[2] + 1, popup[3] + 1))
    area = (popup[2] - popup[0] + 1) * (popup[3] - popup[1] + 1)
    assert image.find(BLUE) is None, "overlay does not cover the window"
    assert left == area, f"only {left} of {area} popup pixels drawn above the overlay"
    white = image.count(WHITE, (0, 0, image.width, image.height))
    for action in ("commands", "windows"):
        reply = comp.ctl(f'return zl.layout("{action}")')
        image = shot()
        assert image.count(WHITE, (0, 0, image.width, image.height)) < white // 2, f"{action} sheet not shown ({reply.strip()})"
        left = image.count(CYAN, (popup[0], popup[1], popup[2] + 1, popup[3] + 1))
        assert left == area, f"only {left} of {area} popup pixels drawn above the {action} sheet ({reply.strip()})"
        comp.ctl(f'return zl.layout("{action}")')
    return f"popup {popup} stays above a full-screen overlay, the command sheet and the window picker"


def resize_keeps_tiled_shadow(comp, shot):
    """A tiled window being resized keeps its shadow; only a moved window drops it."""
    client = comp.client()
    scene = Scene(client)
    scene.toplevel(300, 200, solid(BLUE), server_side=False)
    before = shot()
    window = before.find(BLUE)
    assert window, "window not drawn"
    band = (window[0] - 30, window[1] + 20, window[0] - 2, window[3] - 20)
    dark = lambda image: sum(1 for y in range(band[1], band[3]) for x in range(band[0], band[2]) if image.at(x, y)[0] < 25)
    assert dark(before) > 100, f"no shadow left of the tiled window {window}"
    pointer_to(client, window[2] - 20, window[3] - 20, (before.width, before.height))
    reply = comp.ctl("return zl.begin_resize()")
    pointer_to(client, window[2] - 60, window[3] - 60, (before.width, before.height))
    during = shot()
    assert dark(during) > 100, f"shadow dropped while resizing ({reply.strip()})"
    return f"{dark(during)} shadow pixels left of the window while resizing"


def drag_onto_output(comp, extent):
    """A focused window whose right part is dragged onto HEADLESS-2 while a top-layer
    surface holds keyboard focus. Returns the client so the window stays alive."""
    client = comp.client()
    scene = Scene(client)
    scene.toplevel(300, 200, solid(BLUE), title="WWW")
    scene.layer(2, "parity-launcher", 40, 40, 1 | 4, solid(CYAN), keyboard=1)
    first = comp.shot(output="HEADLESS-1")
    bar = first.find(GREEN, 40)
    assert bar, "titlebar not found"
    x, y = (bar[0] + bar[2]) // 2, (bar[1] + bar[3]) // 2
    pointer_to(client, x, y, extent)
    reply = comp.ctl("zl.begin_move()")
    for step in range(1, 11):
        pointer_to(client, x + (900 - bar[2]) * step // 10, y, extent)
    return client, reply


TILED_SHADOW = """
zl.set_layout("dwindle")
zl.set_window_style({ gaps_in = 0, gaps_out = 80, border_size = 2, rounding = 0, rounding_power = 2,
    active_border = "#ff0000ff", active_border_end = "#ff0000ff", inactive_border = "#ff0000ff", inactive_border_end = "#ff0000ff",
    active_opacity = 1.0, inactive_opacity = 1.0, fullscreen_opacity = 1.0,
    shadow = { enabled = true, range = 40, render_power = 1, color = "#000000ff", color_inactive = "#000000ff" } })
zl.set_ssd(false)
"""
THEME = {
    "otter-shell/theme.conf": "colors_path = colors.conf\nlayout_path = layout.conf\nspacing_path = spacing.conf\n",
    "otter-shell/colors.conf": "foreground = \"#ff00ff\"\nmuted = \"#ff00ff\"\n",
    "otter-shell/layout.conf": "",
    "otter-shell/spacing.conf": "",
}
TWO_OUTPUTS = ("--headless", "--headless-size=800x600", "--headless-size2=800x600")
TWO_OUTPUT_CONFIG = 'zl.output_rule({ output = "HEADLESS-2", width = 800, height = 600, refresh = 60, x = 800, y = 0, scale = 2 })\n'


def drag_focus_restyle(comp, shot):
    """While a layer surface holds keyboard focus, a window dragged onto another output
    takes that output's focus styling there: it has no focused window, so the part of
    the frame on it is drawn inactive."""
    client, reply = drag_onto_output(comp, (1200, 600))
    image = comp.shot(output="HEADLESS-2")
    home = comp.shot(output="HEADLESS-1")
    assert home.find(RED, 40), f"frame on the home output lost its focused border ({reply.strip()})"
    active, inactive = image.find(RED, 40), image.find(BLUE_BORDER, 40)
    assert image.find(GREEN, 40), f"dragged window not drawn on the second output ({reply.strip()})"
    assert active is None, f"focused border drawn on the second output at {active}"
    assert inactive, "no inactive border on the second output"
    return f"inactive border on the second output at {inactive}"


def drag_title_scale(comp, shot):
    """The title of a window dragged onto a 2x output rasterizes at 2x there: its
    strokes keep pure white cores instead of an upscaled blur."""
    client, reply = drag_onto_output(comp, (1200, 600))
    image = comp.shot(output="HEADLESS-2")
    bar = image.find(GREEN, 40)
    assert bar, f"dragged window not drawn on the second output ({reply.strip()})"
    white = grey = 0
    for y in range(bar[1], bar[3] + 1):
        for x in range(bar[0], bar[2] + 1):
            r, g, b = image.at(x, y)
            if r > 230 and b > 230:
                white += 1
            elif r > 60 and b > 60:
                grey += 1
    assert white, "no title text on the second output"
    ratio = white / (white + grey)
    assert ratio > 0.5, f"title upscaled: {white} white to {grey} blended text pixels"
    return f"title on the 2x output: {white} white to {grey} blended text pixels"


def tile_drag_highlight(comp, shot, focus, grab, to, lit, dark):
    """Mid tile drag, the place the tile would land is highlighted in the accent colour.
    Points are fractions of the output: the focused tile is grabbed at `grab` and moved
    to `to`; `lit` must be tinted, `dark` (if any) must not."""
    client = comp.client()
    scene = Scene(client)
    scene.toplevel(200, 120, solid(BLUE), title="AAA")
    scene.toplevel(200, 120, solid(YELLOW), title="BBB")
    comp.ctl(f'zl.focus_direction("{focus}")')
    before = shot()
    at = lambda f: (int(f[0] * before.width), int(f[1] * before.height))
    extent = (before.width, before.height)
    pointer_to(client, *at(grab), extent)
    reply = comp.ctl("return zl.begin_move()")
    pointer_to(client, *at(to), extent)
    during = shot()
    tinted = lambda f: sum(abs(d - b) for d, b in zip(during.at(*at(f)), before.at(*at(f))))
    assert tinted(lit) >= 30, f"no highlight at {at(lit)}: {before.at(*at(lit))} -> {during.at(*at(lit))} ({reply.strip()})"
    if dark is None:
        return f"highlight at {at(lit)}: {before.at(*at(lit))} -> {during.at(*at(lit))}"
    assert tinted(dark) < 12, f"highlight spilled to {at(dark)}: {before.at(*at(dark))} -> {during.at(*at(dark))}"
    return f"highlight at {at(lit)} {during.at(*at(lit))}, none at {at(dark)} {during.at(*at(dark))}"


TILE_DRAG = 'zl.set_layout("dwindle")\nzl.set_window_style({ gaps_in = 0, gaps_out = 0 })\n'


def x11_override_window(x, y, width, height, argb):
    """Maps a 32-bit override-redirect X window filled with `argb` (premultiplied) and
    keeps it until killed. Runs as a child of the compositor, which gives it DISPLAY."""
    display = int(os.environ["DISPLAY"].lstrip(":").split(".")[0])
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(f"/tmp/.X11-unix/X{display}")
    name = data = b""
    if os.environ.get("XAUTHORITY") and os.path.exists(os.environ["XAUTHORITY"]):
        raw = open(os.environ["XAUTHORITY"], "rb").read()
        at = 2
        while at < len(raw):
            fields = []
            for _ in range(4):
                (size,) = struct.unpack_from(">H", raw, at)
                fields.append(raw[at + 2:at + 2 + size])
                at += 2 + size
            at += 2
            if fields[2] == b"MIT-MAGIC-COOKIE-1":
                name, data = fields[2], fields[3]
                break
    pad = lambda b: b + b"\0" * (-len(b) % 4)
    sock.sendall(struct.pack("<BxHHHHxx", 0x6C, 11, 0, len(name), len(data)) + pad(name) + pad(data))
    head = sock.recv(8)
    assert head[0] == 1, "X server refused the connection"
    (words,) = struct.unpack_from("<H", head, 6)
    body = b""
    while len(body) < words * 4:
        body += sock.recv(words * 4 - len(body))
    base, _mask = struct.unpack_from("<II", body, 4)
    vendor_len, _, screens, formats = struct.unpack_from("<HHBB", body, 16)
    at = 32 + vendor_len + (-vendor_len % 4) + formats * 8
    root = struct.unpack_from("<I", body, at)[0]
    depths = body[at + 39]
    at += 40
    visual = None
    for _ in range(depths):
        depth, count = body[at], struct.unpack_from("<H", body, at + 2)[0]
        at += 8
        for _ in range(count):
            if depth == 32 and body[at + 4] == 4:
                visual = struct.unpack_from("<I", body, at)[0]
            at += 24
    assert visual, "no 32-bit TrueColor visual"
    window, colormap = base | 1, base | 2
    sock.sendall(struct.pack("<BBHIII", 78, 0, 4, colormap, root, visual)
                 + struct.pack("<BBHIIhhHHHHII", 1, 32, 12, window, root, x, y, width, height, 0, 1, visual, 0x2 | 0x8 | 0x200 | 0x2000)
                 + struct.pack("<IIII", argb, 0, 1, colormap)
                 + struct.pack("<BxHI", 8, 2, window))
    while sock.recv(4096):
        pass


def override_redirect_blur(comp, shot):
    """An override-redirect X window blurs as a popup: with popup blur off its
    translucent backdrop stays sharp."""
    scene = Scene(comp.client())
    scene.toplevel(600, 400, lambda x, y: (*(WHITE if (x // 2 + y // 2) % 2 else BLACK), 255), server_side=False)
    x0, y0, x1, y1 = shot().find(WHITE)
    cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
    comp.ctl(f'zl.exec_command("python3 {os.path.abspath(__file__)} --x11-override {cx - 100} {cy - 100} 200 200")')
    for _ in range(40):
        image = shot()
        if image.count(WHITE, (cx - 10, cy - 10, cx + 10, cy + 10)) == 0:
            break
    else:
        raise AssertionError("override-redirect window never mapped")
    tint = image.at(cx - 90, cy - 90), image.at(cx + 90, cy + 90)
    contrast = 0
    for y in range(cy - 40, cy + 40):
        for x in range(cx - 40, cx + 40):
            contrast = max(contrast, abs(image.at(x, y)[0] - image.at(x + 2, y)[0]))
    assert contrast > 100, f"backdrop under the override-redirect window is blurred (max contrast {contrast}, corners {tint})"
    return f"backdrop under an override-redirect window stays sharp (contrast {contrast}, corners {tint})"


def occluder_needs_opaque_region(comp, shot):
    """Only a window whose opaque region covers its whole surface hides what lies
    under it: below a fullscreen XRGB window without one the background layer is
    still drawn, so its frames are presented, not discarded."""
    client = comp.client()
    scene = Scene(client)
    presentation = client.bind("wp_presentation", 1)
    background = scene.layer(0, "parity-wallpaper", 0, 0, 1 | 2 | 4 | 8, solid(GREEN))
    surface = scene.surface()
    state = {"serial": None, "size": None}
    xdg = client.new(lambda op, body: state.update(serial=struct.unpack_from("<I", body)[0]) if op == 0 else None)
    client.send(message(scene.wm_base, 2, u32(xdg, surface)))
    top = client.new(lambda op, body: state.update(size=struct.unpack_from("<ii", body)) if op == 0 else None)
    client.send(message(xdg, 1, u32(top)))
    client.send(message(top, 11, u32(0)))
    client.send(message(surface, 6))
    client.dispatch_until(lambda: state["serial"] is not None and state["size"] and state["size"][0] > 0)
    width, height = state["size"]
    client.send(message(xdg, 4, u32(state["serial"])))
    client.send(message(surface, 1, u32(client.buffer_of(scene.shm, width, height, solid(BLUE), format=1)) + i32(0, 0)))
    client.send(message(surface, 9, i32(0, 0, width, height)))
    client.send(message(surface, 6))
    client.roundtrip()
    image = shot()
    assert image.find(GREEN) is None and image.find(BLUE), "fullscreen window does not cover the output"
    outcome = []
    for _ in range(3):
        feedback = client.new(lambda op, body: outcome.append(("presented", "discarded")[op - 1]) if op in (1, 2) else None)
        client.send(message(presentation, 1, u32(background["surface"], feedback)))
        client.send(message(background["surface"], 1, u32(client.buffer_of(scene.shm, image.width, image.height, solid(GREEN))) + i32(0, 0)))
        client.send(message(background["surface"], 9, i32(0, 0, image.width, image.height)))
        client.send(message(background["surface"], 6))
        count = len(outcome)
        try:
            client.dispatch_until(lambda: len(outcome) > count, 3.0)
        except TimeoutError:
            outcome.append("no feedback")
            break
    assert outcome == ["presented"] * 3, f"background layer feedback under the window: {outcome}"
    return f"background layer feedback under the window: {outcome}"


def chrome_theme_palette(comp, shot):
    """Compositor chrome text takes its colour from the loaded shell theme even when
    window decorations do not follow it."""
    scene = Scene(comp.client())
    scene.toplevel(300, 200, solid(BLUE))
    reply = comp.ctl('return zl.layout("commands")')
    image = shot()
    themed, plain = image.find(MAGENTA, 60), image.find(GREEN, 60)
    assert themed, f"no theme-coloured chrome text ({reply.strip()})"
    assert plain is None, f"chrome text in the decoration colour at {plain}"
    return f"command sheet text in the theme colour at {themed}"


def overview_config_live(comp, shot):
    """zl.set_overview from the control socket re-lays the open overview at once."""
    scene = Scene(comp.client())
    scene.toplevel(300, 200, solid(BLUE))
    comp.ctl("zl.toggle_overview()")
    before = shot()
    comp.ctl('zl.set_overview({ axis = "horizontal", rail = "top" })')
    after = shot()
    changed = sum(before.pixels[i] != after.pixels[i] for i in range(0, len(before.pixels), 3))
    assert changed > before.width * before.height // 100, f"only {changed} pixels changed after set_overview"
    return f"{changed} pixels changed after set_overview with the overview open"


SCENARIOS = {
    "ssd_corners": (ssd_corners, ""),
    "popup_geometry": (popup_geometry, ""),
    "popup_hidden_parent": (popup_hidden_parent, ""),
    "layer_popup_order": (layer_popup_order, ""),
    "layer_blur_scope": (layer_blur_scope, 'zl.set_blur({ enabled = true, size = 8, passes = 3 })\n'),
    "inactive_dim": (inactive_dim, "zl.set_dim({ inactive = true, strength = 0.5 })\n"),
    "surface_leave_hidden": (surface_leave_hidden, ""),
    "popup_hit_topmost": (popup_hit_topmost, ""),
    "ime_popup_over_overlay": (ime_popup_over_overlay, ""),
    "drag_focus_restyle": (drag_focus_restyle, TWO_OUTPUT_CONFIG + DRAG_STYLE, TWO_OUTPUTS),
    "drag_title_scale": (drag_title_scale, TWO_OUTPUT_CONFIG + DRAG_STYLE, TWO_OUTPUTS),
    "chrome_theme_palette": (chrome_theme_palette, 'zl.set_ssd({ title_color = "#00ff00ff", inactive_title_color = "#00ff00ff" })\n', (), THEME),
    # Headless keeps shadows, which a DRM display drawn on the CPU, as the software VM's is, leaves out.
    "resize_keeps_tiled_shadow": (resize_keeps_tiled_shadow, TILED_SHADOW, ("--headless", "--headless-size=1280x800")),
    "occluder_needs_opaque_region": (occluder_needs_opaque_region, ""),
    "override_redirect_blur": (override_redirect_blur, "zl.set_blur({ enabled = true, size = 8, passes = 3, popups = false })\n"),
    "overview_config_live": (overview_config_live, ""),
    "tile_drag_swap": (lambda comp, shot: tile_drag_highlight(comp, shot, "right", (0.98, 0.97), (0.25, 0.5), (0.47, 0.95), None), TILE_DRAG),
    "tile_drag_insert": (lambda comp, shot: tile_drag_highlight(comp, shot, "right", (0.98, 0.97), (0.25, 0.92), (0.47, 0.75), (0.47, 0.25)), TILE_DRAG),
    "tile_drag_scrolling": (
        lambda comp, shot: tile_drag_highlight(comp, shot, "left", (0.02, 0.97), (0.58, 0.5), (0.6, 0.95), (0.45, 0.95)),
        TILE_DRAG + 'zl.set_layout("scrolling", 0.3)\n',
    ),
}


def main():
    if sys.argv[1:2] == ["--x11-override"]:
        x11_override_window(*map(int, sys.argv[2:6]), 0x40000000)
        return
    parser = argparse.ArgumentParser()
    parser.add_argument("--compositor", required=True)
    parser.add_argument("--shots")
    parser.add_argument("scenarios", nargs="*")
    args = parser.parse_args()
    names = args.scenarios or list(SCENARIOS)
    failed = 0
    for name in names:
        check, config, *extra = SCENARIOS[name]
        workdir = tempfile.mkdtemp(prefix=f"parity-{name}-")
        comp = None
        try:
            comp = Compositor(os.path.abspath(args.compositor), config, workdir, *extra)
            shot = lambda: comp.shot(os.path.join(args.shots, f"{name}.ppm") if args.shots else None)
            print(f"PASS {name}: {check(comp, shot)}")
        except Exception as err:
            failed += 1
            print(f"FAIL {name}: {type(err).__name__}: {err}")
        finally:
            if comp:
                comp.stop()
            shutil.rmtree(workdir, ignore_errors=True)
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
