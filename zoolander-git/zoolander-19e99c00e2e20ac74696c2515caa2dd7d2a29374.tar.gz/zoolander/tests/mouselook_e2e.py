#!/usr/bin/env python3
"""A confine_cursor X11 game doing mouse-look must keep the pointer.

Run inside the session mouselook_e2e.sh starts: HEADLESS-1 (1280x800 at 0,0) holds the
fullscreen game, HEADLESS-2 sits to its right rotated 90 degrees, as on the machine
the bug came from, with a native Wayland window covering it. The X client hides its
cursor and warps the pointer back to its centre on every motion, the way mouse-look
does, while a virtual pointer pushes right for a long time. The pointer must never
reach the window on the other monitor and the game must keep keyboard focus.
Takes an optional list of case names; exits non-zero when any check fails.
"""
import os
import select
import struct
import subprocess
import sys
import time

from Xlib import X, display

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from protocol_e2e import Client  # noqa: E402

DESKTOP = (0, -300, 2080, 1280)  # x, y, width, height of both outputs together
STEPS = 3000
PUSH = 40
failures = []


def check(name, ok, detail):
    print(f"{'PASS' if ok else 'FAIL'} {name}: {detail}", flush=True)
    if not ok:
        failures.append(name)


class Spy:
    """A native window covering HEADLESS-2 with a virtual pointer: it hears the pointer
    and keyboard arrive if they ever leave the game."""

    def __init__(self):
        self.c = Client()
        self.compositor = self.c.bind("wl_compositor", 4)
        seat = self.c.bind("wl_seat", 9)
        manager = self.c.bind("zwlr_virtual_pointer_manager_v1", 2)
        self.virtual = self.c.new_id()
        self.c.request(manager, 0, struct.pack("<II", 0, self.virtual))
        self.pointer, self.keyboard = self.c.new_id(), self.c.new_id()
        self.c.request(seat, 0, struct.pack("<I", self.pointer))
        self.c.request(seat, 1, struct.pack("<I", self.keyboard))
        self.point(1700, 300)
        self.surface, _ = self.c.map_toplevel(self.compositor, self.c.bind("xdg_wm_base", 1))
        self.pointer_entered = 0
        self.keyboard_entered = 0
        self.settle()
        self.pointer_entered = 0
        self.keyboard_entered = 0

    def point(self, x, y):
        dx, dy, w, h = DESKTOP
        self.c.request(self.virtual, 1, struct.pack("<IIIII", 0, x - dx, y - dy, w, h))
        self.c.request(self.virtual, 4)

    def push(self, dx, dy):
        self.c.request(self.virtual, 0, struct.pack("<Iii", 0, int(dx * 256), int(dy * 256)))
        self.c.request(self.virtual, 4)

    def settle(self):
        for obj, opcode, body in self.c.roundtrip():
            if obj == self.pointer and opcode == 0 and struct.unpack_from("<II", body)[1] == self.surface:
                self.pointer_entered += 1
            if obj == self.keyboard and opcode == 1 and struct.unpack_from("<II", body)[1] == self.surface:
                self.keyboard_entered += 1


WAR_THUNDER = "War Thunder (Vulkan, 64bit)"
MASK = X.StructureNotifyMask | X.PointerMotionMask | X.FocusChangeMask | X.EnterWindowMask | X.LeaveWindowMask


def vulkan_window(d, seconds=20):
    """The Vulkan client's window, once the window manager lists it."""
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        prop = d.screen().root.get_full_property(d.intern_atom("_NET_CLIENT_LIST"), X.AnyPropertyType)
        for wid in (prop.value if prop else []):
            win = d.create_resource_object("window", wid)
            cls = win.get_wm_class()
            if cls and cls[1] == WAR_THUNDER:
                return win
        time.sleep(0.1)
    raise RuntimeError("the Vulkan client never mapped")


class Game:
    def __init__(self, name, hidden, grab, confine, warp, vulkan=False):
        self.d = display.Display()
        screen = self.d.screen()
        self.process = None
        if vulkan:
            env = dict(os.environ, ZOOLANDER_WSI="1", WSI_CLIENT_EARLY="1", WSI_CLIENT_CLASS=WAR_THUNDER, WSI_CLIENT_SECONDS="120",
                       VK_ADD_IMPLICIT_LAYER_PATH=os.environ["MOUSELOOK_VK_LAYERS"])
            self.process = subprocess.Popen([os.environ["MOUSELOOK_VK_CLIENT"]], env=env, stdout=subprocess.PIPE, text=True)
            self.win = vulkan_window(self.d)
            self.win.change_attributes(event_mask=MASK)
            geometry = self.win.get_geometry()
            self.width, self.height = geometry.width, geometry.height
        else:
            self.win = screen.root.create_window(
                0, 0, 640, 400, 0, screen.root_depth, X.InputOutput, X.CopyFromParent, background_pixel=screen.black_pixel, event_mask=MASK,
            )
            self.win.set_wm_name(name)
            self.win.set_wm_class(name, name)
        cursor = X.NONE
        if hidden:
            blank = self.win.create_pixmap(1, 1, 1)
            cursor = blank.create_cursor(blank, (0, 0, 0), (0, 0, 0), 0, 0)
            self.win.change_attributes(cursor=cursor)
        if not vulkan:
            self.win.map()
            self.d.sync()
            self.width, self.height = 0, 0
        self.focus_out = 0
        self.wait(lambda: self.width >= 1280, 5)
        if grab:
            status = self.win.grab_pointer(
                True, X.PointerMotionMask, X.GrabModeAsync, X.GrabModeAsync, self.win if confine else X.NONE, cursor, X.CurrentTime,
            )
            check(f"{name} grab", status == X.GrabSuccess, f"XGrabPointer returned {status}")
        self.warp = warp
        self.motions = 0
        self.warps = 0
        self.last = None
        self.jumps = []
        self.warp_serial = None
        self.focus_out = 0

    def pump(self):
        while self.d.pending_events():
            e = self.d.next_event()
            if e.type == X.ConfigureNotify:
                self.width, self.height = e.width, e.height
            elif e.type == X.FocusOut and e.mode == X.NotifyNormal and e.detail != X.NotifyPointer:
                self.focus_out += 1
                print(f"  focus out detail {e.detail}", flush=True)
            elif e.type == X.MotionNotify and self.width:
                self.motions += 1
                cx, cy = self.width // 2, self.height // 2
                # Motion the server queued before the last warp still carries the pre-warp position.
                stale = self.warp_serial is not None and (e.sequence_number - self.warp_serial) % 65536 > 32768
                if not stale and self.last and max(abs(e.event_x - self.last[0]), abs(e.event_y - self.last[1])) > 2 * PUSH:
                    self.jumps.append((self.last, (e.event_x, e.event_y)))
                if not stale:
                    self.last = (e.event_x, e.event_y)
                if self.warp and self.motions % self.warp == 0 and (e.event_x, e.event_y) != (cx, cy):
                    self.win.warp_pointer(cx, cy)
                    self.warps += 1
                    self.last = (cx, cy)
                    self.warp_serial = (self.d.display.request_serial - 1) % 65536
        self.d.flush()

    def wait(self, predicate, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end and not predicate():
            select.select([self.d.fileno()], [], [], 0.05)
            self.pump()

    def root_pointer(self):
        p = self.win.query_pointer()
        return p.root_x, p.root_y

    def close(self):
        self.d.ungrab_pointer(X.CurrentTime)
        if self.process:
            self.process.kill()
            self.process.wait()
        else:
            self.win.destroy()
        self.d.close()


def pointer_report(title):
    """What `zoolanderctl clients` says about the pointer of the window titled `title`, or of the Vulkan game."""
    ctl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "zoolanderctl")
    lines = subprocess.run(["sh", ctl, "clients"], capture_output=True, text=True).stdout.splitlines()
    block = []
    for line in lines:
        if line.startswith("window "):
            block = [line]
        else:
            block.append(line)
        if line.startswith("  pointer:") and any(title in b or WAR_THUNDER in b for b in block):
            return line.strip()
    return "no report"


def mouselook(spy, name, hidden, grab, confine, warp=1, vulkan=False, rule=True):
    spy.point(640, 400)
    spy.settle()
    game = Game(name, hidden, grab, confine, warp, vulkan)
    if rule:
        check(f"{name} fullscreen", game.width == 1280 and game.height == 800, f"{game.width}x{game.height}")
    spy.point(640, 400)
    spy.settle()
    game.wait(lambda: False, 0.3)
    spy.pointer_entered = spy.keyboard_entered = 0
    game.last, game.jumps = None, []
    escaped_at = None
    report = "no report"
    for step in range(STEPS):
        spy.push(PUSH, 0)
        if step % 10 == 0:
            spy.settle()
            game.wait(lambda: False, 0.002)
            if escaped_at is None and (spy.pointer_entered or spy.keyboard_entered or game.focus_out):
                escaped_at = step
        if step == STEPS // 2:
            report = pointer_report(name)
    spy.settle()
    game.wait(lambda: False, 0.3)
    spy.settle()
    x, y = game.root_pointer()
    detail = (f"escaped at push {escaped_at}, spy pointer enters {spy.pointer_entered}, keyboard enters {spy.keyboard_entered}, "
              f"game focus outs {game.focus_out}, X motions {game.motions}, warps {game.warps}, X pointer {x},{y}; mid-run {report}")
    if rule:
        check(f"{name} keeps the pointer", escaped_at is None and spy.pointer_entered == 0, detail)
        check(f"{name} never jumps", not game.jumps, f"{len(game.jumps)} jumps, first {game.jumps[:3]}")
        check(f"{name} keeps the keyboard", spy.keyboard_entered == 0 and game.focus_out == 0, detail)
    else:
        check(f"{name} loses the pointer without the rule", spy.pointer_entered > 0, detail)
    game.close()
    spy.settle()


# Mouse-look as X11 games do it: the cursor hidden or not, the pointer grabbed or confined to the window, and
# warped back to the centre on every motion, every eighth one or never. The Vulkan cases present through the
# WSI layer's bypass surface as War Thunder does with force_game_hdr.
CASES = {
    "hidden-grab": dict(hidden=True, grab=True, confine=False),
    "hidden": dict(hidden=True, grab=False, confine=False),
    "visible": dict(hidden=False, grab=False, confine=False),
    "hidden-grab-confine": dict(hidden=True, grab=True, confine=True),
    "hidden-grab-nowarp": dict(hidden=True, grab=True, confine=False, warp=0),
    "hidden-grab-slowwarp": dict(hidden=True, grab=True, confine=False, warp=8),
    "vulkan-hdr": dict(hidden=True, grab=True, confine=False, vulkan=True),
    "vulkan-hdr-nowarp": dict(hidden=True, grab=True, confine=False, warp=0, vulkan=True),
}

spy = Spy()
for case in sys.argv[1:] or list(CASES):
    mouselook(spy, f"mouselook-{case}", **CASES[case])
# The same game without the rule must lose the pointer, or the checks above prove nothing.
mouselook(spy, "control-visible", hidden=False, grab=False, confine=False, rule=False)
sys.exit(len(failures))
