// An X11 Vulkan client standing in for a Proton game: its window class is steam_app_<SteamAppId>, it
// prefers an HDR10 swapchain when the surface offers one, and it clears every frame to 0.439, which reads
// back as 0x70 through an SDR swapchain and as the PQ conversion's output through an HDR10 one.
// Prints DXVK_HDR=, HDR10=, SWAPCHAIN and PRESENTING lines for wsi_layer_e2e.sh.
#define VK_USE_PLATFORM_XCB_KHR
#include <vulkan/vulkan.h>
#include <xcb/xcb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define CHECK(x) do { VkResult r_ = (x); if (r_ < 0) { fprintf(stderr, "%s failed: %d\n", #x, r_); exit(1); } } while (0)

static double now(void) {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec + ts.tv_nsec / 1e9;
}

struct chain {
	VkSwapchainKHR swapchain;
	VkImage images[8];
	uint32_t count;
};

static void make_chain(VkPhysicalDevice pd, VkDevice dev, VkSurfaceKHR surface, VkSurfaceFormatKHR format, struct chain *c) {
	VkSurfaceCapabilitiesKHR caps;
	CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(pd, surface, &caps));
	VkExtent2D extent = caps.currentExtent;
	if (extent.width == 0xffffffff) extent = (VkExtent2D){ 640, 400 };
	VkSwapchainCreateInfoKHR info = {
		.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
		.surface = surface,
		.minImageCount = caps.minImageCount < 2 ? 2 : caps.minImageCount,
		.imageFormat = format.format,
		.imageColorSpace = format.colorSpace,
		.imageExtent = extent,
		.imageArrayLayers = 1,
		.imageUsage = VK_IMAGE_USAGE_TRANSFER_DST_BIT,
		.preTransform = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR,
		.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR,
		.presentMode = VK_PRESENT_MODE_FIFO_KHR,
		.clipped = VK_TRUE,
		.oldSwapchain = c->swapchain,
	};
	VkSwapchainKHR made;
	VkResult r = vkCreateSwapchainKHR(dev, &info, NULL, &made);
	printf("SWAPCHAIN format=%d colorspace=%d extent=%ux%u result=%d\n", format.format, format.colorSpace, extent.width, extent.height, r);
	fflush(stdout);
	if (r < 0) exit(1);
	if (c->swapchain) vkDestroySwapchainKHR(dev, c->swapchain, NULL);
	c->swapchain = made;
	c->count = 8;
	CHECK(vkGetSwapchainImagesKHR(dev, made, &c->count, c->images));
}

int main(void) {
	xcb_connection_t *conn = xcb_connect(NULL, NULL);
	if (xcb_connection_has_error(conn)) { fprintf(stderr, "no X11\n"); return 1; }
	xcb_screen_t *screen = xcb_setup_roots_iterator(xcb_get_setup(conn)).data;
	xcb_window_t window = xcb_generate_id(conn);
	xcb_create_window(conn, XCB_COPY_FROM_PARENT, window, screen->root, 0, 0, 640, 400, 0,
		XCB_WINDOW_CLASS_INPUT_OUTPUT, screen->root_visual, 0, NULL);
	char class[64];
	const char *app = getenv("SteamAppId");
	int n = getenv("WSI_CLIENT_CLASS") ? snprintf(class, sizeof class, "%s", getenv("WSI_CLIENT_CLASS"))
		: snprintf(class, sizeof class, "steam_app_%s", app ? app : "0");
	// WSI_CLIENT_EARLY decides on HDR and makes its swapchain before mapping the window, as many games do.
	int early = getenv("WSI_CLIENT_EARLY") != NULL;
	char both[130];
	memcpy(both, class, n + 1);
	memcpy(both + n + 1, class, n + 1);
	xcb_change_property(conn, XCB_PROP_MODE_REPLACE, window, XCB_ATOM_WM_CLASS, XCB_ATOM_STRING, 8, 2 * (n + 1), both);
	if (!early) xcb_map_window(conn, window);
	xcb_flush(conn);

	const char *extensions[] = { "VK_KHR_surface", "VK_KHR_xcb_surface", "VK_EXT_swapchain_colorspace" };
	VkApplicationInfo app_info = { .sType = VK_STRUCTURE_TYPE_APPLICATION_INFO, .pApplicationName = "wsi-layer-client", .apiVersion = VK_API_VERSION_1_1 };
	VkInstanceCreateInfo ici = { .sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO, .pApplicationInfo = &app_info, .enabledExtensionCount = 3, .ppEnabledExtensionNames = extensions };
	VkInstance instance;
	CHECK(vkCreateInstance(&ici, NULL, &instance));
	const char *hdr_env = getenv("DXVK_HDR");
	printf("DXVK_HDR=%s\n", hdr_env ? hdr_env : "unset");

	VkXcbSurfaceCreateInfoKHR sci = { .sType = VK_STRUCTURE_TYPE_XCB_SURFACE_CREATE_INFO_KHR, .connection = conn, .window = window };
	VkSurfaceKHR surface;
	CHECK(vkCreateXcbSurfaceKHR(instance, &sci, NULL, &surface));
	uint32_t pdc = 1;
	VkPhysicalDevice pd;
	vkEnumeratePhysicalDevices(instance, &pdc, &pd);
	VkBool32 supported = VK_FALSE;
	CHECK(vkGetPhysicalDeviceSurfaceSupportKHR(pd, 0, surface, &supported));
	if (!supported) { fprintf(stderr, "queue family 0 cannot present\n"); return 1; }

	// The window maps and the compositor applies its rules a little after the surface exists.
	struct timespec settle = { 0, 300000000 };
	if (!early) nanosleep(&settle, NULL);
	uint32_t fc = 64;
	VkSurfaceFormatKHR formats[64];
	CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(pd, surface, &fc, formats));
	VkSurfaceFormatKHR chosen = { VK_FORMAT_B8G8R8A8_UNORM, VK_COLOR_SPACE_SRGB_NONLINEAR_KHR };
	int hdr10 = 0;
	for (uint32_t i = 0; i < fc; i++) {
		// Lavapipe presents through wl_shm, which has 8-bit formats only, so any HDR10 format will do,
		// 10-bit preferred as a game would.
		if (formats[i].colorSpace != VK_COLOR_SPACE_HDR10_ST2084_EXT) continue;
		if (formats[i].format != VK_FORMAT_B8G8R8A8_UNORM && formats[i].format != VK_FORMAT_A2B10G10R10_UNORM_PACK32) continue;
		if (!hdr10 || formats[i].format == VK_FORMAT_A2B10G10R10_UNORM_PACK32) chosen = formats[i];
		hdr10 = 1;
	}
	// WSI_CLIENT_SDR keeps an sRGB swapchain while HDR10 is offered, as a game with HDR off would.
	if (getenv("WSI_CLIENT_SDR")) chosen = (VkSurfaceFormatKHR){ VK_FORMAT_B8G8R8A8_UNORM, VK_COLOR_SPACE_SRGB_NONLINEAR_KHR };
	printf("HDR10=%d formats=%u\n", hdr10, fc);
	fflush(stdout);

	float priority = 1;
	VkDeviceQueueCreateInfo qci = { .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO, .queueCount = 1, .pQueuePriorities = &priority };
	const char *dev_ext[] = { "VK_KHR_swapchain" };
	VkDeviceCreateInfo dci = { .sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO, .queueCreateInfoCount = 1, .pQueueCreateInfos = &qci, .enabledExtensionCount = 1, .ppEnabledExtensionNames = dev_ext };
	VkDevice dev;
	CHECK(vkCreateDevice(pd, &dci, NULL, &dev));
	VkQueue queue;
	vkGetDeviceQueue(dev, 0, 0, &queue);
	VkCommandPoolCreateInfo pci = { .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO, .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT };
	VkCommandPool pool;
	CHECK(vkCreateCommandPool(dev, &pci, NULL, &pool));
	VkCommandBufferAllocateInfo cai = { .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO, .commandPool = pool, .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY, .commandBufferCount = 1 };
	VkCommandBuffer cmd;
	CHECK(vkAllocateCommandBuffers(dev, &cai, &cmd));
	VkSemaphoreCreateInfo semi = { .sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO };
	VkSemaphore acquired, rendered;
	CHECK(vkCreateSemaphore(dev, &semi, NULL, &acquired));
	CHECK(vkCreateSemaphore(dev, &semi, NULL, &rendered));
	VkFenceCreateInfo fi = { .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
	VkFence fence;
	CHECK(vkCreateFence(dev, &fi, NULL, &fence));

	struct chain c = { 0 };
	make_chain(pd, dev, surface, chosen, &c);
	if (early) {
		xcb_map_window(conn, window);
		xcb_flush(conn);
	}
	printf("PRESENTING\n");
	fflush(stdout);
	double end = now() + (getenv("WSI_CLIENT_SECONDS") ? atof(getenv("WSI_CLIENT_SECONDS")) : 6);
	while (now() < end) {
		uint32_t index;
		VkResult r = vkAcquireNextImageKHR(dev, c.swapchain, UINT64_MAX, acquired, VK_NULL_HANDLE, &index);
		if (r == VK_ERROR_OUT_OF_DATE_KHR) { vkDeviceWaitIdle(dev); make_chain(pd, dev, surface, chosen, &c); continue; }
		CHECK(r);
		VkCommandBufferBeginInfo bi = { .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
		CHECK(vkBeginCommandBuffer(cmd, &bi));
		VkImageSubresourceRange range = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 };
		VkImageMemoryBarrier to_dst = { .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER, .dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT,
			.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED, .newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
			.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED, .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED, .image = c.images[index], .subresourceRange = range };
		vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, NULL, 0, NULL, 1, &to_dst);
		VkClearColorValue grey = { .float32 = { 0.4392f, 0.4392f, 0.4392f, 1.0f } };
		vkCmdClearColorImage(cmd, c.images[index], VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, &grey, 1, &range);
		VkImageMemoryBarrier to_present = to_dst;
		to_present.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
		to_present.dstAccessMask = 0;
		to_present.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
		to_present.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
		vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, 0, 0, NULL, 0, NULL, 1, &to_present);
		CHECK(vkEndCommandBuffer(cmd));
		VkPipelineStageFlags stage = VK_PIPELINE_STAGE_TRANSFER_BIT;
		VkSubmitInfo si = { .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO, .waitSemaphoreCount = 1, .pWaitSemaphores = &acquired, .pWaitDstStageMask = &stage,
			.commandBufferCount = 1, .pCommandBuffers = &cmd, .signalSemaphoreCount = 1, .pSignalSemaphores = &rendered };
		CHECK(vkQueueSubmit(queue, 1, &si, fence));
		VkPresentInfoKHR pi = { .sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR, .waitSemaphoreCount = 1, .pWaitSemaphores = &rendered,
			.swapchainCount = 1, .pSwapchains = &c.swapchain, .pImageIndices = &index };
		r = vkQueuePresentKHR(queue, &pi);
		vkWaitForFences(dev, 1, &fence, VK_TRUE, UINT64_MAX);
		vkResetFences(dev, 1, &fence);
		if (r == VK_ERROR_OUT_OF_DATE_KHR || r == VK_SUBOPTIMAL_KHR) {
			printf("RECREATE result=%d\n", r);
			fflush(stdout);
			vkDeviceWaitIdle(dev);
			make_chain(pd, dev, surface, chosen, &c);
		} else CHECK(r);
	}
	vkDeviceWaitIdle(dev);
	vkDestroySwapchainKHR(dev, c.swapchain, NULL);
	vkDestroyDevice(dev, NULL);
	vkDestroySurfaceKHR(instance, surface, NULL);
	vkDestroyInstance(instance, NULL);
	printf("DONE\n");
	return 0;
}
