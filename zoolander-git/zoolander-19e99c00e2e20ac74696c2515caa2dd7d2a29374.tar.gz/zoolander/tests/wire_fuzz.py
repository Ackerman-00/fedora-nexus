#!/usr/bin/env python3
"""Seeded raw-wire fuzzing of every advertised global.

Each round opens one to three clients that bind globals and send requests built
from the protocol XML: boundary integers, long and foreign strings, assorted
fds, wrong or stale objects, plus broken framing (bad sizes, truncated frames,
unknown opcodes, fd floods, garbage). Protocol errors are expected; the test
fails only if the compositor stops answering, and prints the round to replay.

    wire_fuzz.py [first-round [rounds]]

Run with WAYLAND_DISPLAY and XDG_RUNTIME_DIR pointing at the compositor.
ZL_PROTOCOLS overrides the XML directory, by default the sibling zooland
checkout's protocols.
"""
import collections
import glob
import os
import random
import socket
import struct
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bind_all_globals import DISPLAY, REGISTRY, message  # noqa: E402

INTS = [0, 1, -1, 2, 7, 64, 255, 256, 4096, 65535, 0x7FFFFFFF, -0x80000000, 0x40000000, -2]
UINTS = [0, 1, 2, 3, 4, 5, 8, 16, 255, 0xFFFFFFFF, 0x7FFFFFFF, 0x80000000, 4096, 65535, 0x34325258]
ACK_OPCODE = {"xdg_surface": 4, "zwlr_layer_surface_v1": 6, "ext_session_lock_surface_v1": 1}


def string(raw):
    raw += b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def socket_path():
    return os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))


def load_requests():
    here = os.path.dirname(os.path.abspath(__file__))
    folder = os.environ.get("ZL_PROTOCOLS", os.path.join(here, "..", "..", "zooland", "protocols"))
    requests = {}
    for path in glob.glob(os.path.join(folder, "*.xml")):
        for iface in ET.parse(path).getroot().iter("interface"):
            requests[iface.get("name")] = [
                (r.get("name"), [(a.get("type"), a.get("interface"), a.get("allow-null") == "true") for a in r.iter("arg")],
                 r.get("type") == "destructor", int(r.get("since", "1")))
                for r in iface.iter("request")]
    if not requests:
        raise RuntimeError(f"no protocol XML in {folder}")
    return requests


class Fuzzer:
    """One client. `strings` is shared by the round so one client can replay
    tokens, handles and names another one received."""

    def __init__(self, requests, rng, strings, log):
        self.requests, self.rng, self.strings, self.log = requests, rng, strings, log
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(socket_path())
        self.objects = {DISPLAY: ("wl_display", 1), REGISTRY: ("wl_registry", 1)}
        self.next_id = REGISTRY + 1
        self.globals = []
        self.events = []
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.sync()
        if rng.random() < 0.7:
            self.map_window()

    def new(self, iface, version=1):
        self.next_id += 1
        self.objects[self.next_id - 1] = (iface, version)
        return self.next_id - 1

    def bind(self, name, iface, version):
        obj = self.new(iface, max(version, 1))
        self.log.append(f"bind {iface}@{version} -> {obj}")
        self.send(message(REGISTRY, 0, struct.pack("<I", name) + string(iface.encode()) + struct.pack("<II", version, obj)))
        return obj

    def bind_named(self, iface):
        return next((self.bind(name, i, version) for name, i, version in self.globals if i == iface), None)

    def shm_buffer(self, shm, width, height):
        fd = os.memfd_create("wire-fuzz")
        os.ftruncate(fd, width * height * 4)
        pool = self.new("wl_shm_pool")
        self.send(message(shm, 0, struct.pack("<Ii", pool, width * height * 4)), [fd])
        os.close(fd)
        buffer = self.new("wl_buffer")
        self.send(message(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, width * 4, 1)))
        return buffer

    def map_window(self):
        """A mapped toplevel and spare buffers, so requests reach focus, input and render paths."""
        compositor, shm, wm_base = (self.bind_named(i) for i in ("wl_compositor", "wl_shm", "xdg_wm_base"))
        for iface in ("wl_seat", "wl_output", "wl_subcompositor", "zwlr_layer_shell_v1", "wl_data_device_manager"):
            self.bind_named(iface)
        surface = self.new("wl_surface", 6)
        xdg_surface, toplevel = self.new("xdg_surface", 7), self.new("xdg_toplevel", 7)
        self.send(message(compositor, 0, struct.pack("<I", surface)))
        self.send(message(wm_base, 2, struct.pack("<II", xdg_surface, surface)))
        self.send(message(xdg_surface, 1, struct.pack("<I", toplevel)))
        self.send(message(surface, 6, b""))
        self.events = []
        if not self.sync():
            return
        serial = next((struct.unpack_from("<I", b)[0] for o, op, b in self.events if o == xdg_surface and op == 0), None)
        if serial is None:
            return
        self.send(message(xdg_surface, 4, struct.pack("<I", serial)))
        self.send(message(surface, 1, struct.pack("<Iii", self.shm_buffer(shm, 64, 64), 0, 0)))
        self.send(message(surface, 6, b""))
        for _ in range(2):
            self.shm_buffer(shm, self.rng.choice([1, 16, 64]), self.rng.choice([1, 16, 64]))

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, struct.pack(f"{len(fds)}i", *fds))])
        else:
            self.sock.sendall(data)

    def sync(self):
        """Round trip; False once the compositor posted an error or hung up."""
        callback = self.next_id
        self.next_id += 1
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        buffer = b""
        while True:
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * 4))
            for level, kind, payload in ancillary:
                if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                    for fd in struct.unpack(f"{len(payload) // 4}i", payload[:len(payload) - len(payload) % 4]):
                        os.close(fd)
            if not data:
                return False
            buffer += data
            while len(buffer) >= 8 and len(buffer) >= struct.unpack_from("<I", buffer, 4)[0] >> 16:
                obj, word = struct.unpack_from("<II", buffer)
                body, buffer = buffer[8:word >> 16], buffer[word >> 16:]
                self.event(obj, word & 0xFFFF, body)
                if obj == DISPLAY and word & 0xFFFF == 0:
                    return False
                if obj == callback and word & 0xFFFF == 0:
                    return True

    def event(self, obj, opcode, body):
        self.events.append((obj, opcode, body))
        for at in range(0, len(body) - 4, 4):
            (size,) = struct.unpack_from("<I", body, at)
            if 2 <= size <= 256 and at + 4 + size <= len(body) and body[at + 3 + size] == 0:
                raw = body[at + 4:at + 3 + size]
                if all(32 <= c < 127 for c in raw) and raw not in self.strings:
                    self.strings.append(raw)
        if obj == REGISTRY and opcode == 0:
            name, size = struct.unpack_from("<II", body)
            self.globals.append((name, body[8:7 + size].decode(), struct.unpack_from("<I", body, 8 + size + (-size % 4))[0]))
        elif obj == DISPLAY and opcode == 0:
            failed, code, size = struct.unpack_from("<III", body)
            self.log.append(f"error on {self.objects.get(failed, ('?',))[0]}@{failed} code {code}: {body[12:11 + size].decode(errors='replace')}")

    def fd(self):
        roll = self.rng.random()
        if roll < 0.5:
            fd = os.memfd_create("wire-fuzz")
            os.ftruncate(fd, self.rng.choice([0, 1, 4096, 65536, 1 << 20]))
            return fd
        if roll < 0.8:
            read, write = os.pipe()
            os.close(write)
            return read
        return os.open("/dev/null", os.O_RDWR)

    def object_id(self, iface):
        live = [o for o, (i, _) in self.objects.items() if iface is None or i == iface]
        roll = self.rng.random()
        if live and roll < 0.97:
            return self.rng.choice(live)
        if not live and roll < 0.9:
            raise LookupError(iface)
        if roll < 0.99:
            return self.rng.choice(list(self.objects))
        return self.rng.choice([0, 0xFFFFFFFF, 0xFF000000, self.next_id + 5])

    def argument(self, kind, iface, nullable, version, fds):
        rng = self.rng
        if kind == "int":
            return struct.pack("<i", rng.choice(INTS) if rng.random() < 0.7 else rng.randint(-5000, 5000))
        if kind == "uint":
            return struct.pack("<I", rng.choice(UINTS) if rng.random() < 0.7 else rng.randint(0, 5000))
        if kind == "fixed":
            return struct.pack("<i", rng.choice(INTS) if rng.random() < 0.5 else rng.randint(-5000 * 256, 5000 * 256))
        if kind == "string":
            if nullable and rng.random() < 0.2:
                return struct.pack("<I", 0)
            if self.strings and rng.random() < 0.4:
                return string(rng.choice(self.strings))
            return string(bytes(rng.choice(b"abcxyz/.-_ \xc3\xa9") for _ in range(rng.choice([0, 1, 5, 64, 300, 1000, 4000]))))
        if kind == "array":
            size = rng.choice([0, 1, 3, 4, 8, 12, 16, 64, 1024])
            return struct.pack("<I", size) + bytes(rng.randrange(256) for _ in range(size)) + b"\0" * (-size % 4)
        if kind == "fd":
            fds.append(self.fd())
            return b""
        if kind == "object":
            return struct.pack("<I", 0 if nullable and rng.random() < 0.2 else self.object_id(iface))
        if iface is None:
            raise LookupError(kind)
        obj = self.new(iface, version) if rng.random() < 0.995 else rng.choice(list(self.objects))
        return struct.pack("<I", obj)

    def ack_configures(self):
        latest = {obj: body for obj, opcode, body in self.events if opcode == 0}
        self.events = []
        for obj, body in latest.items():
            iface = self.objects.get(obj, ("",))[0]
            if iface in ACK_OPCODE:
                self.log.append(f"ack {iface}@{obj}")
                self.send(message(obj, ACK_OPCODE[iface], body[:4]))

    def step(self):
        rng = self.rng
        if rng.random() < 0.08:
            return self.ack_configures()
        if self.globals and (rng.random() < 0.08 or len(self.objects) < 4):
            name, iface, version = rng.choice(self.globals)
            return self.bind(name, iface, rng.randint(1, version) if rng.random() < 0.9 else rng.choice([0, version + 1]))
        obj = rng.choice([o for o in self.objects if o != DISPLAY])
        iface, version = self.objects[obj]
        candidates = [(op, r) for op, r in enumerate(self.requests.get(iface, [])) if r[3] <= version or rng.random() < 0.05]
        if iface == "wl_registry" or not candidates:
            return
        opcode, (name, args, destructor, _) = rng.choice(candidates)
        saved, fds = (dict(self.objects), self.next_id), []
        try:
            payload = b"".join(self.argument(kind, arg_iface, nullable, version, fds) for kind, arg_iface, nullable in args)
        except LookupError:
            for fd in fds:
                os.close(fd)
            self.objects, self.next_id = saved
            return
        data = message(obj, opcode, payload)
        roll = rng.random()
        if roll < 0.01:
            data = struct.pack("<II", obj, rng.choice([0, 4, 6, 9, 4095, 4100, 0xFFFF, len(data) + 4]) << 16 | opcode) + payload
        elif roll < 0.02:
            data = data[:rng.randrange(1, len(data))]
        elif roll < 0.03:
            data = message(obj, rng.choice([opcode + 50, 0xFFFF]), payload)
        elif roll < 0.035:
            fds += [self.fd() for _ in range(rng.choice([1, 27, 30, 70]))]
        elif roll < 0.04:
            data = bytes(rng.randrange(256) for _ in range(rng.choice([8, 64, 4096])))
        self.log.append(f"{iface}@{obj}.{name} {data.hex()} fds={len(fds)}")
        try:
            # SCM_RIGHTS carries at most 28 descriptors per sendmsg here, so a flood spans several.
            for at in range(0, max(len(fds), 1), 28):
                self.send(data if at == 0 else message(DISPLAY, 0, struct.pack("<I", self.next_id)), fds[at:at + 28])
        finally:
            for fd in fds:
                os.close(fd)
        if destructor:
            del self.objects[obj]


def answers():
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
            sock.settimeout(5)
            sock.connect(socket_path())
            sock.sendall(message(DISPLAY, 0, struct.pack("<I", 3)))
            return len(sock.recv(64)) > 0
    except OSError:
        return False


def fuzz_round(requests, number, log):
    rng = random.Random(number)
    strings, clients = [], []
    try:
        for _ in range(rng.choice([1, 2, 3])):
            clients.append(Fuzzer(requests, rng, strings, log))
    except OSError as err:
        log.append(f"client setup: {err}")
    for _ in range(rng.choice([30, 100, 300])):
        if not clients:
            break
        client = rng.choice(clients)
        try:
            client.step()
            if rng.random() < 0.05 and not client.sync():
                raise ConnectionError("disconnected")
        except OSError as err:
            log.append(f"client gone: {err}")
            clients.remove(client)
            client.sock.close()
    for client in clients:
        try:
            client.sync()
        except OSError:
            pass
        client.sock.close()


def main():
    first = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    rounds = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
    requests = load_requests()
    for number in range(first, first + rounds):
        log = collections.deque(maxlen=200)
        fuzz_round(requests, number, log)
        if not answers():
            print(f"FAIL: compositor stopped answering after round {number}; replay with: wire_fuzz.py {number} 1")
            print("\n".join(log))
            sys.exit(1)
    print(f"PASS {rounds} rounds from {first}")


if __name__ == "__main__":
    main()
