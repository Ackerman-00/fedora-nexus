#!/usr/bin/env python3
"""Input rules, the inputs report and the keyboard layout stream, on a real libinput device.

Runs against a live compositor on the seat, started with tests/input_devices_e2e.lua as
its config (a two-layout keymap switched with Alt+Shift, and an F1 bind that appends a
line to $XDG_RUNTIME_DIR/input-devices-e2e-fires). The keyboard is a uinput device, so
sudo must work without a password. WAYLAND_DISPLAY and XDG_RUNTIME_DIR must point at
the compositor. Each check prints PASS or FAIL; the exit status is the number of
failures.
"""
import fcntl
import json
import os
import socket
import struct
import subprocess
import sys
import time

NAME = "zoo input rule keyboard"
KEY_F1, KEY_LEFTALT, KEY_LEFTSHIFT = 59, 56, 42
CHORDS = {"f1": [KEY_F1], "layout": [KEY_LEFTALT, KEY_LEFTSHIFT]}
failures = 0


def check(name, ok, detail=""):
    global failures
    failures += not ok
    print(f"{'PASS' if ok else 'FAIL'} {name}{'' if ok else ': ' + detail}", flush=True)


def keyboard_device():
    """Runs as root: a uinput keyboard that presses the chord named on each stdin line."""
    def emit(fd, kind, code, value):
        os.write(fd, struct.pack("<qqHHi", 0, 0, kind, code, value))

    fd = os.open("/dev/uinput", os.O_WRONLY)
    fcntl.ioctl(fd, 0x40045564, 1)  # UI_SET_EVBIT EV_KEY
    for key in (KEY_F1, KEY_LEFTALT, KEY_LEFTSHIFT):
        fcntl.ioctl(fd, 0x40045565, key)  # UI_SET_KEYBIT
    os.write(fd, NAME.encode().ljust(80, b"\0") + struct.pack("<HHHHI", 3, 1, 1, 1, 0) + b"\0" * (4 * 64 * 4))
    fcntl.ioctl(fd, 0x5501)  # UI_DEV_CREATE
    print("ready", flush=True)
    for line in sys.stdin:
        keys = CHORDS[line.strip()]
        for key in keys:
            emit(fd, 1, key, 1)
            emit(fd, 0, 0, 0)
        time.sleep(0.05)
        for key in reversed(keys):
            emit(fd, 1, key, 0)
            emit(fd, 0, 0, 0)
        print("done", flush=True)
    fcntl.ioctl(fd, 0x5502)  # UI_DEV_DESTROY
    os.close(fd)


class Keyboard:
    def __init__(self):
        self.device = subprocess.Popen(["sudo", "-n", sys.executable, os.path.abspath(__file__), "--device"],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
        self.device.stdout.readline()

    def press(self, chord):
        self.device.stdin.write(chord + "\n")
        self.device.stdin.flush()
        self.device.stdout.readline()

    def unplug(self):
        self.device.stdin.close()
        self.device.wait()


def connect():
    path = os.path.join(os.environ["XDG_RUNTIME_DIR"], "zoolander-" + os.path.basename(os.environ["WAYLAND_DISPLAY"]) + ".sock")
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(path)
    return sock


def control(command):
    """The reply to one command, without the greeting."""
    with connect() as sock:
        sock.sendall(command.encode() + b"\n")
        sock.shutdown(socket.SHUT_WR)
        reply = b""
        while chunk := sock.recv(65536):
            reply += chunk
    return reply.decode().split("\n", 1)[1]


def line(stream, seconds=3):
    """The next line of a watch connection, or None when none comes."""
    stream.settimeout(seconds)
    data = b""
    try:
        while not data.endswith(b"\n"):
            chunk = stream.recv(1)
            if not chunk:
                return None
            data += chunk
    except socket.timeout:
        return None
    return data.decode()


def device():
    listed = [d for d in json.loads(control("inputs-json").split("\n", 1)[1]) if d["name"] == NAME]
    return listed[0] if len(listed) == 1 else None


def wait_for(probe, seconds=3):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if probe():
            return True
        time.sleep(0.05)
    return probe()


def fires():
    try:
        with open(os.path.join(os.environ["XDG_RUNTIME_DIR"], "input-devices-e2e-fires")) as log:
            return len(log.readlines())
    except FileNotFoundError:
        return 0


def rule(enabled):
    reply = control(f'eval zl.input_rule({{ device = "^(zoo input rule.*)$", enabled = {str(enabled).lower()} }})')
    check(f"input_rule enabled={enabled} is accepted", reply.startswith("OK"), repr(reply))


def main():
    keyboard = Keyboard()
    check("a plugged keyboard is listed enabled", wait_for(lambda: (device() or {}).get("enabled") is True), repr(device()))
    caps = (device() or {}).get("capabilities", {})
    check("it is listed as a keyboard only", caps.get("keyboard") is True and not caps.get("pointer"), repr(caps))
    keyboard.press("f1")
    check("its keys reach binds", wait_for(lambda: fires() == 1), f"{fires()} fires")

    watch = connect()
    line(watch)
    watch.sendall(b"watch-keyboard-layout\n")
    first = line(watch)
    check("a layout watch starts with the active layout", first == "OK keyboard-layout 0\tEnglish (US)\n", repr(first))
    keyboard.press("f1")
    quiet = line(watch, 0.5)
    check("a key that leaves the layout alone sends no event", quiet is None, repr(quiet))
    keyboard.press("layout")
    switched = line(watch)
    check("a layout switch with no client focused reaches the watcher", switched == "EVENT keyboard-layout 1\tEnglish (UK)\n", repr(switched))
    queried = control("keyboard-layout")
    check("the query agrees", queried == "OK keyboard-layout 1\tEnglish (UK)\n", repr(queried))

    rule(False)
    check("a rule disables the matching device", wait_for(lambda: (device() or {}).get("enabled") is False), repr(device()))
    check("the text report marks it", f'"{NAME}" (disabled)\n' in control("inputs"), control("inputs"))
    before = fires()
    keyboard.press("f1")
    keyboard.press("layout")
    stray = line(watch, 0.7)
    check("a disabled device sends nothing", fires() == before and stray is None, f"{fires() - before} fires, event {stray!r}")

    keyboard.unplug()
    check("an unplugged device leaves the report", wait_for(lambda: device() is None), repr(device()))
    keyboard = Keyboard()
    check("a device plugged in under the rule starts disabled", wait_for(lambda: (device() or {}).get("enabled") is False), repr(device()))
    keyboard.press("f1")
    time.sleep(0.5)
    check("and stays silent", fires() == before, f"{fires() - before} fires")

    rule(True)
    check("the rule enables it again", wait_for(lambda: (device() or {}).get("enabled") is True), repr(device()))
    keyboard.press("f1")
    check("and its keys reach binds again", wait_for(lambda: fires() == before + 1), f"{fires() - before} fires")

    rule(False)
    wait_for(lambda: (device() or {}).get("enabled") is False)
    reply = control("reload")
    check("a reload drops rules the config does not hold", reply.startswith("OK") and wait_for(lambda: (device() or {}).get("enabled") is True),
          f"{reply!r} {device()!r}")
    watch.close()
    keyboard.unplug()


if __name__ == "__main__":
    if sys.argv[1:] == ["--device"]:
        keyboard_device()
    else:
        main()
        sys.exit(failures)
