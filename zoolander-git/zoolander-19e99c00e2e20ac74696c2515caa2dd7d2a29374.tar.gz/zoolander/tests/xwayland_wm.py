#!/usr/bin/env python3
"""Drive zoolander's X11 window manager from a real X client and check what
the client sees: input focus, work area, ConfigureNotify traffic, root
property traffic and the floating size.

Run inside a live session (see xwayland_wm.sh): DISPLAY and XAUTHORITY reach
Xwayland, XDG_RUNTIME_DIR and WAYLAND_DISPLAY the control socket. Takes an
optional list of test names; exits non-zero when any check fails.
"""
import json
import os
import select
import socket
import subprocess
import sys
import time

from Xlib import X, Xatom, Xutil, display
from Xlib.protocol import event as xevent

d = display.Display()
screen = d.screen()
root = screen.root
failures = []


def atom(name):
    return d.intern_atom(name)


def check(name, ok, detail):
    print(f"{'PASS' if ok else 'FAIL'} {name}: {detail}", flush=True)
    if not ok:
        failures.append(name)


def collect(seconds):
    events = []
    end = time.monotonic() + seconds
    while True:
        while d.pending_events():
            events.append(d.next_event())
        left = end - time.monotonic()
        if left <= 0:
            return events
        select.select([d.fileno()], [], [], left)


def client_list():
    prop = d.screen().root.get_full_property(atom("_NET_CLIENT_LIST"), Xatom.WINDOW)
    return list(prop.value) if prop else []


def wait_for(predicate, seconds=5):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        collect(0.05)
        if predicate():
            return True
    return False


def make(name, w=300, h=200, kind=None, strut=None):
    win = root.create_window(0, 0, w, h, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                             background_pixel=screen.white_pixel,
                             event_mask=X.StructureNotifyMask | X.PropertyChangeMask)
    win.set_wm_name(name)
    win.set_wm_class(name, name)
    win.set_wm_hints(flags=Xutil.InputHint, input=1)
    if kind:
        win.change_property(atom("_NET_WM_WINDOW_TYPE"), Xatom.ATOM, 32, [atom(kind)])
    if strut:
        win.change_property(atom("_NET_WM_STRUT_PARTIAL"), Xatom.CARDINAL, 32, strut)
    win.map()
    d.sync()
    if not wait_for(lambda: win.id in client_list()):
        raise RuntimeError(f"{name} never became a managed client")
    collect(0.5)
    return win


def destroy(*windows):
    for win in windows:
        win.destroy()
    d.sync()
    wait_for(lambda: not any(w.id in client_list() for w in windows))
    collect(0.3)


def control(command):
    path = os.path.join(os.environ["XDG_RUNTIME_DIR"], "zoolander-" + os.path.basename(os.environ["WAYLAND_DISPLAY"]) + ".sock")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.connect(path)
        sock.sendall(command.encode() + b"\n")
        sock.shutdown(socket.SHUT_WR)
        reply = b""
        while chunk := sock.recv(4096):
            reply += chunk
    return reply.decode()


def activate(win):
    root.send_event(xevent.ClientMessage(window=win, client_type=atom("_NET_ACTIVE_WINDOW"), data=(32, [2, X.CurrentTime, 0, 0, 0])),
                    event_mask=X.SubstructureRedirectMask | X.SubstructureNotifyMask)
    d.sync()
    collect(0.5)


def test_focus():
    # A focus change made after the WM's last PropertyNotify must not make
    # the server reject the WM's next SetInputFocus as stale.
    a = make("focus-a")
    b = make("focus-b")
    b.set_input_focus(X.RevertToPointerRoot, X.CurrentTime)
    d.sync()
    collect(0.3)
    activate(a)
    focus = d.get_input_focus().focus
    check("focus", getattr(focus, "id", focus) == a.id, f"X input focus 0x{getattr(focus, 'id', 0):x}, activated 0x{a.id:x}")
    destroy(a, b)


def test_struts():
    width = screen.width_in_pixels
    dock = make("strut-dock", w=width, h=60, kind="_NET_WM_WINDOW_TYPE_DOCK", strut=[0, 0, 60, 0, 0, 0, 0, 0, 0, width - 1, 0, 0])
    tiled = make("strut-tiled")
    reserved = tiled.get_geometry().y
    check("strut reserves", reserved >= 60, f"tiled window y={reserved} with a 60px top strut")
    dock.change_property(atom("_NET_WM_STRUT_PARTIAL"), Xatom.CARDINAL, 32, [0, 0, 90, 0, 0, 0, 0, 0, 0, width - 1, 0, 0])
    d.sync()
    collect(0.5)
    grown = tiled.get_geometry().y
    check("strut follows its property", grown >= 90, f"tiled window y={grown} after the strut grew to 90px")
    dock.unmap()
    d.sync()
    wait_for(lambda: dock.id not in client_list())
    collect(0.5)
    released = tiled.get_geometry().y
    check("strut releases", released < 60, f"tiled window y={released} after the dock unmapped")
    destroy(dock, tiled)


def notifies(win, events):
    return [e for e in events if e.type == X.ConfigureNotify and e.window.id == win.id]


def test_configure_notify():
    floating = make("configure-float", kind="_NET_WM_WINDOW_TYPE_DIALOG")
    g = floating.get_geometry()
    floating.configure(width=g.width + 40, height=g.height + 30)
    d.sync()
    seen = notifies(floating, collect(1))
    synthetic = [e for e in seen if e.send_event]
    real = [e for e in seen if not e.send_event and e.width == g.width + 40]
    check("configure floating", len(real) >= 1 and not synthetic, f"{len(real)} real resize notifies, {len(synthetic)} synthetic")
    tiled = make("configure-tiled")
    tiled.configure(width=123, height=77)
    d.sync()
    seen = notifies(tiled, collect(1))
    synthetic = [e for e in seen if e.send_event]
    check("configure tiled", len(synthetic) == 1 and len(seen) == 1, f"{len(seen)} notifies, {len(synthetic)} synthetic")
    destroy(floating, tiled)


def test_property_traffic():
    win = make("property")
    root.change_attributes(event_mask=X.PropertyChangeMask)
    d.sync()
    collect(0.5)
    win.set_wm_name("property-renamed")
    d.sync()
    names = {d.get_atom_name(e.atom) for e in collect(1) if e.type == X.PropertyNotify and e.window.id == root.id}
    check("title change", not names, f"root properties rewritten: {sorted(names) or 'none'}")
    root.change_attributes(event_mask=X.NoEventMask)
    destroy(win)


def test_float_size():
    win = make("float-size", w=301, h=203)
    win.set_input_focus(X.RevertToPointerRoot, X.CurrentTime)
    reply = control("eval zl.toggle_floating()")
    d.sync()
    collect(0.5)
    g = win.get_geometry()
    check("float size", abs(g.width - 301) > 4 or abs(g.height - 203) > 4, f"floated at {g.width}x{g.height} (opened at 301x203), control: {reply.strip()!r}")
    destroy(win)


def states(win):
    prop = win.get_full_property(atom("_NET_WM_STATE"), Xatom.ATOM)
    return {d.get_atom_name(a) for a in prop.value} if prop else set()


def request_state(win, action, name):
    root.send_event(xevent.ClientMessage(window=win, client_type=atom("_NET_WM_STATE"), data=(32, [action, atom(name), 0, 1, 0])),
                    event_mask=X.SubstructureRedirectMask | X.SubstructureNotifyMask)
    d.sync()
    collect(0.5)


def test_state_requests():
    win = make("state")
    request_state(win, 1, "_NET_WM_STATE_FULLSCREEN")
    g = win.get_geometry()
    full = "_NET_WM_STATE_FULLSCREEN" in states(win)
    check("fullscreen request", full and (g.x, g.y) == (0, 0) and g.width >= 1280, f"states {sorted(states(win))}, geometry {g.x},{g.y} {g.width}x{g.height}")
    request_state(win, 0, "_NET_WM_STATE_FULLSCREEN")
    check("fullscreen release", "_NET_WM_STATE_FULLSCREEN" not in states(win), f"states {sorted(states(win))}")
    request_state(win, 1, "_NET_WM_STATE_DEMANDS_ATTENTION")
    check("attention while focused", "_NET_WM_STATE_DEMANDS_ATTENTION" not in states(win), f"states {sorted(states(win))}")
    request_state(win, 1, "_NET_WM_STATE_MODAL")
    check("modal request", "_NET_WM_STATE_MODAL" in states(win), f"states {sorted(states(win))}")
    destroy(win)


def test_start_hidden():
    # A client that maps already carrying _NET_WM_STATE_HIDDEN asks to start minimized.
    win = root.create_window(0, 0, 300, 200, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                             background_pixel=screen.white_pixel, event_mask=X.StructureNotifyMask | X.PropertyChangeMask)
    win.set_wm_name("hidden")
    win.set_wm_class("hidden", "hidden")
    win.change_property(atom("_NET_WM_STATE"), Xatom.ATOM, 32, [atom("_NET_WM_STATE_HIDDEN")])
    win.map()
    d.sync()
    managed = wait_for(lambda: win.id in client_list())
    collect(0.5)
    wm_state = win.get_full_property(atom("WM_STATE"), atom("WM_STATE"))
    iconic = wm_state is not None and wm_state.value[0] == 3
    check("start hidden", managed and iconic and "_NET_WM_STATE_HIDDEN" in states(win),
          f"managed {managed}, WM_STATE {list(wm_state.value) if wm_state else None}, states {sorted(states(win))}")
    destroy(win)


def test_no_minimize():
    reply = control('eval zl.add_window_rule("app_id", "^(no-minimize)$", { no_minimize = true })')
    check("no-minimize rule eval", "\nOK" in reply, repr(reply))
    win = None
    dyn_win = None
    try:
        win = root.create_window(0, 0, 300, 200, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                                 background_pixel=screen.white_pixel, event_mask=X.StructureNotifyMask | X.PropertyChangeMask)
        win.set_wm_name("no-minimize")
        win.set_wm_class("no-minimize", "no-minimize")
        win.change_property(atom("_NET_WM_STATE"), Xatom.ATOM, 32, [atom("_NET_WM_STATE_HIDDEN")])
        win.map()
        d.sync()
        managed = wait_for(lambda: win.id in client_list())
        collect(0.5)
        wm_state = win.get_full_property(atom("WM_STATE"), atom("WM_STATE"))
        normal = wm_state is not None and wm_state.value[0] == 1
        allowed = win.get_full_property(atom("_NET_WM_ALLOWED_ACTIONS"), Xatom.ATOM)
        allowed_names = {d.get_atom_name(a) for a in allowed.value} if allowed else set()
        check("no-minimize start", managed and normal and "_NET_WM_STATE_HIDDEN" not in states(win)
              and "_NET_WM_ACTION_MINIMIZE" not in allowed_names,
              f"managed {managed}, WM_STATE {list(wm_state.value) if wm_state else None}, states {sorted(states(win))}, allowed {sorted(allowed_names)}")
        send_root(win, "WM_CHANGE_STATE", [3])
        d.sync()
        collect(0.5)
        wm_state = win.get_full_property(atom("WM_STATE"), atom("WM_STATE"))
        normal = wm_state is not None and wm_state.value[0] == 1
        check("no-minimize change_state", normal and "_NET_WM_STATE_HIDDEN" not in states(win),
              f"WM_STATE {list(wm_state.value) if wm_state else None}, states {sorted(states(win))}")
        destroy(win)
        win = None

        dyn_win = make("plain-min")
        allowed = dyn_win.get_full_property(atom("_NET_WM_ALLOWED_ACTIONS"), Xatom.ATOM)
        allowed_names = {d.get_atom_name(a) for a in allowed.value} if allowed else set()
        check("plain allowed action", "_NET_WM_ACTION_MINIMIZE" in allowed_names, f"allowed {sorted(allowed_names)}")
        send_root(dyn_win, "WM_CHANGE_STATE", [3])
        d.sync()
        collect(0.5)
        wm_state = dyn_win.get_full_property(atom("WM_STATE"), atom("WM_STATE"))
        iconic = wm_state is not None and wm_state.value[0] == 3
        check("plain minimized", iconic and "_NET_WM_STATE_HIDDEN" in states(dyn_win),
              f"WM_STATE {list(wm_state.value) if wm_state else None}, states {sorted(states(dyn_win))}")
        dyn_win.set_wm_class("no-minimize", "no-minimize")
        d.sync()
        collect(0.5)
        wm_state = dyn_win.get_full_property(atom("WM_STATE"), atom("WM_STATE"))
        normal = wm_state is not None and wm_state.value[0] == 1
        allowed = dyn_win.get_full_property(atom("_NET_WM_ALLOWED_ACTIONS"), Xatom.ATOM)
        allowed_names = {d.get_atom_name(a) for a in allowed.value} if allowed else set()
        check("no-minimize reclass restore", normal and "_NET_WM_STATE_HIDDEN" not in states(dyn_win)
              and "_NET_WM_ACTION_MINIMIZE" not in allowed_names,
              f"WM_STATE {list(wm_state.value) if wm_state else None}, states {sorted(states(dyn_win))}, allowed {sorted(allowed_names)}")
    finally:
        for w in (win, dyn_win):
            if w is not None:
                destroy(w)
        control("reload")
        collect(0.3)


def root_writes(action, seconds=1):
    root.change_attributes(event_mask=X.PropertyChangeMask)
    d.sync()
    collect(0.5)
    action()
    d.sync()
    names = [d.get_atom_name(e.atom) for e in collect(seconds) if e.type == X.PropertyNotify and e.window.id == root.id]
    root.change_attributes(event_mask=X.NoEventMask)
    d.sync()
    return names


def send_root(win, name, data):
    root.send_event(xevent.ClientMessage(window=win, client_type=atom(name), data=(32, data + [0] * (5 - len(data)))),
                    event_mask=X.SubstructureRedirectMask | X.SubstructureNotifyMask)


def cardinal(win, name):
    prop = win.get_full_property(atom(name), Xatom.CARDINAL)
    return prop.value[0] if prop else None


def test_root_sync():
    # Each root sync rewrites _NET_CURRENT_DESKTOP once, so its count is the number of syncs.
    win = make("root-sync")
    activate(win)
    names = root_writes(lambda: send_root(win, "_NET_WM_STATE", [1, atom("_NET_WM_STATE_FULLSCREEN"), 0, 1]))
    check("fullscreen root sync", "_NET_WM_STATE_FULLSCREEN" in states(win) and not names, f"root properties rewritten: {sorted(set(names)) or 'none'}")
    request_state(win, 0, "_NET_WM_STATE_FULLSCREEN")
    count = cardinal(root, "_NET_NUMBER_OF_DESKTOPS")
    names = root_writes(lambda: send_root(win, "_NET_WM_DESKTOP", [count, 1]))
    check("missing window desktop root sync", not names and cardinal(win, "_NET_WM_DESKTOP") == 0, f"moving to desktop {count} rewrote {sorted(set(names)) or 'nothing'}")
    names = root_writes(lambda: send_root(win, "_NET_WM_DESKTOP", [1, 1]))
    syncs = names.count("_NET_CURRENT_DESKTOP")
    check("window desktop root sync", syncs == 2 and cardinal(win, "_NET_WM_DESKTOP") == 1, f"moving to desktop 1: _NET_WM_DESKTOP={cardinal(win, '_NET_WM_DESKTOP')}, {syncs} root syncs")
    destroy(win)
    # Without windows no focus change adds its own sync: the switch syncs once and the request once more.
    names = root_writes(lambda: send_root(root, "_NET_CURRENT_DESKTOP", [count, X.CurrentTime]))
    check("missing desktop root sync", not names, f"{count} desktops, activating desktop {count} rewrote {sorted(set(names)) or 'nothing'}")
    names = root_writes(lambda: send_root(root, "_NET_CURRENT_DESKTOP", [1, X.CurrentTime]))
    syncs = names.count("_NET_CURRENT_DESKTOP")
    check("current desktop root sync", syncs == 2, f"activating desktop 1: {syncs} root syncs")
    send_root(root, "_NET_CURRENT_DESKTOP", [0, X.CurrentTime])
    d.sync()
    collect(0.5)


def test_map_desktop():
    win = root.create_window(0, 0, 300, 200, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                             background_pixel=screen.white_pixel, event_mask=X.StructureNotifyMask)
    win.set_wm_name("map-desktop")
    win.set_wm_class("map-desktop", "map-desktop")
    win.change_property(atom("_NET_WM_DESKTOP"), Xatom.CARDINAL, 32, [1])
    win.map()
    d.sync()
    managed = wait_for(lambda: win.id in client_list())
    collect(0.5)
    desktop = cardinal(win, "_NET_WM_DESKTOP")
    check("map desktop", managed and desktop == 1, f"opened on desktop {desktop}")
    destroy(win)


def test_home_output():
    # Scrolled-off windows sit over the second output, whose scale differs
    # from their home output's; their X size must still use the home scale.
    wins = [make(f"home-{i}") for i in range(3)]
    # zl.set_layout reaches only the focused output's workspace: focus the windows' output first.
    activate(wins[0])
    control('eval zl.set_layout("scrolling")')
    activate(wins[0])
    rects = [(g.x, g.y, g.width, g.height) for g in (w.get_geometry() for w in wins)]
    check("home output", len({r[2:] for r in rects}) == 1, f"X rects {rects}")
    destroy(*wins)
    control('eval zl.set_layout("dwindle")')


def test_clients():
    before = set(client_list())
    procs = [subprocess.Popen(argv) for argv in (["xterm"], ["xeyes"])]
    managed = wait_for(lambda: len(set(client_list()) - before) == len(procs), 10)
    check("real clients", managed, f"{len(set(client_list()) - before)} of {len(procs)} clients managed")
    for proc in procs:
        proc.terminate()
        proc.wait()
    wait_for(lambda: set(client_list()) <= before)


def test_ctl_clients():
    # _NET_WM_PID is set to a pid that is not ours: the server's own record of the connection wins.
    title = 'x11 "quoted"\t\\ ünïcødé ☃'
    win = root.create_window(0, 0, 300, 200, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                             background_pixel=screen.white_pixel, event_mask=X.StructureNotifyMask)
    win.change_property(atom("_NET_WM_NAME"), atom("UTF8_STRING"), 8, title.encode())
    win.set_wm_class("e2e-instance", "E2EClass")
    win.change_property(atom("_NET_WM_PID"), Xatom.CARDINAL, 32, [1])
    win.map()
    d.sync()
    wait_for(lambda: win.id in client_list())
    collect(0.5)
    text = control("clients")
    print(text, flush=True)
    reply = control("clients-json").split("\n")
    print(reply[2], flush=True)
    found = [c for c in json.loads(reply[2]) if c["class"] == "E2EClass"]
    check("ctl clients json", reply[1] == "OK json" and len(found) == 1, f"{reply[1]!r}, {len(found)} windows of class E2EClass")
    if found:
        c = found[0]
        check("ctl clients x11 pid", c["pid"] == os.getpid(), f"pid {c['pid']}, ours {os.getpid()}")
        check("ctl clients x11 fields", c["xwayland"] and c["instance"] == "e2e-instance" and c["app_id"] == "E2EClass" and c["title"] == title, repr(c))
    check("ctl clients x11 text", 'class: "E2EClass" instance: "e2e-instance"' in text and "kind: xwayland" in text, text)
    destroy(win)


def test_restart():
    # Runs last: the XWM connection this script holds goes away with Xwayland.
    global d
    control("eval zl.set_xwayland({ enabled = false })")
    time.sleep(1)
    control("eval zl.set_xwayland({ enabled = true, force_zero_scaling = true })")
    time.sleep(1)
    proc = subprocess.Popen(["xeyes"])
    try:
        d = display.Display()
        ok = wait_for(lambda: len(client_list()) == 1, 10)
    except Exception as err:
        ok = False
        print(err)
    check("restart", ok, "a new Xwayland manages a client after disable and enable")
    proc.terminate()
    proc.wait()


tests = {"focus": test_focus, "struts": test_struts, "configure": test_configure_notify,
         "property": test_property_traffic, "float": test_float_size, "state": test_state_requests, "start-hidden": test_start_hidden,
         "no-minimize": test_no_minimize, "root-sync": test_root_sync,
         "map-desktop": test_map_desktop, "home": test_home_output,
         "clients": test_clients, "ctl-clients": test_ctl_clients, "restart": test_restart}
# Each output starts with one workspace, so on a single output the desktop
# tests need a second desktop to move to.
if cardinal(root, "_NET_NUMBER_OF_DESKTOPS") < 2:
    control('eval zl.workspace("2")')
    control('eval zl.workspace("1")')
    collect(0.5)
for name in sys.argv[1:] or tests:
    tests[name]()
print("FAILED: " + ", ".join(failures) if failures else "ALL PASSED", flush=True)
sys.exit(1 if failures else 0)
