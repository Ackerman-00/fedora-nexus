#!/usr/bin/env python3
"""Raw-wire proof that the compositor waits on the acquire point of every
explicit-sync (linux-drm-syncobj-v1) commit, not only the first.

Run against a live zoolander on a real GPU: WAYLAND_DISPLAY and
XDG_RUNTIME_DIR must point at it, the vgem module must be loaded, and
/dev/dri/renderD128 must be the GPU the compositor renders with. Without vgem,
or when the compositor offers no dmabuf or syncobj global (the software
renderer), it prints SKIP and passes.

  syncobj_acquire_e2e.py [N]

The compositor holds each commit until its acquire point has signalled, so
no update whose rendering is unfinished is ever latched. Each commit goes
through three phases:

  unavailable  the point has no fence yet: the commit must be held
  pending      the point carries a vgem fence that is not signaled: the commit
               is still held, so nothing sampling the buffer may reach the
               screen and no presented feedback may arrive
  signaled     the vgem fence is signaled: the commit must be presented

A commit "waited" when nothing arrived before its fence was signaled.
"""
import array
import ctypes
import fcntl
import os
import socket
import struct
import sys
import time

DISPLAY, REGISTRY = 1, 2
XRGB8888 = 0x34325258
HOLD = 0.3
FEEDBACK = ("sync_output", "presented", "discarded")


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


def ioc(direction, kind, nr, size):
    return direction << 30 | size << 16 | ord(kind) << 8 | nr


def iowr(nr, size, kind="d"):
    return ioc(3, kind, nr, size)


SYNCOBJ_CREATE = iowr(0xBF, 8)
SYNCOBJ_HANDLE_TO_FD = iowr(0xC1, 16)
SYNCOBJ_FD_TO_HANDLE = iowr(0xC2, 16)
SYNCOBJ_TRANSFER = iowr(0xCC, 32)
SYNCOBJ_QUERY = iowr(0xCB, 24)
MODE_CREATE_DUMB = iowr(0xB2, 32)
PRIME_HANDLE_TO_FD = iowr(0x2D, 12)
VGEM_FENCE_ATTACH = iowr(0x41, 16)
VGEM_FENCE_SIGNAL = ioc(1, "d", 0x42, 8)
DMA_BUF_EXPORT_SYNC_FILE = iowr(0x02, 8, "b")
IMPORT_SYNC_FILE = 1


def ioctl(fd, request, fmt, *values):
    data = bytearray(struct.pack(fmt, *values))
    fcntl.ioctl(fd, request, data)
    return struct.unpack(fmt, data)


class Timeline:
    def __init__(self, drm):
        self.drm = drm
        self.handle = ioctl(drm, SYNCOBJ_CREATE, "<II", 0, 0)[0]
        self.fd = ioctl(drm, SYNCOBJ_HANDLE_TO_FD, "<IIii", self.handle, 0, -1, 0)[2]

    def signaled(self):
        points = array.array("Q", [0])
        handles = array.array("I", [self.handle])
        ioctl(self.drm, SYNCOBJ_QUERY, "<QQII", handles.buffer_info()[0], points.buffer_info()[0], 1, 0)
        return points[0]

    def attach_sync_file(self, sync_file, point):
        binary = ioctl(self.drm, SYNCOBJ_CREATE, "<II", 0, 0)[0]
        ioctl(self.drm, SYNCOBJ_FD_TO_HANDLE, "<IIii", binary, IMPORT_SYNC_FILE, sync_file, 0)
        ioctl(self.drm, SYNCOBJ_TRANSFER, "<IIQQII", binary, self.handle, 0, point, 0, 0)


class VgemFence:
    """An unsignaled dma_fence the test signals by hand (vgem auto-signals after 10s)."""

    def __init__(self):
        for name in sorted(os.listdir("/dev/dri")):
            if name.startswith("card") and os.path.basename(os.path.realpath(f"/sys/class/drm/{name}/device")) == "vgem":
                self.fd = os.open(f"/dev/dri/{name}", os.O_RDWR)
                break
        else:
            raise RuntimeError("vgem is not loaded (sudo modprobe vgem)")
        _, _, _, _, self.bo, _, _ = ioctl(self.fd, MODE_CREATE_DUMB, "<IIIIIIQ", 1, 1024, 32, 0, 0, 0, 0)
        self.dmabuf = ioctl(self.fd, PRIME_HANDLE_TO_FD, "<IIi", self.bo, os.O_CLOEXEC | os.O_RDWR, -1)[2]

    def arm(self):
        """Attach a write fence and return (fence id, sync_file fd)."""
        fence = ioctl(self.fd, VGEM_FENCE_ATTACH, "<IIII", self.bo, 1, 0, 0)[2]
        sync_file = ioctl(self.dmabuf, DMA_BUF_EXPORT_SYNC_FILE, "<Ii", 3, -1)[1]
        return fence, sync_file

    def signal(self, fence):
        ioctl(self.fd, VGEM_FENCE_SIGNAL, "<II", fence, 0)


class Gbm:
    def __init__(self, drm):
        lib = ctypes.CDLL("libgbm.so.1")
        lib.gbm_create_device.restype = ctypes.c_void_p
        lib.gbm_create_device.argtypes = [ctypes.c_int]
        lib.gbm_bo_create.restype = ctypes.c_void_p
        lib.gbm_bo_create.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
        for name, res in (("gbm_bo_get_fd", ctypes.c_int), ("gbm_bo_get_stride", ctypes.c_uint32),
                          ("gbm_bo_get_offset", ctypes.c_uint32), ("gbm_bo_get_modifier", ctypes.c_uint64)):
            getattr(lib, name).restype = res
        lib.gbm_bo_get_fd.argtypes = [ctypes.c_void_p]
        lib.gbm_bo_get_stride.argtypes = [ctypes.c_void_p]
        lib.gbm_bo_get_modifier.argtypes = [ctypes.c_void_p]
        lib.gbm_bo_get_offset.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self.lib = lib
        self.device = lib.gbm_create_device(drm)
        if not self.device:
            raise RuntimeError("gbm_create_device failed")

    def bo(self, width, height):
        # GBM_BO_USE_RENDERING | GBM_BO_USE_LINEAR
        bo = self.lib.gbm_bo_create(self.device, width, height, XRGB8888, 1 << 2 | 1 << 4)
        if not bo:
            raise RuntimeError("gbm_bo_create failed")
        return (self.lib.gbm_bo_get_fd(bo), self.lib.gbm_bo_get_stride(bo),
                self.lib.gbm_bo_get_offset(bo, 0), self.lib.gbm_bo_get_modifier(bo))


class Client:
    def __init__(self):
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(path)
        self.buffer = b""
        self.next_id = 3
        self.handlers = {}
        self.globals = {}
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.on(REGISTRY, self._global)
        self.roundtrip()

    def _global(self, opcode, body):
        if opcode != 0:
            return
        name, = struct.unpack_from("<I", body)
        interface, at = read_string(body, 4)
        version, = struct.unpack_from("<I", body, at)
        self.globals.setdefault(interface, (name, version))

    def new_id(self):
        self.next_id += 1
        return self.next_id - 1

    def on(self, obj, handler):
        self.handlers[obj] = handler

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
        else:
            self.sock.sendall(data)

    def bind(self, interface, version):
        name, advertised = self.globals[interface]
        obj = self.new_id()
        self.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", min(version, advertised), obj)))
        return obj

    def dispatch(self, timeout):
        self.sock.settimeout(max(timeout, 0.001))
        try:
            fds = array.array("i")
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * fds.itemsize))
        except socket.timeout:
            return
        for level, kind, payload in ancillary:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                fds.frombytes(payload[:len(payload) - len(payload) % fds.itemsize])
        for fd in fds:
            os.close(fd)
        if not data:
            raise ConnectionError("compositor closed the connection")
        self.buffer += data
        while len(self.buffer) >= 8:
            obj, word = struct.unpack_from("<II", self.buffer)
            size = word >> 16
            if len(self.buffer) < size:
                break
            body, self.buffer = self.buffer[8:size], self.buffer[size:]
            if obj == DISPLAY and word & 0xFFFF == 0:
                failed, code = struct.unpack_from("<II", body)
                raise RuntimeError(f"protocol error on object {failed} code {code}: {read_string(body, 8)[0]}")
            if obj in self.handlers:
                self.handlers[obj](word & 0xFFFF, body)

    def pump(self, seconds, done=lambda: False):
        end = time.monotonic() + seconds
        while not done() and (left := end - time.monotonic()) > 0:
            self.dispatch(left)

    def roundtrip(self):
        callback = self.new_id()
        state = {"done": False}
        self.on(callback, lambda op, body: state.update(done=True))
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        self.pump(5.0, lambda: state["done"])
        if not state["done"]:
            raise TimeoutError("roundtrip timed out")


def main():
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    width, height = 512, 384
    client = Client()
    missing = [name for name in ("zwp_linux_dmabuf_v1", "wp_linux_drm_syncobj_manager_v1") if name not in client.globals]
    if not os.path.isdir("/sys/module/vgem"):
        missing.append("vgem")
    if missing:
        print(f"SKIP: no {', '.join(missing)}")
        return 0
    drm = os.open("/dev/dri/renderD128", os.O_RDWR)
    gbm = Gbm(drm)
    vgem = VgemFence()
    acquire, release = Timeline(drm), Timeline(drm)

    wm = client.bind("xdg_wm_base", 1)
    client.on(wm, lambda op, body: client.send(message(wm, 3, body[:4])) if op == 0 else None)
    compositor = client.bind("wl_compositor", 4)
    dmabuf = client.bind("zwp_linux_dmabuf_v1", 3)
    client.on(dmabuf, lambda op, body: None)
    syncobj = client.bind("wp_linux_drm_syncobj_manager_v1", 1)
    presentation = client.bind("wp_presentation", 1)
    client.on(presentation, lambda op, body: None)

    surface = client.new_id()
    client.send(message(compositor, 0, struct.pack("<I", surface)))
    client.on(surface, lambda op, body: None)
    sync_surface = client.new_id()
    client.send(message(syncobj, 1, struct.pack("<II", sync_surface, surface)))
    timelines = {}
    for name, timeline in (("acquire", acquire), ("release", release)):
        timelines[name] = client.new_id()
        client.send(message(syncobj, 2, struct.pack("<I", timelines[name])), [timeline.fd])

    xdg = client.new_id()
    client.send(message(wm, 2, struct.pack("<II", xdg, surface)))
    toplevel = client.new_id()
    client.send(message(xdg, 1, struct.pack("<I", toplevel)))
    client.send(message(toplevel, 3, string("syncobj-acquire-e2e")))
    serial = []
    client.on(xdg, lambda op, body: serial.append(struct.unpack_from("<I", body)[0]) if op == 0 else None)
    client.on(toplevel, lambda op, body: None)
    client.send(message(surface, 6))
    client.pump(5.0, lambda: serial)
    client.send(message(xdg, 4, struct.pack("<I", serial[-1])))

    buffers = []
    for _ in range(count):
        fd, stride, offset, modifier = gbm.bo(width, height)
        params = client.new_id()
        client.send(message(dmabuf, 1, struct.pack("<I", params)))
        client.send(message(params, 1, struct.pack("<IIIII", 0, offset, stride, modifier >> 32, modifier & 0xFFFFFFFF)), [fd])
        os.close(fd)
        buffer = client.new_id()
        client.send(message(params, 3, struct.pack("<IiiII", buffer, width, height, XRGB8888, 0)))
        client.send(message(params, 0))
        client.on(buffer, lambda op, body: None)
        buffers.append(buffer)
    client.roundtrip()
    print(f"buffers: {count} x {width}x{height} XRGB8888 modifier 0x{modifier:016x}, acquire/release timelines on renderD128")

    results = []
    for k in range(1, count + 1):
        events = {}
        hi, lo = k >> 32, k & 0xFFFFFFFF
        client.send(message(sync_surface, 1, struct.pack("<III", timelines["acquire"], hi, lo)))
        client.send(message(sync_surface, 2, struct.pack("<III", timelines["release"], hi, lo)))
        client.send(message(surface, 1, struct.pack("<Iii", buffers[k - 1], 0, 0)))
        client.send(message(surface, 9, struct.pack("<iiii", 0, 0, width, height)))
        callback = client.new_id()
        client.on(callback, lambda op, body, events=events: events.setdefault("frame", time.monotonic()))
        client.send(message(surface, 3, struct.pack("<I", callback)))
        feedback = client.new_id()
        client.on(feedback, lambda op, body, events=events: events.setdefault(FEEDBACK[op], time.monotonic()))
        client.send(message(presentation, 1, struct.pack("<II", surface, feedback)))
        prior_release = release.signaled()
        client.send(message(surface, 6))

        client.pump(HOLD)
        unavailable = sorted(events)

        fence, sync_file = vgem.arm()
        acquire.attach_sync_file(sync_file, k)
        os.close(sync_file)
        available = time.monotonic()
        client.pump(HOLD)
        pending = sorted(events)
        released_while_pending = release.signaled() > prior_release

        vgem.signal(fence)
        signaled = time.monotonic()
        client.pump(3.0, lambda: "frame" in events and ("presented" in events or "discarded" in events))
        rel = {key: f"{(at - signaled) * 1000:+.1f}ms" for key, at in sorted(events.items(), key=lambda kv: kv[1])}
        early = [key for key in ("presented", "discarded") if key in events and events[key] < signaled]
        waited = not early and not unavailable and not pending
        applied = "presented" in events
        results.append((k, waited, applied))
        print(f"commit {k}: acquire point {k} | before fence: {unavailable or 'none'} | "
              f"fence attached, unsignaled for {(signaled - available) * 1000:.0f}ms: {pending or 'none'}"
              f" (release point {prior_release} -> {release.signaled() if released_while_pending else prior_release} while pending) | "
              f"events relative to signal: {rel} | {'WAITED' if waited else 'DID NOT WAIT: ' + ','.join(early or unavailable or pending)}"
              f"{'' if applied else ' | NOT APPLIED after signal'}")

    print()
    print("commit  waited-on-acquire  applied-after-signal")
    for k, waited, applied in results:
        print(f"{k:>6}  {'yes' if waited else 'NO':>17}  {'yes' if applied else 'NO':>20}")
    if all(waited and applied for _, waited, applied in results):
        print("PASS: every commit waited on its acquire point")
        return 0
    print("FAIL: " + ", ".join(f"commit {k}" for k, waited, applied in results if not (waited and applied))
          + " did not wait on its acquire point")
    return 1


if __name__ == "__main__":
    sys.exit(main())
