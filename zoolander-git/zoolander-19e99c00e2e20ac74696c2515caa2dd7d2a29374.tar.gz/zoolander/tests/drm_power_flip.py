#!/usr/bin/env python3
"""Toggle an output off and on through wlr-output-power while another client
keeps page flips in flight, and require frames to keep completing.

Powering an output off drains its pending flips from inside the request
handler. When the DRM fd became ready in the same loop batch, its own
handler then finds the fd empty; that read must not stop flip delivery.
Padding each power request with ~40-110 KiB of cheap requests makes the
compositor read this client over several wakeups, so the request lands in
a batch where the client is listed ahead of a freshly completed flip.

Run against a live DRM compositor: WAYLAND_DISPLAY and XDG_RUNTIME_DIR must
point at it. Usage: drm_power_flip.py [cycles]
"""
import mmap
import os
import random
import select
import socket
import struct
import sys
import threading
import time

DISPLAY, REGISTRY = 1, 2
WIDTH, HEIGHT = 256, 256


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


class Client:
    def __init__(self):
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(path)
        self.buffer = b""
        self.next_id = REGISTRY
        self.handlers = {}
        self.globals = {}

        def registry(opcode, body):
            if opcode == 0:
                (name,) = struct.unpack_from("<I", body)
                interface, _ = read_string(body, 4)
                self.globals.setdefault(interface, name)

        self.handlers[REGISTRY] = registry
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        synced = []
        sync = self.new_id()
        self.handlers[sync] = lambda *_: synced.append(1)
        self.send(message(DISPLAY, 0, struct.pack("<I", sync)))
        self.wait(lambda: synced, 5, "registry sync")

    def new_id(self):
        self.next_id += 1
        return self.next_id

    def bind(self, interface, version):
        if interface not in self.globals:
            raise RuntimeError(f"{interface} not advertised")
        obj = self.new_id()
        self.send(message(REGISTRY, 0, struct.pack("<I", self.globals[interface]) + string(interface) + struct.pack("<II", version, obj)))
        return obj

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, struct.pack(f"<{len(fds)}i", *fds))])
        else:
            self.sock.sendall(data)

    def pump(self, timeout):
        """Dispatch whatever arrives within `timeout` seconds."""
        deadline = time.monotonic() + timeout
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                return
            ready, _, _ = select.select([self.sock], [], [], left)
            if not ready:
                return
            data = self.sock.recv(65536)
            if not data:
                raise ConnectionError("compositor closed the connection")
            self.buffer += data
            while len(self.buffer) >= 8:
                obj, word = struct.unpack_from("<II", self.buffer)
                size = word >> 16
                if len(self.buffer) < size:
                    break
                body, self.buffer = self.buffer[8:size], self.buffer[size:]
                opcode = word & 0xFFFF
                if obj == DISPLAY and opcode == 0:
                    failed, code = struct.unpack_from("<II", body)
                    text, _ = read_string(body, 8)
                    raise RuntimeError(f"protocol error on object {failed} code {code}: {text}")
                handler = self.handlers.get(obj)
                if handler:
                    handler(opcode, body)

    def wait(self, done, timeout, what):
        deadline = time.monotonic() + timeout
        while not done():
            if time.monotonic() >= deadline:
                raise TimeoutError(what)
            self.pump(min(0.05, deadline - time.monotonic()))


class FrameDriver:
    """A toplevel that commits a new frame whenever the last one completed."""

    def __init__(self):
        self.frames = 0
        self.error = None
        c = self.c = Client()
        compositor = c.bind("wl_compositor", 4)
        shm = c.bind("wl_shm", 1)
        wm_base = c.bind("xdg_wm_base", 1)
        c.handlers[wm_base] = lambda op, body: c.send(message(wm_base, 3, body[:4])) if op == 0 else None
        stride = WIDTH * 4
        self.size = stride * HEIGHT
        fd = os.memfd_create("drm-power-flip")
        os.ftruncate(fd, self.size * 2)
        self.pixels = mmap.mmap(fd, self.size * 2)
        pool = c.new_id()
        c.send(message(shm, 0, struct.pack("<II", pool, self.size * 2)), [fd])
        os.close(fd)
        self.buffers = []
        for n in range(2):
            b = c.new_id()
            c.send(message(pool, 0, struct.pack("<IiiiiI", b, n * self.size, WIDTH, HEIGHT, stride, 1)))
            self.buffers.append(b)
        self.surface = c.new_id()
        c.send(message(compositor, 0, struct.pack("<I", self.surface)))
        xdg_surface = c.new_id()
        c.send(message(wm_base, 2, struct.pack("<II", xdg_surface, self.surface)))
        c.send(message(xdg_surface, 1, struct.pack("<I", c.new_id())))
        configured = []

        def on_xdg_surface(opcode, body):
            if opcode == 0:
                c.send(message(xdg_surface, 4, body[:4]))
                configured.append(1)

        c.handlers[xdg_surface] = on_xdg_surface
        c.send(message(self.surface, 6))
        c.wait(lambda: configured, 5, "first configure")
        self.pending = False
        self.committed_at = 0.0

    def commit(self):
        c = self.c
        which = self.frames & 1
        offset = which * self.size
        self.pixels[offset:offset + 4] = struct.pack("<I", self.frames & 0xFFFFFF)
        callback = c.new_id()

        def done(opcode, body, callback=callback):
            del c.handlers[callback]
            self.frames += 1
            self.pending = False

        c.handlers[callback] = done
        c.send(message(self.surface, 1, struct.pack("<Iii", self.buffers[which], 0, 0))
               + message(self.surface, 2, struct.pack("<iiii", 0, 0, WIDTH, HEIGHT))
               + message(self.surface, 3, struct.pack("<I", callback))
               + message(self.surface, 6))
        self.pending = True
        self.committed_at = time.monotonic()

    def run(self):
        try:
            while True:
                # A callback queued while the output was off may never fire; a fresh commit asks again.
                if not self.pending or time.monotonic() - self.committed_at > 0.5:
                    self.commit()
                self.c.pump(0.002)
        except Exception as err:
            self.error = err


def main():
    cycles = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    driver = FrameDriver()
    threading.Thread(target=driver.run, daemon=True).start()

    c = Client()
    output = c.bind("wl_output", 1)
    manager = c.bind("zwlr_output_power_manager_v1", 1)
    compositor = c.bind("wl_compositor", 4)
    region = c.new_id()
    c.send(message(compositor, 1, struct.pack("<I", region)))
    pad = message(region, 1, struct.pack("<iiii", 0, 0, 1, 1))
    power = c.new_id()
    modes = []

    def on_power(opcode, body):
        if opcode == 0:
            modes.append(struct.unpack_from("<I", body)[0])
        elif opcode == 1:
            raise RuntimeError("output power failed")

    c.handlers[power] = on_power
    c.send(message(manager, 0, struct.pack("<II", power, output)))
    c.wait(lambda: modes, 5, "initial power mode")

    rng = random.Random(1)
    for cycle in range(cycles):
        before = driver.frames
        start = time.monotonic()
        while driver.frames < before + 3:
            if driver.error:
                raise driver.error
            if time.monotonic() - start >= 3:
                raise RuntimeError(f"cycle {cycle}: frames stopped completing ({driver.frames - before} in 3s)")
            time.sleep(0.005)
        time.sleep(rng.uniform(0, 0.017))
        for mode in (0, 1):
            modes.clear()
            c.send(pad * rng.randint(1700, 4600) + message(power, 0, struct.pack("<I", mode)))
            c.wait(lambda: mode in modes, 5, f"cycle {cycle}: power mode {mode}")
    print(f"PASS: {cycles} power cycles, {driver.frames} frames completed")


if __name__ == "__main__":
    try:
        main()
    except Exception as err:
        print(f"FAIL: {err}", file=sys.stderr)
        sys.exit(1)
