#!/usr/bin/env python3
"""Keyboard focus and popup grab behaviour, driven over the raw wire.

Two xdg toplevels (A and B), a floating decorated toplevel (C) and a wlr
virtual pointer run against a live compositor started with
tests/focus_e2e.lua as its config (click focus, a no-modifier middle-button
bind, a repeating F1 bind that appends a line to
$XDG_RUNTIME_DIR/focus-e2e-repeat, and
server-side decorations on floating windows). Keys are held on a uinput
keyboard (virtual-keyboard clients bypass compositor binds), so sudo must
work without a password.
WAYLAND_DISPLAY and XDG_RUNTIME_DIR must point at the compositor. Each check
prints PASS or FAIL; the exit status is the number of failures.
"""
import array
import fcntl
import mmap
import os
import socket
import struct
import subprocess
import sys
import time

DISPLAY, REGISTRY = 1, 2
BTN_LEFT, BTN_MIDDLE = 0x110, 0x112
TITLEBAR = 30
EXTENT = 1000
# Above the floating window, which opens centred.
ROW = 0.2


def message(obj, opcode, payload=b""):
    return struct.pack("<II", obj, (8 + len(payload)) << 16 | opcode) + payload


def string(text):
    raw = text.encode() + b"\0"
    return struct.pack("<I", len(raw)) + raw + b"\0" * (-len(raw) % 4)


def read_string(body, at):
    (size,) = struct.unpack_from("<I", body, at)
    return body[at + 4:at + 3 + size].decode(), at + 4 + size + (-size % 4)


class Client:
    def __init__(self, name):
        self.name = name
        path = os.path.join(os.environ["XDG_RUNTIME_DIR"], os.environ.get("WAYLAND_DISPLAY", "wayland-0"))
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect(path)
        self.buffer = b""
        self.next_id = 3
        self.handlers = {}
        self.log = []
        self.globals = {}
        self.send(message(DISPLAY, 1, struct.pack("<I", REGISTRY)))
        self.handlers[REGISTRY] = self.on_registry
        self.sync()

    def new_id(self, handler=None):
        obj = self.next_id
        self.next_id += 1
        if handler:
            self.handlers[obj] = handler
        return obj

    def send(self, data, fds=()):
        if fds:
            self.sock.sendmsg([data], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
        else:
            self.sock.sendall(data)

    def on_registry(self, opcode, body):
        if opcode == 0:
            (name,) = struct.unpack_from("<I", body)
            interface, at = read_string(body, 4)
            (version,) = struct.unpack_from("<I", body, at)
            self.globals[interface] = (name, version)

    def bind(self, interface, version, handler=None):
        name, advertised = self.globals[interface]
        obj = self.new_id(handler)
        self.send(message(REGISTRY, 0, struct.pack("<I", name) + string(interface) + struct.pack("<II", min(version, advertised), obj)))
        return obj

    def sync(self):
        callback = self.new_id()
        self.send(message(DISPLAY, 0, struct.pack("<I", callback)))
        while True:
            while len(self.buffer) >= 8:
                obj, word = struct.unpack_from("<II", self.buffer)
                size = word >> 16
                if len(self.buffer) < size:
                    break
                body, self.buffer = self.buffer[8:size], self.buffer[size:]
                opcode = word & 0xFFFF
                if obj == DISPLAY and opcode == 0:
                    failed, code = struct.unpack_from("<II", body)
                    text, _ = read_string(body, 8)
                    raise RuntimeError(f"{self.name}: protocol error on object {failed} code {code}: {text}")
                if obj == callback:
                    return
                if obj in self.handlers:
                    self.handlers[obj](opcode, body)
            fds = array.array("i")
            data, ancillary, _, _ = self.sock.recvmsg(65536, socket.CMSG_SPACE(28 * fds.itemsize))
            for level, kind, payload in ancillary:
                if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                    fds.frombytes(payload[:len(payload) - len(payload) % fds.itemsize])
            for fd in fds:
                os.close(fd)
            if not data:
                raise ConnectionError(f"{self.name}: compositor closed the connection")
            self.buffer += data


class App(Client):
    """One xdg client with a seat keyboard and pointer, logging focus events."""

    def __init__(self, name):
        super().__init__(name)
        self.compositor = self.bind("wl_compositor", 4)
        self.shm = self.bind("wl_shm", 1)
        self.wm_base = self.bind("xdg_wm_base", 2, self.on_wm_base)
        self.seat = self.bind("wl_seat", 5)
        self.keyboard = self.new_id(self.on_keyboard)
        self.send(message(self.seat, 1, struct.pack("<I", self.keyboard)))
        self.pointer = self.new_id(self.on_pointer)
        self.send(message(self.seat, 0, struct.pack("<I", self.pointer)))
        self.surfaces = {}
        self.configures = {}
        self.popup_done = set()
        self.last_press = None
        self.keyboard_focus = None
        self.pointer_at = None
        self.events = {}
        self.sync()

    def watch(self, label, names):
        obj = self.new_id(lambda opcode, _: self.log.append((label, names[opcode])))
        return obj

    def on_wm_base(self, opcode, body):
        if opcode == 0:
            self.send(message(self.wm_base, 3, body[:4]))

    def on_keyboard(self, opcode, body):
        if opcode == 1:
            _, surface = struct.unpack_from("<II", body)
            self.keyboard_focus = surface
            self.log.append(("kbd_enter", self.surfaces.get(surface, surface)))
        elif opcode == 2:
            _, surface = struct.unpack_from("<II", body)
            self.keyboard_focus = None
            self.log.append(("kbd_leave", self.surfaces.get(surface, surface)))

    def on_pointer(self, opcode, body):
        if opcode == 0:
            _, surface, sx, sy = struct.unpack_from("<IIii", body)
            self.pointer_at = (sx / 256, sy / 256)
            self.log.append(("ptr_enter", self.surfaces.get(surface, surface)))
        elif opcode == 1:
            self.log.append(("ptr_leave",))
        elif opcode == 2:
            _, sx, sy = struct.unpack_from("<Iii", body)
            self.pointer_at = (sx / 256, sy / 256)
        elif opcode == 3:
            serial, _, button, state = struct.unpack_from("<IIII", body)
            if state == 1:
                self.last_press = serial
            self.log.append(("button", button, state))

    def shm_buffer(self, width, height):
        fd = os.memfd_create("focus-e2e")
        os.ftruncate(fd, width * height * 4)
        with mmap.mmap(fd, width * height * 4) as pixels:
            pixels.write(b"\x80\x40\x20\xff" * width * height)
        pool = self.new_id()
        self.send(message(self.shm, 0, struct.pack("<Ii", pool, width * height * 4)), [fd])
        os.close(fd)
        buffer = self.new_id()
        self.send(message(pool, 0, struct.pack("<IiiiiI", buffer, 0, width, height, width * 4, 1)))
        self.send(message(pool, 1))
        return buffer

    def xdg_surface(self, label):
        surface = self.new_id()
        self.send(message(self.compositor, 0, struct.pack("<I", surface)))
        self.surfaces[surface] = label
        xs = self.new_id()

        def on_configure(opcode, body):
            if opcode == 0:
                self.configures[xs] = struct.unpack_from("<I", body)[0]

        self.handlers[xs] = on_configure
        self.send(message(self.wm_base, 2, struct.pack("<II", xs, surface)))
        return surface, xs

    def map(self, surface, xs, width, height):
        self.send(message(surface, 6))
        self.sync()
        self.send(message(xs, 4, struct.pack("<I", self.configures[xs])))
        self.send(message(surface, 1, struct.pack("<Iii", self.shm_buffer(width, height), 0, 0)))
        self.send(message(surface, 2, struct.pack("<iiii", 0, 0, width, height)))
        self.send(message(surface, 6))
        self.sync()

    def toplevel(self, label, app_id=None, size=(400, 300), server_side=False):
        surface, xs = self.xdg_surface(label)
        toplevel = self.new_id(lambda *_: None)
        self.send(message(xs, 1, struct.pack("<I", toplevel)))
        self.send(message(toplevel, 2, string(label)))
        if app_id:
            self.send(message(toplevel, 3, string(app_id)))
        if server_side:
            manager = self.bind("zxdg_decoration_manager_v1", 1)
            decoration = self.new_id(lambda *_: None)
            self.send(message(manager, 1, struct.pack("<II", decoration, toplevel)))
            self.send(message(decoration, 1, struct.pack("<I", 2)))
        self.map(surface, xs, *size)
        return surface, xs, toplevel

    def destroy_toplevel(self, surface, xs, toplevel):
        self.send(message(toplevel, 0))
        self.send(message(xs, 0))
        self.send(message(surface, 0))
        self.sync()

    def constrain(self, surface, lock):
        manager = self.bind("zwp_pointer_constraints_v1", 1)
        label = "lock" if lock else "confine"
        constraint = self.watch(label, ("locked", "unlocked") if lock else ("confined", "unconfined"))
        self.send(message(manager, 1 if lock else 2, struct.pack("<IIIII", constraint, surface, self.pointer, 0, 2)))
        self.sync()

    def inhibit_shortcuts(self, surface):
        manager = self.bind("zwp_keyboard_shortcuts_inhibit_manager_v1", 1)
        inhibitor = self.watch("inhibitor", ("active", "inactive"))
        self.send(message(manager, 1, struct.pack("<III", inhibitor, surface, self.seat)))
        self.sync()
        return inhibitor

    def grabbing_popup(self, parent_xs, label):
        positioner = self.new_id()
        self.send(message(self.wm_base, 1, struct.pack("<I", positioner)))
        self.send(message(positioner, 1, struct.pack("<ii", 120, 80)))
        self.send(message(positioner, 2, struct.pack("<iiii", 10, 10, 1, 1)))
        surface, xs = self.xdg_surface(label)
        popup = self.new_id()

        def on_popup(opcode, _):
            if opcode == 1:
                self.popup_done.add(label)

        self.handlers[popup] = on_popup
        self.send(message(xs, 2, struct.pack("<III", popup, parent_xs, positioner)))
        self.send(message(popup, 1, struct.pack("<II", self.seat, self.last_press)))
        self.send(message(positioner, 0))
        self.map(surface, xs, 120, 80)
        return surface, xs, popup

    def destroy_popup(self, surface, xs, popup):
        self.send(message(popup, 0))
        self.send(message(xs, 0))
        self.send(message(surface, 0))
        self.sync()


class Pointer(Client):
    def __init__(self):
        super().__init__("pointer")
        manager = self.bind("zwlr_virtual_pointer_manager_v1", 1)
        self.pointer = self.new_id()
        self.send(message(manager, 0, struct.pack("<II", 0, self.pointer)))
        self.time = 1
        self.sync()

    def tick(self):
        self.time += 10
        return self.time

    def move(self, fx, fy):
        self.send(message(self.pointer, 1, struct.pack("<IIIII", self.tick(), int(fx * EXTENT), int(fy * EXTENT), EXTENT, EXTENT)))
        self.send(message(self.pointer, 4))
        self.sync()

    def button(self, button, pressed):
        self.send(message(self.pointer, 2, struct.pack("<III", self.tick(), button, 1 if pressed else 0)))
        self.send(message(self.pointer, 4))
        self.sync()

    def click(self, button=BTN_LEFT):
        self.button(button, True)
        self.button(button, False)


failures = 0


def check(name, ok, detail=""):
    global failures
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" ({detail})" if detail and not ok else ""))
    if not ok:
        failures += 1


def settle(*clients):
    for client in clients:
        client.sync()


def repeats():
    try:
        with open(os.path.join(os.environ["XDG_RUNTIME_DIR"], "focus-e2e-repeat")) as log:
            return len(log.readlines())
    except FileNotFoundError:
        return 0


KEY_F1 = 59


def hold_key_device(ms):
    """Runs as root: a uinput keyboard holds F1 for `ms` milliseconds."""
    def emit(fd, kind, code, value):
        os.write(fd, struct.pack("<qqHHi", 0, 0, kind, code, value))

    fd = os.open("/dev/uinput", os.O_WRONLY)
    fcntl.ioctl(fd, 0x40045564, 1)  # UI_SET_EVBIT EV_KEY
    fcntl.ioctl(fd, 0x40045565, KEY_F1)  # UI_SET_KEYBIT
    os.write(fd, b"focus-e2e keyboard".ljust(80, b"\0") + struct.pack("<HHHHI", 3, 1, 1, 1, 0) + b"\0" * (4 * 64 * 4))
    fcntl.ioctl(fd, 0x5501)  # UI_DEV_CREATE
    time.sleep(1)  # libinput adds the device
    emit(fd, 1, KEY_F1, 1)
    emit(fd, 0, 0, 0)
    print("down", flush=True)
    time.sleep(ms / 1000)
    emit(fd, 1, KEY_F1, 0)
    emit(fd, 0, 0, 0)
    time.sleep(0.2)
    fcntl.ioctl(fd, 0x5502)  # UI_DEV_DESTROY
    os.close(fd)


def hold_f1(ms):
    holder = subprocess.Popen(["sudo", "-n", sys.executable, os.path.abspath(__file__), "--hold-f1", str(ms)], stdout=subprocess.PIPE, text=True)
    holder.stdout.readline()
    return holder


def main():
    a = App("A")
    b = App("B")
    pointer = Pointer()
    a_surface, a_xs, a_toplevel = a.toplevel("A")
    b_surface, _, _ = b.toplevel("B")
    settle(a, b)

    # Find a point over each toplevel from the pointer enters they report.
    spots = {}
    for fx in (0.15, 0.3, 0.5, 0.7, 0.85):
        a.log.clear()
        b.log.clear()
        pointer.move(fx, ROW)
        settle(a, b)
        for app in (a, b):
            if ("ptr_enter", app.name) in app.log:
                spots.setdefault(app.name, fx)
    if "A" not in spots or "B" not in spots:
        check("both toplevels are under the pointer somewhere", False, str(spots))
        return

    pointer.move(spots["A"], ROW)
    pointer.click()
    settle(a, b)
    check("clicking A gives it the keyboard", a.keyboard_focus == a_surface)

    # A menu opened from a press takes the keyboard; closing it hands the
    # keyboard back to the window that opened it.
    pointer.button(BTN_LEFT, True)
    settle(a)
    menu = a.grabbing_popup(a_xs, "menu")
    pointer.button(BTN_LEFT, False)
    settle(a, b)
    check("a grabbing popup takes the keyboard", a.keyboard_focus == menu[0], str(a.log[-4:]))
    a.log.clear()
    a.destroy_popup(*menu)
    settle(a, b)
    check("closing the grabbing popup returns the keyboard to A", a.keyboard_focus == a_surface, str(a.log))

    # Clicking another client's window dismisses the grab.
    pointer.button(BTN_LEFT, True)
    settle(a)
    second = a.grabbing_popup(a_xs, "second")
    pointer.button(BTN_LEFT, False)
    settle(a, b)
    pointer.move(spots["B"], ROW)
    pointer.click()
    settle(a, b)
    check("a click on B dismisses A's grabbing popup", "second" in a.popup_done)
    check("the click focuses B", b.keyboard_focus == b_surface, str(b.log[-4:]))
    a.destroy_popup(*second)

    # A button bind still lets the click focus the window under it.
    pointer.move(spots["A"], ROW)
    settle(a, b)
    a.log.clear()
    pointer.click(BTN_MIDDLE)
    settle(a, b)
    check("a bound middle click focuses A first", a.keyboard_focus == a_surface, str(a.log))
    check("the bound click does not reach A", ("button", BTN_MIDDLE, 1) not in a.log, str(a.log))

    # A press keeps the pointer on A while it moves over B; the release
    # hands the pointer to B without any further motion.
    b.log.clear()
    pointer.button(BTN_LEFT, True)
    pointer.move(spots["B"], ROW)
    settle(a, b)
    check("a held button keeps the pointer on A over B", ("ptr_enter", "B") not in b.log, str(b.log))
    pointer.button(BTN_LEFT, False)
    settle(a, b)
    check("releasing over B enters B", ("ptr_enter", "B") in b.log, str(b.log))

    # A held repeating bind repeats until released.
    pointer.click()
    settle(a, b)
    start = repeats()
    hold_f1(1000).wait()
    time.sleep(0.3)
    held = repeats() - start
    check("a held repeating bind repeats", held >= 5, f"{held} fires")
    after = repeats()
    time.sleep(0.5)
    check("the repeat stops on release", repeats() == after, f"{repeats() - after} late fires")

    # Moving the keyboard to another window ends the repeat.
    focus_start = repeats()
    holder = hold_f1(1600)
    time.sleep(0.7)
    before = repeats()
    pointer.move(spots["A"], ROW)
    pointer.click()
    settle(a, b)
    time.sleep(0.3)
    stopped = repeats()
    holder.wait()
    check("the repeat ran before the focus change", before - focus_start >= 3, f"{before - focus_start} fires")
    check("a focus change ends the repeat", repeats() == stopped and a.keyboard_focus == a_surface, f"{repeats() - stopped} fires after the change")

    # Shortcuts inhibited by the focused window stop a running repeat.
    a.log.clear()
    first = repeats()
    holder = hold_f1(1600)
    time.sleep(0.7)
    running = repeats()
    inhibitor = a.inhibit_shortcuts(a_surface)
    settle(a)
    time.sleep(0.3)
    stopped = repeats()
    holder.wait()
    check("the shortcuts inhibitor becomes active", ("inhibitor", "active") in a.log, str(a.log))
    check("the repeat ran before the inhibitor", running - first >= 3, f"{running - first} fires")
    check("inhibited shortcuts stop the repeat", repeats() == stopped, f"{repeats() - stopped} fires after inhibiting")
    a.send(message(inhibitor, 0))
    settle(a)

    # Hovering a floating window's titlebar in click mode leaves the
    # keyboard alone; its content takes the keyboard (floating differs).
    pointer.move(0.5, 0.6)
    c = App("C")
    c_surface, _, _ = c.toplevel("C", app_id="focus-e2e-float", size=(240, 160), server_side=True)
    settle(a, b, c)
    hover = None
    for fy in (0.6, 0.55, 0.65, 0.5, 0.7):
        c.pointer_at = None
        pointer.move(0.5, fy)
        settle(c)
        if c.pointer_at:
            hover = (fy, c.pointer_at)
            break
    if hover is None:
        check("the floating window is under the pointer", False, str(c.log))
        return
    # Absolute pointer motion spans the bounds of every output, so measure
    # the pixels per pointer unit over C rather than assume one output.
    fy, (sx, sy) = hover
    pointer.move(0.51, fy + 0.01)
    settle(c)
    scale = ((c.pointer_at[0] - sx) / 0.01, (c.pointer_at[1] - sy) / 0.01)
    origin = (0.5 - sx / scale[0], fy - sy / scale[1])
    pointer.move(spots["A"], ROW)
    pointer.click()
    settle(a, b, c)
    c.log.clear()
    pointer.move(origin[0] + 60 / scale[0], origin[1] - TITLEBAR / 2 / scale[1])
    settle(a, b, c)
    check("the pointer over the titlebar is not on C", ("ptr_enter", "C") not in c.log, str(c.log))
    check("hovering the titlebar keeps the keyboard on A", a.keyboard_focus == a_surface and c.keyboard_focus is None, str((a.log[-3:], c.log)))
    pointer.move(origin[0] + 60 / scale[0], origin[1] + 40 / scale[1])
    settle(a, b, c)
    check("hovering the floating content focuses C", c.keyboard_focus == c_surface, str(c.log))

    # A pointer constraint follows the pointer from window to window.
    pointer.move(spots["A"], ROW)
    pointer.click()
    settle(a, b, c)
    a.log.clear()
    b.log.clear()
    a.constrain(a_surface, lock=False)
    pointer.move(spots["A"] + 0.01, ROW)
    settle(a, b)
    check("a confinement on the hovered window activates", ("confine", "confined") in a.log, str(a.log))
    b.constrain(b_surface, lock=True)
    settle(b)
    check("the lock on B waits for the pointer", ("lock", "locked") not in b.log, str(b.log))
    a.destroy_toplevel(a_surface, a_xs, a_toplevel)
    pointer.move(spots["A"] + 0.02, ROW)
    settle(b)
    check("the lock on B activates once the pointer moves onto B", ("ptr_enter", "B") in b.log and ("lock", "locked") in b.log, str(b.log))

if __name__ == "__main__":
    if sys.argv[1:2] == ["--hold-f1"]:
        hold_key_device(int(sys.argv[2]))
        sys.exit(0)
    try:
        main()
    except Exception as err:
        print(f"FAIL: {err}")
        failures += 1
    sys.exit(failures)
