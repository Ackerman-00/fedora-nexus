#!/usr/bin/env python3
"""Output hotplug against a real compositor: the last output to go parks its windows,
position, scale and transform, and the output that comes next gets them all back.

    dormant_output_e2e.py ZOOLANDER

Each case starts its own compositor on the VM's seat, so run this only in the project VM
with VM_OUTPUTS=2. CONNECTOR names the DRM connector forced on and off (default
/sys/class/drm/card0-Virtual-2); writing its status needs passwordless sudo.
Prints PASS or FAIL per case; the exit status is non-zero on any failure.
"""
import os
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bind_all_globals import REGISTRY, read_string  # noqa: E402
from protocol_e2e import Client  # noqa: E402

CONNECTOR = os.environ.get("CONNECTOR", "/sys/class/drm/card0-Virtual-2")
UNPLUGGED = os.path.basename(CONNECTOR).split("-", 1)[1]
PRIMARY = "Virtual-1"
TRANSFORM_90 = 1
SCALE = 1.5
POSITION = (640, 200)


def set_connector(value):
    card = os.path.join(os.path.dirname(CONNECTOR), os.path.basename(CONNECTOR).split("-", 1)[0])
    subprocess.run(["sudo", "-n", "sh", "-c", f"echo {value} > {CONNECTOR}/status && udevadm trigger --action=change {card}"], check=True)


class Compositor:
    def __init__(self, binary):
        self.dir = tempfile.mkdtemp(prefix="zl-dormant-")
        runtime = os.path.join(self.dir, "rt")
        os.mkdir(runtime, 0o700)
        os.mkdir(os.path.join(self.dir, "cfg"))
        env = dict(os.environ, XDG_RUNTIME_DIR=runtime, XDG_CONFIG_HOME=os.path.join(self.dir, "cfg"), XDG_SESSION_TYPE="wayland")
        env.setdefault("LIBSEAT_BACKEND", "seatd")
        env.setdefault("SEATD_SOCK", "/run/seatd.sock")
        env.pop("WAYLAND_DISPLAY", None)
        self.log = open(os.path.join(self.dir, "compositor.log"), "w")
        self.proc = subprocess.Popen([binary], env=env, stdout=self.log, stderr=subprocess.STDOUT)
        socket_path = os.path.join(runtime, "wayland-0")
        deadline = time.monotonic() + 20
        while not os.path.exists(socket_path):
            if self.proc.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError("compositor did not start:\n" + self.output())
            time.sleep(0.1)
        os.environ["XDG_RUNTIME_DIR"], os.environ["WAYLAND_DISPLAY"] = runtime, "wayland-0"
        # Outputs are announced after the socket exists.
        time.sleep(1)

    def eval(self, lua):
        """Run Lua in the config runtime through the control socket and return its first result."""
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
            sock.settimeout(10)
            sock.connect(os.path.join(os.environ["XDG_RUNTIME_DIR"], "zoolander-wayland-0.sock"))
            sock.sendall(f"eval {lua}\n".encode())
            data = b""
            while data.count(b"\n") < 2:
                chunk = sock.recv(65536)
                if not chunk:
                    break
                data += chunk
        status, _, value = data.decode().split("\n")[1].partition(" ")
        assert status == "OK", f"eval {lua}: {data!r}"
        return value

    def output(self):
        self.log.flush()
        with open(self.log.name) as f:
            return f.read()

    def stop(self):
        """Require the compositor to have survived and to stop cleanly."""
        if self.proc.poll() is not None:
            raise AssertionError(f"compositor exited with status {self.proc.returncode} during the test")
        self.proc.send_signal(signal.SIGTERM)
        status = self.proc.wait(timeout=20)
        assert status == 0, f"compositor stopped with status {status}"
        assert "panic" not in self.output(), "compositor panicked"
        shutil.rmtree(self.dir)


def heads():
    """Every output-management head by name: enabled, position, transform and exact scale."""
    c = Client()
    manager = c.bind("zwlr_output_manager_v1", 4)
    found = {}
    for obj, opcode, body in c.read_events():
        c.note_registry(obj, opcode, body)
        if obj == manager and opcode == 0:
            found[struct.unpack_from("<I", body)[0]] = {}
        elif obj == manager and opcode == 1:
            serial = struct.unpack_from("<I", body)[0]
            break
        elif obj in found:
            head = found[obj]
            if opcode == 0:
                head["name"] = read_string(body, 0)[0]
            elif opcode == 4:
                head["enabled"] = struct.unpack_from("<i", body)[0] != 0
            elif opcode == 6:
                head["position"] = struct.unpack_from("<ii", body)
            elif opcode == 7:
                head["transform"] = struct.unpack_from("<i", body)[0]
            elif opcode == 8:
                head["scale"] = struct.unpack_from("<i", body)[0] / 256
    return c, manager, serial, {head["name"]: (obj, head) for obj, head in found.items()}


def configure(name, enabled=True, scale=None, transform=None, position=None):
    """Apply one output-management configuration that changes only `name`."""
    c, manager, serial, by_name = heads()
    config = c.new_id()
    c.request(manager, 0, struct.pack("<II", config, serial))
    for head_name, (obj, head) in by_name.items():
        if head_name == name and not enabled or head_name != name and not head.get("enabled"):
            c.request(config, 1, struct.pack("<I", obj))
            continue
        config_head = c.new_id()
        c.request(config, 0, struct.pack("<II", config_head, obj))
        if head_name != name:
            continue
        if position is not None:
            c.request(config_head, 2, struct.pack("<ii", *position))
        if transform is not None:
            c.request(config_head, 3, struct.pack("<i", transform))
        if scale is not None:
            c.request(config_head, 4, struct.pack("<i", round(scale * 256)))
    c.request(config, 2)
    result = []
    c.wait_for(lambda obj, opcode, _: obj == config and opcode in (0, 1, 2) and not result.append(opcode))
    assert result == [0], f"configuring {name} was {('succeeded', 'failed', 'cancelled')[result[0]]}"


class App(Client):
    """One mapped toplevel that follows which outputs its surface is on."""

    def __init__(self):
        super().__init__()
        self.wm_base = self.bind("xdg_wm_base", 1)
        self.bound = {}
        self.entered = set()
        self.surface, _ = self.map_toplevel(self.bind("wl_compositor", 6), self.wm_base)
        self.roundtrip()

    def pump(self, done, waiting, seconds=10):
        """Handle events until `done()` holds, binding every wl_output as it is announced."""
        deadline = time.monotonic() + seconds
        while not done():
            assert time.monotonic() < deadline, f"timed out waiting for {waiting}"
            for name in self.outputs:
                if name not in self.bound and name not in self.removed:
                    self.bound[name] = {"obj": self.bind_name(name, "wl_output", 4)}
            for obj, opcode, body in self.roundtrip():
                if obj == self.wm_base and opcode == 0:
                    self.request(self.wm_base, 3, body[:4])
                elif obj == self.surface and opcode in (0, 1):
                    output = struct.unpack_from("<I", body)[0]
                    (self.entered.add if opcode == 0 else self.entered.discard)(output)
                for state in self.bound.values():
                    if obj != state["obj"]:
                        continue
                    if opcode == 0:
                        x, y = struct.unpack_from("<ii", body)
                        _, at = read_string(body, 20)
                        _, at = read_string(body, at)
                        state["geometry"] = (x, y, struct.unpack_from("<i", body, at)[0])
                    elif opcode == 3:
                        state["scale"] = struct.unpack_from("<i", body)[0]
                    elif opcode == 4:
                        state["name"] = read_string(body, 0)[0]
            # A surface on a removed output gets no leave; it simply stops being on it.
            for name in self.removed & self.bound.keys():
                self.entered.discard(self.bound[name]["obj"])
            if not done():
                time.sleep(0.05)

    def live(self, name):
        for global_name, state in self.bound.items():
            if global_name not in self.removed and state.get("name") == name:
                return state
        return None

    def on(self, name):
        state = self.live(name)
        return state is not None and state["obj"] in self.entered

    def wait_on(self, name):
        self.pump(lambda: self.on(name), f"the window on {name}")

    def wait_gone(self, name):
        self.pump(lambda: self.live(name) is None, f"{name} to go")


def expect_parked_state(app, name):
    state = app.live(name)
    assert state["geometry"] == (*POSITION, TRANSFORM_90), f"{name} came back as {state['geometry']}, want {(*POSITION, TRANSFORM_90)}"
    assert state["scale"] == 2, f"{name} came back with wl_output scale {state['scale']}"
    _, _, _, by_name = heads()
    head = by_name[name][1]
    seen = (head.get("enabled"), head.get("position"), head.get("transform"), head.get("scale"))
    assert seen == (True, POSITION, TRANSFORM_90, SCALE), f"{name} head came back as {seen}"


def same_output_returns(comp):
    """Unplugging the last output and plugging it back restores it and its windows."""
    assert comp.eval("return zl.focus_monitor('right')") == "true"
    app = App()
    app.wait_on(UNPLUGGED)
    configure(PRIMARY, enabled=False)
    app.wait_gone(PRIMARY)
    configure(UNPLUGGED, scale=SCALE, transform=TRANSFORM_90, position=POSITION)
    app.pump(lambda: app.live(UNPLUGGED).get("geometry") == (*POSITION, TRANSFORM_90), f"{UNPLUGGED} to move")
    assert app.on(UNPLUGGED), f"the window left {UNPLUGGED}"
    set_connector("off")
    app.wait_gone(UNPLUGGED)
    set_connector("on")
    app.wait_on(UNPLUGGED)
    expect_parked_state(app, UNPLUGGED)


def next_output_takes_over(comp):
    """With no output left, an output never seen before takes the last one's place and windows."""
    app = App()
    app.wait_on(PRIMARY)
    configure(PRIMARY, scale=SCALE, transform=TRANSFORM_90, position=POSITION)
    app.pump(lambda: app.live(PRIMARY).get("geometry") == (*POSITION, TRANSFORM_90), f"{PRIMARY} to move")
    configure(PRIMARY, enabled=False)
    app.wait_gone(PRIMARY)
    set_connector("on")
    app.wait_on(UNPLUGGED)
    expect_parked_state(app, UNPLUGGED)


CASES = ((same_output_returns, "on"), (next_output_takes_over, "off"))


def main():
    binary = os.path.realpath(sys.argv[1])
    failed = 0
    for case, initial in CASES:
        set_connector(initial)
        comp = None
        try:
            comp = Compositor(binary)
            case(comp)
            comp.stop()
            print(f"PASS {case.__name__}")
        except Exception as err:
            failed += 1
            print(f"FAIL {case.__name__}: {err}")
            if comp is not None:
                print(f"  log: {comp.log.name}")
                if comp.proc.poll() is None:
                    comp.proc.kill()
    set_connector("detect")
    return failed


if __name__ == "__main__":
    sys.exit(main())
