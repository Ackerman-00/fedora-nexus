#!/bin/sh
set -eu

# Resolved before the cd, so the sudo re-exec finds the script from any
# working directory.
script=$(readlink -f "$0")
cd "$(dirname "$script")"
if test "$(id -u)" -ne 0 || test -n "${DESTDIR:-}"; then
    test "$#" -eq 0 || {
        echo "run install-system.sh without arguments" >&2
        exit 1
    }
    otr=${OTR:-otr}
    # 0.2.2 is the first release whose std has the guarded-mapping and
    # descriptor APIs the Otr sources use.
    version=$("$otr" version | sed 's/^otr //')
    if test "$(printf '%s\n' 0.2.2 "$version" | sort -V | head -n1)" != 0.2.2; then
        echo "otr $version is too old; zoolander needs otr 0.2.2 or newer" >&2
        exit 1
    fi
    if test ! -f vendor/luajit/src/libluajit.a; then
        sh vendor/fetch-luajit.sh
    fi
    mkdir -p otr-out
    # Compiler caches land in the working directory, so build from inside
    # otr-out where they stay ignored.
    (
        cd otr-out
        "$otr" build ../otr/native_main.otr --release --cpu baseline \
            -rpath '$ORIGIN/../lib/zoolander' -o zoolander
        "$otr" build ../otr/bell_player.otr ../otr/bell_audio_ffi.c --release --cpu baseline \
            --lib shared --pkg-config libpipewire-0.3 -I ../otr -o libzoolander_bell.so
        "$otr" build ../otr/audio_visualizer/capture_lib.otr ../otr/bell_audio_ffi.c ../otr/audio_visualizer/capture_ffi.c --release --cpu baseline \
            --lib shared --pkg-config libpipewire-0.3 -I ../otr -o libzoolander_audio_visualizer.so
        "$otr" build ../wsi/layer.otr --release --cpu baseline --lib shared \
            -l wayland-client -l xcb -l X11-xcb -o libVkLayer_zoolander_wsi.so
        "$otr" run ../wsi/manifest.otr -- /usr/local/lib/zoolander/libVkLayer_zoolander_wsi.so > zoolander_wsi.json
    )
    if test -z "${DESTDIR:-}"; then
        exec sudo "$script" --install
    fi
else
    test "${1:-}" = --install && test "$#" -eq 1 || {
        echo "run install-system.sh as your user, not through sudo" >&2
        exit 1
    }
fi

prefix="${DESTDIR:-}/usr/local"
install -d -m 0755 "$prefix/bin" "$prefix/lib/zoolander" "$prefix/share/wayland-sessions" "$prefix/share/xdg-desktop-portal" \
    "$prefix/share/vulkan/implicit_layer.d" "$prefix/share/zoolander/config"
install -m 0755 otr-out/zoolander "$prefix/bin/zoolander"
# Loaded on first use through the binary's $ORIGIN/../lib/zoolander
# runpath.
install -m 0755 otr-out/libzoolander_bell.so "$prefix/lib/zoolander/libzoolander_bell.so"
install -m 0755 otr-out/libzoolander_audio_visualizer.so "$prefix/lib/zoolander/libzoolander_audio_visualizer.so"
install -m 0755 zoolanderctl "$prefix/bin/zoolanderctl"
# The loader reads /usr/local/share through XDG_DATA_DIRS; the manifest names the library by full path.
install -m 0644 otr-out/libVkLayer_zoolander_wsi.so "$prefix/lib/zoolander/libVkLayer_zoolander_wsi.so"
install -m 0644 otr-out/zoolander_wsi.json "$prefix/share/vulkan/implicit_layer.d/zoolander_wsi.json"
install -m 0644 zoolander.desktop "$prefix/share/wayland-sessions/zoolander.desktop"
install -m 0644 zoolander-portals.conf "$prefix/share/xdg-desktop-portal/zoolander-portals.conf"
# The binary finds the starter config through its own prefix, $prefix/share/zoolander/config.
install -m 0644 config/starter/*.lua "$prefix/share/zoolander/config/"
