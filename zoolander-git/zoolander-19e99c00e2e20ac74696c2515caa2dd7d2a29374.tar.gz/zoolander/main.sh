#! /bin/bash

set -e

VERSION="0.1.52"
source ./pika-build-config.sh

echo "$PIKA_BUILD_ARCH" > pika-build-arch

# Clone zooland where otr/otr.toml expects it: ../../zooland/otr from otr/ is a
# sibling of this checkout.
# Remove any leftover clone from a previous (retried) attempt: the central
# build logic can re-run this script in the same workspace after a transient
# dependency-resolution failure, and a stale ../zooland would otherwise make
# git clone fail with "destination path already exists".
rm -rf ../zooland
git clone --depth 1 -b v"$VERSION" https://git.pika-os.com/otter-shell/zooland.git ../zooland

# The pinned static LuaJIT the build links; debian/rules does not fetch it.
sh vendor/fetch-luajit.sh

# Get build deps
apt-get build-dep ./ -y

# Build package. Binary-only, because the CI build log is written into this
# source tree and would fail the dpkg-source upstream-changes check.
LOGNAME=root dh_make --createorig -y -l -p zoolander_"$VERSION" || echo "dh-make: Ignoring Last Error"
dpkg-buildpackage --no-sign -b

# Move the debs to output
mkdir -p ./output
mv ../*.deb ./output/
