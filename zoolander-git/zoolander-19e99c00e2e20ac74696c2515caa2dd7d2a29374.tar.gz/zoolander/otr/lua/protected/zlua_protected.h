#ifndef ZLUA_PROTECTED_H
#define ZLUA_PROTECTED_H

#include <lua.h>
#include <stddef.h>
#include <stdint.h>

/* Nonzero positive status: Lua error object on top, original inputs intact.
 * Negative status: no error object was pushed. All output parameters are valid
 * only on success. A failed operation must be propagated before more Lua work. */
#define ZLUA_ERRSTACK (-256)
#define ZLUA_NOT_READY (-257)

int zlua_prepare(lua_State *L);
int zlua_failure(int status);
int zlua_pushhandler(lua_State *L, lua_CFunction handler);
int zlua_pushcclosure(lua_State *L, lua_CFunction function, int upvalues);
int zlua_pushlstring(lua_State *L, const char *bytes, size_t length);
int zlua_pushlightuserdata(lua_State *L, uintptr_t token);
int zlua_pushnil(lua_State *L);
int zlua_pushinteger(lua_State *L, lua_Integer value);
int zlua_pushnumber(lua_State *L, lua_Number value);
int zlua_pushboolean(lua_State *L, int value);
int zlua_pushvalue(lua_State *L, int index);
int zlua_createtable(lua_State *L, int array, int record);
int zlua_getfield(lua_State *L, int index, const char *key);
int zlua_setfield(lua_State *L, int index, const char *key);
int zlua_rawgeti(lua_State *L, int index, int key);
int zlua_rawseti(lua_State *L, int index, int key);
int zlua_next(lua_State *L, int index, int *more);
int zlua_ref(lua_State *L, int index, int *reference);
int zlua_unref(lua_State *L, int index, int reference);
int zlua_tolstring(lua_State *L, int index, const char **bytes, size_t *length);
int zlua_settop(lua_State *L, int index);
int zlua_call(lua_State *L, int arguments, int results);
int zlua_loadbuffer(lua_State *L, const char *bytes, size_t length, const char *name);
int zlua_error(lua_State *L, const char *bytes, size_t length);
int zlua_openlibs(lua_State *L);

#endif
