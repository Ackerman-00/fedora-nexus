#include <pipewire/pipewire.h>
#include <spa/param/audio/format-utils.h>
const struct spa_pod *zoolander_spa_stereo_f32_format(void *storage, size_t size, uint32_t rate);
