#ifndef ZOOLANDER_TITLE_FONT_FFI_H
#define ZOOLANDER_TITLE_FONT_FFI_H
#include <ft2build.h>
#include FT_FREETYPE_H
#include <fontconfig/fontconfig.h>
#include <hb.h>
#include <hb-ft.h>
#include <fribidi.h>
#endif
