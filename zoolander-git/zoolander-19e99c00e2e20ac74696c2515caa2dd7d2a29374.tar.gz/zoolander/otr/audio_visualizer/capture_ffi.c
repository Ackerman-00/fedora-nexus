#include "audio_visualizer/capture_ffi.h"

struct spa_source *zoolander_audio_visualizer_watch(struct pw_main_loop *loop, int fd, spa_source_io_func_t ready, void *data)
{
    return pw_loop_add_io(pw_main_loop_get_loop(loop), fd, SPA_IO_IN, false, ready, data);
}
