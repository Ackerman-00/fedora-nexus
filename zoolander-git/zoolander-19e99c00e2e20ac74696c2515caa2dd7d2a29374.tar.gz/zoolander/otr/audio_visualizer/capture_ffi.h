#include "bell_audio_ffi.h"
struct spa_source *zoolander_audio_visualizer_watch(struct pw_main_loop *loop, int fd, spa_source_io_func_t ready, void *data);
