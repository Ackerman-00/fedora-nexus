# AGENTS.md

Guidance for coding agents working in this repository.

Every test runs through `tests/run.sh` (see the README). Anything that starts a compositor or touches DRM, the GPU or a seat runs only in the test VM (`tests/run.sh --vm`). On the host, only edit, build, and run `tests/run.sh --unit`. Never kill host processes by name; the host desktop session runs zoolander.

## Code structure rules

These are review blockers. Fix any violation in code you touch, and never add a new one.

- **No implicit coupling.** Modules talk through typed interfaces and named constants that live in one place. Never copy a string or integer contract between modules or packages: config keys, file names, IPC and socket names, Lua ABI names, protocol error codes. Never reach into another module's private storage. If calls must happen in a set order, encode that order in a type or an options struct rather than in a comment.
- **Feature folders, not layer folders.** Group files by feature (`xwayland/`, `layout/`, `picker/`), not by technical kind (`util/`, `core/`, `ext/`, `sys/`, `*_access`, `*_policy`). A shared filename prefix is a folder that hasn't been made yet.
- **No duplication.** Before writing a helper, search the shared libraries for one. If two places need the same logic, move it to the lowest package both depend on. Never vendor a copy of another module inside the same tree. Two byte-identical files are a bug.
- **Make illegal states unrepresentable.** Use a tagged union when fields only make sense for one kind. Use an enum instead of mutually exclusive bools. Use an optional instead of a `has_x` flag plus `x`, or a sentinel value. Store the real enum type, not a raw integer. Switches over these types are exhaustive, with no `else =>` that would hide a new variant.
- **No god files or god structs.** Keep files under about 750 lines (generated code is exempt). Give each struct one responsibility. Split by sub-feature when a struct passes about 30 fields or a file mixes concerns.
- **No shotgun surgery.** Adding one variant (a layout, widget, protocol, IR op, config key or action) should touch one declaration plus its implementation. Drive everything else from a comptime table or a per-variant interface.
- **Respect layering.** Dependencies point downward only. There are no import cycles. A low-level package never imports a higher one, a library or toolkit never depends on an app, and an app never imports another app's internals. Go through the published facade, never around it.
- **No pass-through wrappers.** Don't write functions or modules that only forward a call or re-export names. Call the target directly.
- **Validate at the boundary, then trust.** External input means wire messages, Lua and config values, IPC, CLI arguments, environment variables and files. Parse and validate it once, where it enters, into types that can only hold valid values, and don't re-validate it further in.
  - Only use `catch {}` when the failure doesn't matter, such as best-effort cleanup. Otherwise propagate the error, report it to the user, or log it.
  - Never `@panic` or `unreachable` on anything external input can reach.
