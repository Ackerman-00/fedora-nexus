# Lua API

Zoolander loads LuaJIT configuration from `init.lua`. The global `zl` table
contains the functions and constants below. Config setters may run at top
level. Actions that need a running compositor, such as `zl.workspace` or
`zl.exec_command`, should run from a binding or a `startup` handler.

Unknown string fields in option tables log a warning and do not stop the
config from loading. Invalid arguments raise a Lua error unless a return
value says otherwise; a number outside its documented range is invalid, so
the call raises and leaves the setting unchanged instead of clamping it.
Signatures without `->` return no value.

## Starter config

Zoolander installs a commented starter config in `share/zoolander/config`
below its prefix (`/usr/share/zoolander/config` for the package; the
repository's copy is `config/starter`). When Zoolander starts without
`--config` and the default `init.lua` does not exist, it copies each starter
file the config directory lacks into it and loads the copy; an existing file
is never replaced. When nothing can be written there, it loads the installed
starter in place. `zoolander --config-schema` reports the directory as
`starter_dir`.

The starter's `init.lua` requires `monitors`, `keybinds`, `windows` and
`exec`. Before them it loads the shell profile fragments `shell.keybinds`,
`shell.windows` and `shell.exec` when they exist, so a binding or rule of
yours replaces the profile's. A fragment that exists but fails stops the
config as any other module does. Its `windows.lua` writes rules through a
local helper whose parameters are the compatibility form's names:

```lua
local function rule(match, pattern, float, dim_around, no_animation, idle_inhibit, fullscreen, content, border_size, rounding, shadow, decorate, workspace, follow, confine_cursor, force_game_hdr, no_minimize)
    zl.add_window_rule(match, pattern, float or false, dim_around or false, no_animation or false, idle_inhibit or false, fullscreen or false, content, border_size, rounding, shadow, decorate, workspace, follow or false, confine_cursor or false, force_game_hdr or false, no_minimize or false)
end

rule("app_id", "^(zoolander-settings)$", true)
```

A settings app reads a rule's actions from such a helper by parameter name,
so it can edit and delete the rules written through it.

## Loading config modules

`require("name")` loads `name.lua` or `name/init.lua` below the canonical
config directory. A module name may contain letters, digits, `_`, `-`, and
dots; dots name subdirectories. Modules are text-only, limited to 1 MiB, and
cached for the lifetime of the config runtime. Resolved paths must remain
inside the config directory.

The runtime opens Lua's base, table, string, math, and bit libraries. It
removes `dofile`, `loadfile`, `load`, and `loadstring`, and does not open `io`,
`os`, `package`, `debug`, `jit`, or `ffi`. This is a restricted config
environment, not a process sandbox: `zl.exec_command` deliberately runs a
shell command.

The initial config pass happens before the compositor is attached. Host
actions return `false` or do nothing during that pass and log one warning.
Reload candidates run with the live host attached, so a top-level host action
runs during each reload attempt that reaches it, even if a later statement
makes that reload fail. Put actions with side effects in a binding or a
`startup` handler:

```lua
zl.on("startup", function()
    zl.exec_command("my-status-bar")
end)
```

`zoolander --config-schema` prints every setter below that a settings app may
edit, with its keys, ranges, enum values and defaults, as JSON, and the
starter config directory as `starter_dir` (`null` when none is installed).
`zoolander --describe-config` runs a config without a compositor and prints
each `zl` call it makes, with its arguments and the config lines that made it;
see the README. The control socket's `monitors-json` command reports the
outputs those settings apply to.

Saving `init.lua` or a sibling `.lua` file reloads the whole config
transactionally. A failed reload leaves the old runtime active. The directory
watch is not recursive, so changes below a subdirectory need an explicit
reload.

## Constants

Modifier constants are distinct bit flags and may be combined with `+` or
`bit.bor`:

| Constant | Meaning |
| --- | --- |
| `zl.MOD_SHIFT` | Shift modifier |
| `zl.MOD_CTRL` | Control modifier |
| `zl.MOD_ALT` | Alt modifier |
| `zl.MOD_LOGO` | Logo or Super modifier |

Axis constants identify scroll directions: `zl.AXIS_LEFT`, `zl.AXIS_RIGHT`,
`zl.AXIS_UP`, and `zl.AXIS_DOWN`.

Corner constants identify hot corners: `zl.CORNER_TOP_LEFT`,
`zl.CORNER_TOP_RIGHT`, `zl.CORNER_BOTTOM_LEFT`, and `zl.CORNER_BOTTOM_RIGHT`.

Key constants are `zl.KEY_BACKSPACE`, `zl.KEY_TAB`, `zl.KEY_RETURN`,
`zl.KEY_ESCAPE`, `zl.KEY_SPACE`, `zl.KEY_LEFT`, `zl.KEY_UP`, `zl.KEY_RIGHT`,
`zl.KEY_DOWN`, and `zl.KEY_F1`. Other keys may be given as numeric XKB
keysyms. A printable one-byte string is also accepted by `zl.bind`.

## Bindings and events

### `zl.bind(modifiers, key, callback [, options]) -> id`

Registers a keyboard binding. `options.locked` allows it while the session is
locked. `options.repeating` follows keyboard repeat. Both default to `false`.
`options.description` is a string of at most 127 bytes that `zl.bindings`
reports, for key cheat sheets; it defaults to empty.
The callback return value is ignored. Compositor bindings run before an input
method keyboard grab; a consumed press also consumes its release.
The returned registration ID has no public `zl` unbind operation; the binding
is removed when its config runtime is replaced or destroyed.

### `zl.bind_mouse(modifiers, button, callback [, options]) -> id`

Registers a pointer-button binding. `button` is an integer button code.

### `zl.bind_axis(modifiers, axis, callback [, options]) -> id`

Registers a scroll binding. `axis` is one of the four `AXIS_*` constants.

### `zl.bind_hot_corner(modifiers, corner, callback [, options]) -> id`

Registers a hot corner. `corner` is one of the four `CORNER_*` constants. The
callback runs once when the pointer reaches that corner with exactly
`modifiers` held, and again only after the pointer has left it. A corner is
the last pixel of a monitor's corner with no monitor past either edge, so the
corners where monitors meet never fire. Hot corners do not fire while the
session is locked or while the focused window inhibits shortcuts. There are
none by default.

Keyboard, pointer-button, scroll, and hot-corner callbacks receive no
arguments. The options of `zl.bind_mouse`, `zl.bind_axis`, and
`zl.bind_hot_corner` take only `description`, as for `zl.bind`.

### `zl.bindings() -> list`

Lists the binds of the running config, in the order it made them, as tables
with:

| Field | Meaning |
| --- | --- |
| `kind` | `"key"`, `"mouse"`, `"axis"`, or `"hot_corner"` |
| `modifiers` | the modifier mask the bind was made with |
| `mods` | the modifiers as `SUPER`, `CTRL`, `ALT`, `SHIFT` in that order, joined by `+`; `""` for none |
| `key` | the XKB keysym name for keys (`Return`, `q`, `XF86AudioRaiseVolume`), `mouse:<button>` for buttons, `wheel_left`, `wheel_right`, `wheel_up`, or `wheel_down` for scrolling, `top_left`, `top_right`, `bottom_left`, or `bottom_right` for hot corners |
| `description` | the bind's description, `""` when it has none |
| `locked`, `repeating` | the bind's options; always `false` for mouse, scroll, and hot-corner binds |

Global shortcut binds are keys in this list too. `zoolanderctl eval` replaces
line breaks in its reply with spaces, so a script that reads the list that way
joins it with other separators:

```sh
zoolanderctl eval "local o={} for _,b in ipairs(zl.bindings()) do o[#o+1]=table.concat({b.kind,b.mods,b.key,b.description},'\31') end return table.concat(o,'\30')"
```

### `zl.bind_global_shortcut(modifiers, key, app_id, id [, options]) -> id`

Binds a key to a shortcut an application registered through
hyprland-global-shortcuts-v1, directly or through the GlobalShortcuts portal.
The application learns when the key goes down and when it comes back up; it
never sees the key itself. `app_id` and `id` name the shortcut, each 1 to 255
bytes. The bind exists before the application registers the shortcut, and
keeps the key from other clients even while no application has it.
`options.locked` works as it does for `zl.bind`.

```lua
zl.bind_global_shortcut(zl.MOD_LOGO, 'r', 'org.example.Recorder', 'record')
```

### `zl.global_shortcuts() -> list`

Lists the registered shortcuts as tables with `app_id`, `id`, `description`
and `trigger` (the application's suggested key combination, in its own
words).

### `zl.on(event, callback)`

Registers a handler for `startup`, `config_reloaded`, `output_added`, or
`output_removed`. Output handlers receive a monitor table in the same shape as
`zl.monitor_info`; the other handlers receive no arguments.

Bindings and event handlers belong to their config runtime. A successful
reload removes the old registrations after the candidate runtime is ready.
Errors from binding, event, and custom-layout callbacks are logged; the
compositor continues running.

## Layout selection

### `zl.set_layout(layout [, ratio [, master_count [, axis]]])`

Selects a built-in layout: any entry of the layout switcher. Names are
`dwindle`, `master_stack` (`master` is accepted as an alias), `grid`,
`monocle`, `spiral`, `scrolling`, `floating`, `canvas`, `shelves`, `islands`,
`lanes`, `accordion`, `workbench`, `pairs`, and `anchors`.

`shelves` (Side Shelves), `islands`, and `anchors` are an arrangement
(floating, canvas, and canvas) plus a feature. The layout reaches a workspace
the way `zl.layout("layout_set", 0, name)` puts it there:

- When it reaches a workspace on screen, the feature turns on. Side Shelves
  turns its shelves on. Islands puts the focused window in a new island when
  the workspace has no island yet. Anchors anchors the focused window.
- A new workspace that takes the layout from the config gets its shelves too.
- Windows that open on the workspace later, or are moved onto it, get the
  feature as if the layout had been chosen with them focused. On Islands each
  one joins the layout's island, the first one making it. On Anchors the first
  one is anchored while the layout has no anchored window.
- Stepping the workspace to another layout turns off what the feature turned
  on.
- Setting the same entry again, for example on a reload, changes only ratio,
  master count, and axis.

`ratio` is a fraction
in `(0, 1]` or an integer in `2..999` interpreted as thousandths.
`master_count` is `1..65535`; `axis` is `auto`, `horizontal`, `vertical`, or
`perpendicular`.
Omitted values reset to ratio `0.6`, master count `1`, and `auto` axis.
Scrolling and Lanes treat `auto` as horizontal. Accordion puts its previews
in left/right trays for `horizontal` and top/bottom trays for `vertical`; `auto`
picks by output width. `perpendicular` runs across the way workspaces slide
(the `workspaces` animation style): `vertical`, unless workspaces slide `slide
top` or `slide bottom`, then `horizontal`. It is decided when the layout reaches
a workspace. Toggling orientation overrides the axis for that workspace.

In Scrolling, `ratio` is the width of a column (its height on a vertical
strip) that has no width of its own; `zl.cycle_column_width` gives the focused
column one. Widths are kept in thousandths, and one within half a thousandth
of a fraction with a denominator up to 12 is that fraction exactly: `1/3`,
`0.333` and `0.3333` are all a third. Column edges are rounded once along the
strip, so columns whose widths add up to the screen fill it to the pixel, with
only the configured gaps between them; three columns of `1/3` fill an
ultrawide display edge to edge.

The first argument may instead be a function:

```lua
zl.set_layout(function(index, count, output_width, output_height)
    return x, y, width, height
end)
```

`index` is zero-based. An error or omitted return keeps the built-in fallback
for that value. A layout callback that starts another arrangement does not
re-enter itself; that nested arrangement uses the built-in fallback.

### `zl.set_workspace_layout(name, layout [, ratio [, master_count [, axis]]])`

Sets or replaces the layout rule for a workspace. Arguments after `name` have
the same meaning, limits, and defaults as `zl.set_layout`.
Every switcher entry is accepted, including `shelves`, `islands`, and
`anchors`. The workspace starts on it, and its feature comes on as described
for `zl.set_layout`.

### `zl.set_dwindle(options)`

Configures the Dwindle layout:

| Field | Values |
| --- | --- |
| `preserve_split` | Keep each existing tree node's split axis when geometry changes. When false, axis follows the current rectangle, except for splits `smart_split` placed or `zl.toggle_split()` flipped. |
| `smart_split` | Choose the new split axis and side from pointer position. |
| `smart_resizing` | Default `true`: a tiled pointer resize drags the corner nearest the pointer, moving the divider on that side, so pulling a window's left edge left widens it. `false` always drags the bottom-right corner. |
| `force_split` | `0` uses pointer position, `1` forces left/top, `2` forces right/bottom |
| `split_width_multiplier` | `0.1..4`; biases width when choosing horizontal versus vertical splits |

`smart_split` determines both axis and side for a new leaf, so it takes
precedence over `force_split` and the width multiplier for that insertion,
and the axis it picked stays when the layout changes shape.

### `zl.set_spatial(options)`

Configures spatial layouts. `fallback_width` and `fallback_height` are
`0.2..1`; `width_cap` is `0..16384`; `shelf_width` is `0..1200`; `snap` is
`0..64`; `reveal_margin` is `0..200`; and `pan_fingers` is `0..5`, where zero
disables the gesture. `shelf_mode` is `auto`, `persistent`, or `drawer`.

### `zl.set_scrolling(options)`

Configures the Scrolling layout. `width_presets` lists the widths
`zl.cycle_column_width` steps through, as fractions of the screen in `(0, 1]`
in ascending order, at most 8; the default is `{ 1/3, 2/3, 1 }`. On a vertical
strip they are heights. New columns take the `zl.set_layout` ratio.

```lua
zl.set_scrolling({ width_presets = { 1/3, 1/2, 2/3, 1 } })
```

### `zl.set_tab_bar(enabled_or_options)`

Tab groups let windows share one tile in `master_stack`, `grid`, `monocle`,
`spiral`, `dwindle` and `scrolling`; only the front tab tiles and the others
wait hidden at the same size. `zl.set_tab_bar` draws a bar of tabs, one per
title, 3 px (`gap`) above every tile; the bar is off by default.
`zl.set_tab_bar(true)` or `(false)` toggles it and keeps the other settings; a
table turns it on unless it sets `enabled = false`.

| Field | Values |
| --- | --- |
| `height` | `8..96`, default `30` |
| `radius` | `0..48`, default `8` |
| `gap` | `0..32`, default `3`: between the bar and its tile, and between tabs |
| `padding_x` | `0..64`, default `12`: title inset inside a tab |
| `size` | `6..64`, default `13`: title font size |
| `font` | font family, at most 127 bytes; the window title font when unset |
| `bg`, `fg`, `focus_bg`, `focus_fg` | `#RRGGBB` or `#RRGGBBAA`; the chrome palette when unset |
| `monocle_all` | default `true`: Monocle shows one bar listing every window of the workspace |

Click a tab to focus it, scroll over a bar to step through its tabs, drag a
tab 8 px or more off its bar to take it out of its group, and drop a dragged
tile on another bar to join that group. No bar shows while a fullscreen window
does. `zl.layout_info()` reports each window's `tab` as `null` or
`{ group, order, front }`.

### `zl.set_audio_visualizer(style_or_options)`

Draws what is playing around the focused window, in a shader, from the
default output's audio. It is off by default, and off it costs nothing: the
capture library is not loaded and no thread or descriptor exists. On, both
the capture thread and the compositor sleep while nothing plays; frames are
drawn only while there is sound and a window to draw around, and each one
repaints only the strip around that window. Games (`content_type = "game"`),
fullscreen windows and windows under one never get it, and a display drawn by
the software renderer leaves it off.

A style name sets the style and keeps the other settings, `false` turns it
off, and a table sets any of:

| Field | Values |
| --- | --- |
| `style` | `none` (default), `bars`, `blocks`, `waves`, `glow`, `line` or `custom` |
| `size` | `8..256`, default `48`: pixels a full level reaches from the window edge |
| `opacity` | `0..1`, default `0.85` |
| `sensitivity` | `0.25..4`, default `1`: scales the levels, which already follow the volume |
| `low`, `high` | `#RRGGBB` or `#RRGGBBAA`: the colour at the window edge and at full reach; the active border and title colours when unset |
| `layers` | what `custom` draws: up to 4 tables, the first drawn at the bottom |

The spectrum has 24 bands, a third of an octave each from 40 Hz to 16 kHz.
A layer is one shape fed by a run of them, so new looks are composed in Lua
without code running per frame:

| Layer field | Values |
| --- | --- |
| `shape` | `bars` (default), `wave`, `glow` or `line` |
| `low_band`, `high_band` | `1..24`, default `1` and `24`: the bands it reads, spread around the window |
| `reach` | `0.1..1`, default `1`: share of `size` a full level reaches |
| `period` | `2..512`, default `12`: pixels along the edge for one bar and its gap, or one wavelength |
| `fill` | `0..1`, default `0.7`: share of `period` a bar covers, of a wave's height that stays solid, of a glow that stays bright, or the line's thickness |
| `segment` | `0..64`, default `0`: cuts bars into blocks this many pixels tall |
| `speed` | `-500..500`, default `0`: pixels a second the pattern drifts along the edge |
| `mirror` | default `true`: bass at the bottom centre and treble at the top centre, the same on both sides; `false` runs once around clockwise |
| `inner`, `outer` | colours; `low` and `high` when unset |

```lua
zl.set_audio_visualizer("bars")
zl.set_audio_visualizer({ style = "waves", size = 64, low = "#ff6ad5", high = "#8be9fd" })
zl.set_audio_visualizer({
    style = "custom",
    layers = {
        { shape = "glow", high_band = 6, inner = "#ff6ad580" },
        { shape = "bars", period = 8, fill = 0.5, segment = 4 },
        { shape = "line", low_band = 12, speed = 40, mirror = false },
    },
})
```

### `zl.layout(action [, a [, b]]) -> result`

Runs a spatial-layout action. It returns `"done"`, `"no_target"`, or
`"unavailable"`. Actions are:

`focus`, `move`, `resize`, `cycle`, `primary`, `region`, `inspect`, `pan`,
`center`, `reveal`, `park`, `promote`, `anchor`, `shelves`, `undo`, `preset`,
`group_new`, `group_add`, `group_remove`, `group_cycle`, `group_rename`,
`group_join`, `set_primary`, `attach`, `detach`, `swap`, `orientation`, `tab`, `windows`,
`pan_direct`, `commands`, `layout_cycle`, `layout_set`, and `zoom`.

`left`, `right`, `up`, and `down` are accepted where the action uses a
direction. `next` maps to `1`; `prev` and `previous` map to `-1`. `park`
accepts left or right. `attach` accepts left, right, or down (bottom).
`cycle`, `region`, `tab`, `group_cycle`, and `layout_cycle` use left/up as
`-1` and right/down as `1`. Numeric arguments are rounded. Text arguments are
limited to 64 bytes. For Canvas, `move` and `resize` use `b` as the step size.
`pan_direct` uses `a` and `b` as unanimated pixel deltas. `layout_set` takes
the layout name as text and suppresses its toast when `a` is `1`.

In the tiled layouts `group_join` (a direction) puts the focused window in the
tab group of its neighbour that way, founding one if needed; a group holds 16
tabs. `group_remove` takes the focused window out again, and `tab` and
`group_cycle` step through the tabs of its bar. A group down to one window
dissolves; floating a window by hand or moving it to another workspace takes
it out.

See [Spatial window layouts](WINDOW-LAYOUTS.md) for action behavior and
examples.

### `zl.layout_context() -> table | nil`

Returns `{ layout, entry, placement, spatial, has_window }` for the focused
workspace. `has_window` says whether an eligible window is focused.

### `zl.layout_info() -> json`

Returns a JSON snapshot of the focused workspace, bounded to 96 KiB.

### `zl.set_reduced_motion(enabled)`

Makes spatial camera, travel, and scale changes immediate when enabled.

## Window and compositor actions

These functions return `true` when the requested action was applied and
`false` when no eligible target or live host exists:

| Function | Action |
| --- | --- |
| `zl.toggle_floating()` | Toggle focused window floating state. It floats at the size it last floated at, or else at the size its client opened with. |
| `zl.toggle_split()` | In Dwindle, flip the split holding the focused window between side by side and top/bottom. The flipped axis stays when the layout changes shape. False outside Dwindle or for a window alone on its workspace. |
| `zl.toggle_overview()` | Toggle native overview. |
| `zl.close_window()` | Ask focused window to close. |
| `zl.toggle_fullscreen()` | Toggle focused window fullscreen state. |
| `zl.toggle_pin()` | Toggle focused window pin state. |
| `zl.begin_move()` | Start an interactive pointer move. In Dwindle, Master, Grid, Spiral and Scrolling a tile stays in the layout, see-through under the pointer, and a highlight shows where it lands: dropped on the middle of another tile the two trade places; nearer an edge it goes in beside that tile on that side (between the columns in Scrolling); dropped on another monitor it joins that layout the same way. A titlebar drag does the same. Hold Alt to float the tile out instead. Esc puts it back. |
| `zl.begin_resize()` | Start an interactive pointer resize. |
| `zl.focus_direction(direction)` | Focus in `left`, `right`, `up`, or `down`. |
| `zl.move_window_direction(direction)` | Move in `left`, `right`, `up`, or `down`. |
| `zl.focus_monitor(direction)` | Focus output in `left`, `right`, `up`, or `down`. |
| `zl.move_column(direction)` | In Scrolling, swap the focused column with its neighbour along the strip: `left` or `up` toward the start, `right` or `down` toward the end. Its width goes with it, and focus and the view follow it. |
| `zl.move_column_to_monitor(output)` | Move the focused column to the output in `left`, `right`, `up`, or `down`, or to the output named `output` (such as `DP-1`). It lands on that output's active workspace right of the column focused there, focused, with the view following it; on a workspace that is not Scrolling the window just moves there. |
| `zl.cycle_column_width([step])` | In Scrolling, step the focused column's width (height on a vertical strip) to the next (`next`, the default) or previous (`previous`) of the `zl.set_scrolling` width presets, wrapping round at either end. Each column keeps its own width. |
| `zl.move_floating(dx, dy)` | Move focused floating window by integer deltas. |
| `zl.resize_floating(dw, dh)` | Resize focused floating window by integer deltas. |
| `zl.resize_window(dw, dh)` | Resize focused floating or tiled window by integer deltas. |
| `zl.workspace(name)` | Activate a workspace. |
| `zl.toggle_special_workspace(name)` | Show or hide a special workspace. |
| `zl.workspace_on_monitor(monitor, workspace)` | Activate workspace on named output. |

For special workspaces, an empty name means `special`, a bare name becomes
`special:name`, and `special` or `special:name` is accepted unchanged.
`zl.workspace` delegates names in either prefixed form to the same toggle.

`zl.quit()` requests compositor shutdown and returns no value.

`zl.window_count() -> integer` returns the current window count.

`zl.set_output_size(width, height) -> boolean` changes the primary output size
when the backend permits it. Both arguments are integers.

`zl.move_window_workspace(name [, follow [, address]]) -> boolean` moves the
window at `address`, or the focused window when omitted. `address` must come
from `zl.get_windows`. `follow` defaults to `false`. A `special` or
`special:name` target moves the window onto that special workspace, creating it
hidden if needed; with `follow` it is shown. Moving to a regular workspace's
name takes a window off a special workspace.

`zl.exec_command(command) -> boolean` starts `/bin/sh -c command`. It returns
whether the process was started, not the command's eventual exit status. It
returns `false` for an empty command, a command over 4095 bytes, or a spawn
failure.

## Windows, monitors, and workspaces

### `zl.get_windows() -> array`

Returns one table per window with these fields (the control socket's
`clients` and `clients-json` commands report the same windows from outside
the config, with pid, output and geometry):

- `address`: opaque light-userdata accepted by `zl.move_window_workspace`
- `app_id`, `title`
- `tag`: the untranslated name a Wayland client gives the window through
  xdg-toplevel-tag, such as `main window` or `settings`; empty when unset
- `mapped`, `floating`, `fullscreen`, `pinned`, `gtk_modal`
- `workspace = { name, special }`
- `appmenu_service`, `appmenu_path`
- `gtk_application_id`, `gtk_app_menu_path`, `gtk_menubar_path`
- `gtk_window_object_path`, `gtk_application_object_path`
- `gtk_unique_bus_name`, `gtk_a11y_bus_name`, `gtk_a11y_object_path`

### Monitor queries

| Function | Return |
| --- | --- |
| `zl.monitor_count()` | Number of monitors. |
| `zl.monitor_info(index)` | `{ id, name, mirror, active_workspace = { name } }`, or `nil`; indexes are zero-based. |
| `zl.active_monitor_index()` | Zero-based index of the monitor with focus, or a negative value when unavailable. A monitor gets focus when keyboard focus lands on one of its windows or the pointer moves onto it, even if it has no windows. |
| `zl.monitor_at_cursor_index()` | Zero-based monitor index under pointer, or a negative value when unavailable. |

### Workspace queries and settings

`zl.workspace_info(name) -> table | nil` returns
`{ name, special, empty }`.

`zl.set_workspace_persistent(name, persistent [, monitor]) -> boolean` marks a
workspace persistent. Without `monitor`, the name must identify one workspace
or have been selected with `zl.workspace_on_monitor`.

`zl.set_workspace_gesture(enabled [, fingers])` configures workspace swipes.
`fingers` is `2..10`; when omitted, the current count is retained.

## Output, input, and presentation settings

### `zl.output_rule(options)`

Adds a rule for one output, named by its connector in `output` (for example
`DP-1`). An output name may have one rule. Every other field is optional, and
a field the rule leaves out keeps what the output has now: its current mode,
position, scale and transform, and for the presentation fields the global
value from `zl.set_presentation`. A per-output value always beats the global
one.

Output layout:

- `width`, `height`, `refresh`: all three or none. Width and height are
  integers in `1..16384`; refresh is `1..1000` Hz. A listed mode within 1 Hz
  is used, otherwise a custom mode.
- `x`, `y`: both or none, each in `-100000..100000`.
- `scale`: `0.01..8`.
- `transform`: `normal`, `90`, `180`, `270`, `flipped`, `flipped_90`,
  `flipped_180`, or `flipped_270`.
- `enabled`: boolean, default `true`. `false` turns the output off. When a
  reload drops that rule or no longer sets `enabled = false`, the output comes
  back on at its last placement. An output a client turned off through
  wlr-output-management stays off.
- `primary`: boolean, default `false`. Makes this the main output: it is
  listed first in `zoolanderctl monitors`, and X11 windows and popups that
  don't pick an output open on it. Otherwise the first output connected is
  primary. At most one rule may set it, and a disabled output cannot be
  primary.

Presentation, per output:

- `vrr`: `off`, `always`, `fullscreen`, `fullscreen_game`, or `0..3`.
- `hdr`: `off`, `auto`, or `always`.
- `bitdepth`: `8` or `10`. Left out, the output scans out 8 bits per channel
  in SDR and 10 while HDR is engaged. `10` also scans SDR out at 10 bits, on
  outputs that are not HDR-capable too, as long as the output can scan out 10
  bits: its connector's `max bpc` reaches 10, it renders on the GPU, and a
  10-bit buffer could be allocated. `8` forces 8 bits, so HDR never engages on
  that output, and `bitdepth = 8` with `hdr = "always"` is an error. On an
  output with no `max bpc` property, `8` is ignored. A depth the output cannot
  use logs a warning on each reload, and the driver's depth is used instead.
  Removing the setting hands the depth back to the driver on the next reload.
- `color_profile`: `srgb` (the default) or `edid`. A wide-gamut display shows
  the sRGB colour it is sent stretched over its whole gamut, oversaturated.
  `edid` maps SDR colour into the display's own primaries from its EDID
  instead: untagged content is treated as sRGB and colour-managed content is
  converted from what it declares, so colours look as they do on an sRGB
  display. Use it only with the display in its native or wide colour mode: in
  an sRGB picture mode the display already maps sRGB, and colours come out
  desaturated. Screenshots and screen recordings still read sRGB. An output whose
  EDID gives no primaries stays sRGB, and HDR ignores the setting. Direct
  scanout needs a colour conversion on such an output, so fullscreen windows
  are composited.
- `sdr_brightness` (`0.1..4`), `sdr_saturation` (`0..2`),
  `sdr_min_luminance` (`0..10` nits), `sdr_max_luminance` (`40..1000` nits),
  `sdr_eotf` (`srgb`, `gamma22` or `gamma24`): as in `zl.set_presentation`.
- `min_luminance` (`0..10` nits), `max_luminance` (`80..10000` nits),
  `max_avg_luminance` (`50..10000` nits): replace the display's EDID values.
  They become the target luminances reported to clients. `max_luminance` is
  also the tone-mapping peak, and the HDR metadata sent to the display uses
  `min_luminance` and `max_luminance` for the mastering range, `max_luminance`
  for MaxCLL, and `max_avg_luminance` for MaxFALL. This applies to the
  compositor's own metadata and to a fullscreen client's. Left out, the EDID
  values are used. For the tone-mapping peak, an EDID maximum of exactly 100
  nits (what an EDID without HDR static metadata reports) counts as unknown,
  and the peak is then 1000 nits.

A value out of range raises an error; it is never clamped.

### `zl.set_keyboard(options)`

Fields are `repeat_rate` (`0..1000`), `repeat_delay` (`0..5000` ms),
`numlock` (boolean), and XKB names `rules`, `model`, `layout`, `variant`, and
`options`. Each XKB name is at most 127 bytes. A name the config leaves out
comes from its `XKB_DEFAULT_*` variable, then from `XKBMODEL`, `XKBLAYOUT`,
`XKBVARIANT` and `XKBOPTIONS` in `/etc/default/keyboard`; the layout is `us`
when none of them names one. A variant from the environment or the file
counts only when the layout comes from the same place or a later one.

### `zl.set_pointer(options)`

Fields are `left_handed` (boolean), `accel_profile` (`adaptive` or `flat`),
`sensitivity` (`-1..1`), `follow_mouse` (`disabled`, `focus`, `click`,
`detached`, or `0..3`), and `rules_follow_pointer` (boolean, default `false`).
With `rules_follow_pointer`, a new window opens on the output under the
pointer instead of the focused one. A window rule's `workspace` that lives on
another output is taken to the same position among the pointer output's
workspaces, so a rule for workspace `3` opens on the third workspace of
whichever monitor the pointer is on. Special workspaces and names with no such
position still go to the named workspace.

Three fields apply to touchpads only. `tap_to_click` (boolean, default `false`)
makes a tap click: one finger is the left button, two the right, three the
middle. `natural_scroll` (boolean, default `false`) makes content follow the
fingers. Mouse wheels keep scrolling the usual way. `disable_while_typing`
(boolean, default `true`) ignores a built-in touchpad for a moment after each
key press. External touchpads don't support it.

### `zl.input_rule(options)`

Turns an input device off, or back on. Fields:

- `device` (required string, 1..127 bytes): the device's libinput name, exact,
  or `^(...)$` with `.*` as its only wildcard and `\` to escape.
- `enabled` (boolean, default `true`): `false` suspends the device. It sends no
  events, and the seat no longer counts it as a keyboard, pointer or touch
  device.

The last rule that matches a device decides, and a rule with the same `device`
as an earlier one replaces it. Rules apply to devices already plugged in and to
ones that appear later, and a reload that drops a rule turns its devices back
on. `zoolanderctl inputs` lists every device under the name rules match.

```lua
-- A game controller's touchpad that moves the desktop pointer.
zl.input_rule({ device = "^(.*DualSense.*Touchpad)$", enabled = false })
```

### `zl.set_floating(options)`

`raise_on_hover` (boolean, default `false`) brings a floating window to the
front of the floating windows once the pointer has stayed on it for
`raise_delay` ms (`0..2000`, default `100`). The delay starts when the pointer
enters the window, so crossing windows on the way elsewhere leaves their order
alone; `0` raises at once. Floating windows are those floated by hand, a rule
or their client, and every window on the `floating` layout and on Canvas,
Islands and Anchors (anchored windows excepted). Raising never moves keyboard
focus, whatever `follow_mouse` is, and leaves tiled windows alone. Nothing
rises while a button is held, a window is moved or resized, a drag is under
way, a popup grab or an exclusive layer-shell keyboard grab is active, or the
screen is locked or in the overview.

### `zl.set_presentation(options [, output])`

Without `output`, sets the global presentation. An output's own value in
`zl.output_rule` beats these. Boolean fields are `allow_tearing`, `immediate_fullscreen`,
`direct_scanout`, and `partial_damage`. `vrr` is `off` (default), `always`,
`fullscreen`, `fullscreen_game`, or `0..3`. `fullscreen` turns VRR on while one
window covers the output. `fullscreen_game` does that only while the window
says it is a game through its content type; video is left at the fixed rate.
The configured mode decides VRR, even over a change from a
wlr-output-management client. `hdr` is `off`, `auto`
(default), or `always`.

These fields control how SDR content looks on an output while it is in HDR:

- `sdr_eotf`: `srgb`, `gamma22`, or `gamma24` (default). How untagged SDR
  content is decoded.
- `sdr_min_luminance`: `0..10` nits, default `0`. The luminance of SDR black.
- `sdr_max_luminance`: `40..1000` nits, default `100`. The luminance of SDR
  white.
- `sdr_brightness`: `0.1..4`, default `1`.
- `sdr_saturation`: `0..2`, default `1`.

The maths: a decoded SDR value `v` becomes
`sdr_min_luminance + (sdr_max_luminance - sdr_min_luminance) * eotf(v)` nits,
so SDR white maps to `sdr_max_luminance`. Saturation is then applied around
the target luma, and brightness multiplies the result. Both work in linear
light. A source tagged with its own colour description keeps its own white,
and only the black lift applies to it. The defaults reproduce BT.1886
(gamma 2.4) with white at 100 nits and no black lift. Screen captures of an
HDR output are converted to SDR by undoing this mapping. They use the same
`sdr_eotf`, map `sdr_max_luminance * sdr_brightness` to white, and remove the
black lift, so desktop pixels round-trip. Brighter HDR highlights clip at
white.

`output` names one monitor by connector (for example `DP-1`), or is
`"focused"` for the monitor with focus when the call runs. The fields then
apply to that monitor alone, over its `zl.output_rule` and the global values.
They are the presentation fields `zl.output_rule` takes: `vrr`, `hdr`,
`bitdepth`, `color_profile`, the `sdr_*` fields, `min_luminance`, `max_luminance` and
`max_avg_luminance`, with the same values. A field the call leaves out keeps
what the monitor has now, and a later call for the same monitor changes only
the fields it gives. The boolean fields apply to every output and raise with an
`output`; without one, `bitdepth`, `color_profile` and the three display luminances are ignored
with an unknown-key warning. A
call that would leave the monitor at `bitdepth = 8` with `hdr = "always"`
raises, as does `"focused"` while no monitor has focus.

Either form takes effect at once, from a binding as at top level: HDR engages
or disengages on the next frame, with whatever modeset the display needs, and
VRR, the SDR mapping and the luminance targets change with it.

What a call with `output` sets lasts until the config reloads; the reload
gives every monitor back the presentation its config gives it, as it does for
the global form. It is kept by connector name, so a monitor that is unplugged
and plugged back in keeps it, as it would keep its `zl.output_rule`.
`zoolanderctl monitors-json` reports the values a monitor runs with, these
included, in each setting's `value`.

### `zl.presentation([output]) -> table`

The presentation in force: the global one without `output`, or what that
monitor runs with, `output` being a connector name or `"focused"` as for
`zl.set_presentation`. The table has the boolean fields, `vrr`, `hdr` and
`sdr_eotf` as names, and the `sdr_*` numbers. For a monitor it also has
`bitdepth`, `min_luminance`, `max_luminance` and `max_avg_luminance` when its
rule or a call set them; left out, the driver picks the depth and the EDID
gives the luminances.

A binding that flips HDR on the monitor with focus:

```lua
zl.bind(zl.MOD_LOGO + zl.MOD_SHIFT, 'h', function()
    local p = zl.presentation("focused")
    zl.set_presentation({ hdr = p.hdr == "off" and "always" or "off" }, "focused")
end, { description = "Toggle HDR on this monitor" })
```

### `zl.toggle_hdr([output]) -> boolean`

Flips HDR on one monitor: `output` is a connector name or `"focused"`, the
default. When HDR is engaged on that monitor now, it sets its `hdr` to `off`;
otherwise to `always`. Engaged means the monitor scans out HDR, as
`zoolanderctl monitors-json` reports in `hdr.enabled`, so a monitor on `auto`
showing a fullscreen HDR video turns off, unlike the binding above, which reads
the mode. It returns `true` when it asked for HDR and `false` when it turned it
off. It is `zl.set_presentation({ hdr = ... }, output)`, with that call's
errors and lifetime: it raises for `"focused"` while no monitor has focus and
for a monitor held at `bitdepth = 8`, and a reload gives the monitor back its
configured `hdr`. A monitor that cannot show HDR is set to `always` each time.

```lua
zl.bind(zl.MOD_LOGO + zl.MOD_SHIFT, 'h', function() zl.toggle_hdr() end, { description = "Toggle HDR on this monitor" })
```

### `zl.set_hdr(mode [, output])`

Sets `hdr` on one monitor to `mode`, `off`, `auto` or `always`, as
`zl.set_presentation({ hdr = mode }, output)` does, `output` defaulting to
`"focused"`. It returns nothing.

### `zl.set_xwayland(options)`

`enabled` and `force_zero_scaling` are boolean. `enabled` defaults to `true`;
`false` gives the X display up: no X socket listens, children get no `DISPLAY`
or `XAUTHORITY`, and a running Xwayland is stopped. Setting it back to `true`
listens again, and the next X11 client starts Xwayland. Xwayland is optional at
runtime; the settings are retained even when Xwayland is unavailable.

### `zl.set_overview(options)`

`axis` is `vertical` or `horizontal`; `rail` is `bottom` or `top`. `scale`
(`0.2..1.25`, default `1`) sizes the workspace cards against their default
share of the screen; below `1` more of the neighbouring workspaces shows. At
`1` a card takes 72% of the room along the strip on either axis, so its
neighbours peek in past both ends.
`gap` (`0..512` pixels) is the space between neighbouring cards; unset, it
follows the output's height (a fortieth of it, at least 12). A small `scale`
with a small `gap` puts several workspaces on screen at once:

```lua
zl.set_overview({ scale = 0.35, gap = 8 })
```

`visible_windows` (`0..32`, default `0`) is how many windows a card is zoomed
to show when its windows reach past the screen, as a Scrolling strip or a
spatial desk does. `0` fits every window in the card, which shrinks it as
windows are added. With a number, the card is zoomed to that many windows'
share of the content (never closer than the screen itself) and the rest lie
past its edge. Where the card scrolls across the strip, those windows show on
past both ends of the card to the screen's edges and take clicks there; where
it scrolls along the strip, the neighbouring cards lie there and the windows
stay inside the card. Content that fits the screen, as tiled layouts do, is
never cropped. The card scrolls along the direction its content overflows: over it,
Super with the wheel or touchpad, or a sideways scroll while the cards stack
vertically, glides the crop a window's share per notch, and a touchpad moves
it under the fingers. A plain wheel still moves the strip, and over a card
that shows all its windows Super with the wheel does too. A card rests
centred on what the screen shows, and selecting a workspace, by keyboard,
wheel or click, scrolls its card to the focused window. Each card keeps its
scroll until the overview closes.

In the overview the mouse wheel glides the workspace strip a card per notch (a
fraction of one per high-resolution step) and a touchpad drags it under the
fingers, coasting to a card on release. A window dragged there shrinks under
the pointer and outlines the workspace it would land on and, inside it, the
slot it takes: the half of the tile under the pointer it splits off (Dwindle),
its place before or after that tile (Master, Grid, Spiral, Scrolling), or its
own rect at the pointer (Floating, or a floating window). It lands exactly
there. A window held by a
`zl.begin_move()` bind carries into an overview opened mid-drag (a hot corner's
plain bind fires even with the move bind's modifier still held) and drops onto
a workspace there.

## Window appearance

All color fields accept `#RGB`, `#RGBA`, `#RRGGBB`, or `#RRGGBBAA`, with
optional underscores between hex digits.

### `zl.set_window_style(options)`

Fields:

- `gaps_in`, `gaps_out`: `0..256`
- `border_size`: `0..64`
- `active_border`, `active_border_end`, `inactive_border`,
  `inactive_border_end`: colors
- `active_border_angle`, `inactive_border_angle`: `-360..360`
- `rounding`: `0..128`; `rounding_power`: `2..10`
- `active_opacity`, `inactive_opacity`, `fullscreen_opacity`: `0..1`
- `shadow`: table with `enabled`; `range` (`0..256`); `sharp` (`0..1`);
  `render_power` (`1..8`); `offset_x`, `offset_y` (`-256..256`); `scale`
  (`0.5..2`); and color fields `color`, `color_inactive`

Explicit border fields here take precedence over theme and `zl.set_ssd`
border values.

### `zl.set_ssd(enabled_or_options)`

A boolean enables or disables server-side decorations. A table accepts:

- booleans `enabled`, `floating_workspaces_only`,
  `include_floating_windows`, `follow_theme`, `show_title`
- `border` (`0..64`), `titlebar` (`0..128`)
- border colors and angles with the same names and limits as
  `zl.set_window_style`, plus `active_titlebar`, `inactive_titlebar`,
  `title_color`, and `inactive_title_color` (titles of unfocused windows;
  follows `title_color` when only that is given)
- `title_font` (at most 127 bytes), `title_font_size` (`1..128`), and
  `title_align` (`left`, `center`, or `right`). `title_font` names one or
  more comma-separated families followed by optional style words, as in
  `"Inter, sans-serif Semi-Bold Italic"`. Characters the font lacks come
  from whichever installed font fontconfig finds for them, in the same
  weight and slant.
- `buttons`: up to eight tables with `action` (`close`, `minimize`,
  `maximize`, or `fullscreen`), `side` (`left` or `right`), `width`
  (`1..128`), and `color`

### `zl.set_blur(options)`

With `enabled`, every translucent window surface is blurred behind, window
roots included; a window drawn below full opacity counts as translucent.
A surface that asks for blur through `ext-background-effect-v1` gets only
its own region, whether `enabled` is set or not.
When DRM renders in software, nothing is blurred, and blur, animations and
shadows stay off whatever is set here.

Boolean fields are `enabled`, `ignore_opacity`, `popups`, and
`input_methods`. `size` is `1..40`; `passes` is `1..8`;
`popups_ignorealpha`, `input_methods_ignorealpha`, `noise`, `vibrancy`, and
`vibrancy_darkness` are `0..1`; `contrast` and `brightness` are `0..2`.
`contrast` bends the blurred backdrop along an S-curve around mid-grey, as
Hyprland's does: above 1 darks get darker and lights lighter without
clipping to black or white, below 1 both move towards grey.

`resolution` is `quarter` (the default), `half`, or `full`: the size of the
first blur level against the output. The blur spreads as far at each, but
lower resolutions keep smaller scratch images in GPU memory (at 4K, about
4 MiB at `quarter`, 16 MiB at `half`, 64 MiB at `full`) and read fewer
pixels, at some loss of smoothness. The software renderer ignores it.

### `zl.set_dim(options)`

`inactive` is boolean. `strength`, `special`, and `around` are `0..1`.

## Animations

### `zl.set_animations(options)`

Sets the common animation baseline. `enabled` is boolean, `duration` is
`1..5000` ms, and `easing` is `linear`, `ease_out_cubic`, or
`ease_in_out_cubic`. This updates the six classic animation leaves while
preserving camera, layout, minimize, and reduced-motion settings. Put this call before
per-leaf overrides.

`zl.set_animations_enabled(enabled)` changes only the global enable flag.
When DRM renders in software, animations stay off whatever it is set to.

### `zl.set_animation_leaf(leaf, options)`

Leaves are `windows_in`, `windows_out`, `windows_move`, `fade`, `layers`,
`workspaces`, `camera`, `layout`, and `windows_minimize`. Each call defaults
omitted `enabled` to `true`, `duration` to 180 ms, `style` to `slide`
(`minimize` for `windows_minimize`), and `percent` to 20; these fields do not
retain their previous values. `duration` accepts `1..5000` ms.

`easing` accepts the three common easing names. A `curve` table with `x1`,
`y1`, `x2`, and `y2` takes precedence over `easing`. `x1` and `x2` are
`0..1`. `y1` and `y2` are `-1..2`, so a curve can overshoot its target and
settle back, as in `{ x1 = 0.34, y1 = 1.56, x2 = 0.64, y2 = 1 }`. Positions
and sizes follow the overshoot. Fades and other opacities stay within fully
transparent and fully opaque. Missing
points in a supplied curve default to `0, 0, 1, 1`. When neither `curve` nor
`easing` is supplied, the current curve is retained.

`style` also accepts `popin`, `fade`, `minimize`, `slide left`, `slide right`,
`slide top`, or `slide bottom`; underscore forms are accepted for directional
slides. `percent` is `1..100` and is read only when a style is supplied.

`windows_minimize` animates a window minimizing and coming back, whether by a
taskbar, a bind, or activation. Until `zl.set_animation_leaf` sets it, it is
enabled, 250 ms, `ease_out_cubic`, style `minimize`, and `zl.set_animations`
leaves it alone. With `minimize` the window shrinks into the rectangle a
taskbar gave its entry (`zwlr_foreign_toplevel_handle_v1.set_rectangle`),
keeping its shape, while fading out, and grows back out of it when restored.
Without such a rectangle it shrinks to `percent` of its size about its centre,
like `popin`. `popin` and `fade` fade as they go; slides move the window off the
output whole. The window leaves the layout and focus at once; only the drawing
animates. With reduced motion it only fades, and a `no_animation` rule or the
global switch turns it off.

For `workspaces`, `slide` (the default) moves the outgoing and incoming
workspaces across together without fading them; `slide top` and
`slide bottom` do the same vertically; `fade` cross-fades them in place. The
`fade` leaf does not apply to workspace switches.

## Rules

Window and layer rule patterns are exact strings or anchored forms `^(...)$`.
Inside an anchored form, `.*` is the only wildcard and `\` escapes the next
character. Other regular-expression syntax is rejected. Patterns and names
are at most 127 bytes unless stated otherwise.

### `zl.add_window_rule(match, pattern, actions) -> true`

`match` is `app_id`, `title` or `tag` (see `zl.get_windows`). Rules run
again when any of them changes. `actions` is a table with:

- booleans `float`, `dim_around`, `no_animation`, `idle_inhibit`,
  `fullscreen`, `no_minimize`
- `content`: `none`, `photo`, `video`, or `game`
- `border_size`: `0..64`; `rounding`: `0..128`
- boolean overrides `shadow`, `decorate`, `follow`
- boolean `confine_cursor`
- `force_game_hdr`: boolean, see below
- `workspace`: workspace name, `1..127` bytes. `special` or `special:name`
  opens the window on that special workspace, which is created hidden if
  needed. With `follow` it is shown at once; otherwise it stays hidden until
  `zl.toggle_special_workspace` shows it.

A window floated by a rule opens at the size its client picked, kept within
the work area and its own minimum and maximum size.

`no_minimize` keeps the window from being minimized, for games that minimize
themselves when they lose focus. The window's own requests are refused
(`xdg_toplevel.set_minimized`, X11 `WM_CHANGE_STATE`, mapping hidden), as are
taskbars and the titlebar, which loses its minimize button; clients are told
through `xdg_toplevel.wm_capabilities` and `_NET_WM_ALLOWED_ACTIONS`. A window
that is minimized when the rule first matches it comes back, without taking
focus from another window.

`confine_cursor` keeps the pointer inside the window's visible content while
the window has keyboard focus, for games that let the cursor drift onto
another monitor. Relative and absolute motion, warps and output changes all
stay inside it. It lets go while focus is elsewhere and while the overview, the
command sheet, the layout picker or a move or resize is active, and it pulls
the pointer back in when the window is focused again. A client's own
`zwp_pointer_constraints_v1` lock or confinement still decides where the
pointer goes inside the window, but cannot take it out of the window.
`zoolanderctl clients` shows, per window, whether the rule is on and which
constraint the client holds.

```lua
zl.add_window_rule('app_id', [[^(steam_app_.*)$]], { confine_cursor = true })
```

The compatibility form is
`zl.add_window_rule(match, pattern, float, dim_around, no_animation,
idle_inhibit, fullscreen, content, border_size, rounding, shadow, decorate,
workspace, follow, confine_cursor, force_game_hdr, no_minimize)`. Every
matching window
rule contributes actions; later matches replace single-value actions, while
boolean actions accumulate.

#### `force_game_hdr`

**Proton games also need `DXVK_HDR=1` in their launch options**
(`DXVK_HDR=1 %command%` in Steam, or `PROTON_ENABLE_HDR=1` with GE-Proton).
DXVK offers HDR to the game from that variable alone, and its Windows side reads
the environment Wine copied when the process started. Zoolander's Vulkan layer
cannot change that copy. It does set `DXVK_HDR=1` for a matched game when the
game creates its Vulkan instance, but only Unix-side readers see it: native
DXVK builds and Proton's own X11 display code.

A matched window is told its output is in HDR mode while the output scans out
SDR, either because it cannot do HDR or because its `hdr` is `off`. This is
gamescope's `--hdr-debug-force-support`, for one window at a time. Games then
take their HDR path, and Zoolander converts their PQ back to the SDR the output
scans. On an output that is in HDR mode the rule changes nothing.

```lua
zl.add_window_rule("app_id", "^(steam_app_.*)$", { force_game_hdr = true })
```

The window's preferred image description, through `wp_color_manager_v1` and
`frog_color_management_v1`, becomes the one the output would have in HDR mode:
PQ with BT.2020 primaries, the output's EDID primaries as the target when it
has them, and the output's `max_luminance` as the target peak, else the EDID's
HDR peak, else 1000 nits. Change that peak with the output's `max_luminance`
setting.

X11 games, which covers Proton under Xwayland, get HDR through Zoolander's
Vulkan layer, `VK_LAYER_ZOOLANDER_wsi`. It loads into Vulkan programs Zoolander
starts and does nothing unless this rule matches the window; an output in HDR
mode alone does not change how an X11 game presents. For a matched window:

- the window's X11 Vulkan surface offers Mesa's Wayland formats, HDR10 (PQ,
  BT.2020) among them;
- its swapchain presents through a Wayland surface over the X11 window, in the
  same place, with input left to the X11 window;
- the game's colour space and `vkSetHdrMetadataEXT` metadata reach the
  compositor as on Wayland.

The layer follows gamescope's WSI layer, Wine quirks included. If the rule
starts or stops matching while the game runs, the layer asks the game for a new
swapchain. See `docs/PROTOCOLS.md` for the protocol behind it.

Before the game has a window, the layer checks the rule against the app_id
the window will most likely get: Proton's `steam_app_<SteamGameId or
SteamAppId>`, else the executable's name. The title it uses is the Vulkan
application name. Write the rule against `app_id` (as above) for this check to
match.

Limitations:

- The output still shows SDR. PQ keeps its absolute luminance, 100 nits being
  SDR white, and everything brighter than 75 nits is rolled off into the last
  quarter of the range. Games that put paper white at 200 nits or more look
  flat; set the game's paper white or brightness to about 100 nits.
- Native Wayland Vulkan through Mesa already gets the HDR10 swapchain formats
  on any output, because Mesa lists them from what the compositor supports,
  not from the output. The layer leaves Wayland surfaces alone. The rule
  changes what toolkits that read the preferred description decide, such as
  SDL3's `SDL_PROP_WINDOW_HDR_ENABLED_BOOLEAN`.
- The layer is built for 64-bit programs only, so 32-bit games stay on X11.

##### Opting out of the Vulkan layer

Zoolander gives every program it starts `ZOOLANDER_WSI=1`, and the Vulkan
loader enables the layer only where that is set. Programs that never inherit
it, such as those started outside the session, never load it. To keep it out:

- of one game: add `ZOOLANDER_WSI_DISABLE=1 %command%` to its launch options;
  any value disables it;
- of everything: `zl.set_env("ZOOLANDER_WSI_DISABLE", "1")` in your config, or
  `VK_LOADER_LAYERS_DISABLE=VK_LAYER_ZOOLANDER_wsi`.

##### When a game still offers no HDR

`ZOOLANDER_WSI_DEBUG` makes the layer log what it decides: whether it loaded
or passed through, whether the compositor offers the bypass, each X11 window
and the mode Zoolander sent for it, the formats it exposed and whether a
swapchain went to the bypass surface. Set it to `1` for stderr, or to an
absolute path to append there, which works from Steam. In the game's launch
options:

```
ZOOLANDER_WSI_DEBUG=/tmp/zoolander-wsi.log VK_LOADER_DEBUG=layer %command% 2>/tmp/vk-loader.log
```

`/tmp/zoolander-wsi.log` then has lines such as
`X window 0x2600003: 9 formats from the Wayland surface, HDR10 offered`.
`/tmp/vk-loader.log` shows whether the loader found `VK_LAYER_ZOOLANDER_wsi`
at all. Inside Steam's runtime container that needs the layer under
`/overrides/share/vulkan/implicit_layer.d`. No zoolander-wsi lines at all
means the layer was not loaded.

The rule must match the window's class as Zoolander reports it
(`zoolanderctl clients` lists the app_id), whether or not the window has
mapped yet.

### Layer rules

`zl.add_layer_blur_rule(namespace, ignore_alpha)` enables blur and sets an
ignore-alpha threshold in `0..1`.

`zl.add_layer_no_animation_rule(namespace)` disables animation.

`zl.add_layer_animation_rule(namespace, style)` selects any animation style
accepted by `zl.set_animation_leaf`.

Calls with the same namespace pattern merge into the first record. Later
matching patterns determine blur thresholds and animation styles.
`no_animation` applies when any matching rule enables it.

## Bell, render GPU and environment

`zl.set_bell_sound(value) -> boolean` picks the Otter cue the bell plays:
`chime`, `sparkle`, `droplet`, `bloom`, `whisper`, `tick`, `press`,
`release`, `toggle`, `success`, `error`, `page`, `loading`, `ready`,
`pulse`, `scan` or `arrival`. `"default"` restores `error`, and `"none"` or
an empty string silences the bell. Any other value, a sound file included,
returns `false` and leaves the setting as it was.

`zl.set_render_gpu(value) -> boolean` picks the GPU that draws the desktop on
a machine whose built-in screen is on one GPU while it has another: `"auto"`
(the default) renders on the GPU the displays are on, which on a laptop is the
one behind the built-in screen; `"integrated"` always renders there;
`"discrete"` renders on the other GPU, which has its own cooling and draws
more power. The other GPU's screens are driven either way. The renderer is
created before the config loads, so the value is saved under
`$XDG_STATE_HOME/zoolander/render-gpu` and applies from the next start. It
changes nothing on a machine with one GPU or without a built-in screen, and an
explicit `--drm=DEVICE` overrides it. A GPU that drives no connector is never
picked, so on a laptop whose discrete GPU has no display ports of its own
`"discrete"` changes nothing; `zoolander --drm-list` shows the candidates. Any other value returns `false` and
leaves the setting as it was.

`zl.set_env(name, value) -> boolean` sets an environment variable for clients
spawned later. `XCURSOR_THEME`, `XCURSOR_SIZE`, and `XCURSOR_PATH` also update
compositor cursor lookup. It does not modify the parent shell. Names must be
1..127 bytes and contain neither `=` nor NUL; `name=value` must fit in 511
bytes. The call returns `false` for invalid input or when the 32-entry table is
full. A repeated name replaces its value.
