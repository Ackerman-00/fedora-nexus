# Comparing client protocol traces

A trace diff compares one real Wayland client's requests and events under
Zoolander with the same client under another compositor. It is useful when a
client fails without a protocol error, or when server behavior is legal on
the wire but differs in ordering, version handling, or event reachability.

Run this workflow only in the project VM. Do not start a control compositor,
inject input, or open DRM devices on the host. The commands below use a
software VM and keep each compositor in a private runtime directory.

## Prepare the VM

From the `zoo` workspace root:

```sh
VM=trace VM_GPU=software ./vm/vmctl.sh up
VM=trace ./vm/vmctl.sh copy-in zooland /home/zoo/trace/zooland
VM=trace ./vm/vmctl.sh copy-in zoolander /home/zoo/trace/zoolander
VM=trace ./vm/vmctl.sh ssh
```

Inside the guest, build as described in the [README](../README.md#build).
The guest needs otr 0.2.2 or newer:

```sh
cd /home/zoo/trace/zoolander
./vendor/fetch-luajit.sh
mkdir -p otr-out && cd otr-out
otr build ../otr/native_main.otr --release --cpu baseline \
    -rpath '$ORIGIN/../lib/zoolander' -o zoolander
```

Use a dedicated directory for one comparison. `XDG_RUNTIME_DIR` must be owned
by the guest user and have mode 0700:

```sh
work=$(mktemp -d /tmp/zl-trace.XXXXXX)
ours_runtime=$work/ours-runtime
control_runtime=$work/control-runtime
mkdir "$ours_runtime" "$control_runtime"
chmod 700 "$ours_runtime" "$control_runtime"
```

Keep the shell open until cleanup so it retains the exact PIDs it starts.

## Choose a fair control

Choose a compositor that implements the protocol and version being checked.
KWin, Weston, or another mature compositor may be suitable, but availability
alone is not enough. Record:

- compositor name and version
- startup command
- advertised interface and version relevant to the comparison
- any missing extension that makes the control unsuitable

Do not substitute a different control after seeing the result without
recording why. A missing protocol is an invalid comparison, not evidence that
Zoolander is correct.

## Start isolated compositors

Use an empty config for Zoolander. Unset inherited display variables before
starting either compositor:

```sh
: > "$work/empty.lua"
env -u DISPLAY -u WAYLAND_DISPLAY -u XAUTHORITY \
    XDG_RUNTIME_DIR="$ours_runtime" \
    /home/zoo/trace/zoolander/otr-out/zoolander \
    --headless --headless-size=1280x720 --config="$work/empty.lua" \
    >"$work/ours-server.log" 2>&1 &
ours_pid=$!
```

Wait with a bounded predicate for Zoolander's socket to appear. Use the socket
name printed in `ours-server.log`; do not assume `wayland-0`.

Start the control in `control_runtime` with its documented headless or virtual
backend and redirect its log to `$work/control-server.log`. Record its PID and
socket name in `control_socket`. Keep any backend-specific flags in the run
notes rather than copying an old command blindly.

If the behavior needs linux-dmabuf or real KMS, the headless backend is not a
valid test. Stop and schedule the applicable root-owned VM device gate. Do not
change this procedure to open a host render or card node.

## Capture the same client twice

Set a bounded command once and run the same executable, arguments, config, and
input sequence against both sockets:

```sh
client_cmd='<client and fixed arguments>'

env -u DISPLAY -u XAUTHORITY \
    XDG_RUNTIME_DIR="$ours_runtime" WAYLAND_DISPLAY="$ours_socket" \
    WAYLAND_DEBUG=1 timeout 10s sh -c "$client_cmd" \
    >"$work/ours-client.log" 2>&1
ours_status=$?

env -u DISPLAY -u XAUTHORITY \
    XDG_RUNTIME_DIR="$control_runtime" WAYLAND_DISPLAY="$control_socket" \
    WAYLAND_DEBUG=1 timeout 10s sh -c "$client_cmd" \
    >"$work/control-client.log" 2>&1
control_status=$?
```

The shell form is deliberate only when `client_cmd` is a recorded trusted
test command. For a single executable, invoke it directly. Record both exit
statuses, including `124` from `timeout`. A trace is not clean merely because
the client tolerated a timeout or exited zero.

Use a deterministic input script when behavior needs interaction. Keep it in
the VM, target only the test compositor, and stop every helper by its captured
PID. Input tests remain VM-only.

## Compare the wire behavior

First extract request and event names to locate likely differences. Preserve
the original logs because this normalization loses object identity, payloads,
and ordering:

```sh
for side in ours control; do
    grep -oE '(-> )?[a-z_]+#?[0-9]*\.[a-z_]+\(' \
        "$work/$side-client.log" |
        sed 's/#[0-9]*//' |
        sort -u >"$work/$side-events.txt"
done
diff -u "$work/control-events.txt" "$work/ours-events.txt" || true
```

Read surrounding lines in both raw traces for the first semantic divergence.
Check these separately:

- whether an event is present
- negotiated object version
- request and event ordering
- payload values, including output identity, geometry, scale, and serials
- lifecycle around configure, acknowledge, commit, enter, leave, and destroy
- client exit, visible behavior, and server diagnostics

A sorted name diff cannot prove ordering or matching object identity.

## Classify and record the result

For each client and protocol, record one of:

- Zoolander divergence with visible client impact
- Zoolander divergence tolerated by this client
- same root cause as an already recorded divergence
- invalid comparison because the control lacks required support
- client-side failure unrelated to either compositor
- no divergence found in the exercised path

Include exact trace excerpts around the first divergence, both compositor
versions, both exit statuses, and the client command. State the limits of the
exercise. A clean run covers only the client path and protocol versions that
were reached.

Collect a planned multi-client sweep before changing source. That keeps later
results comparable and prevents the first defect from ending the survey.
After a fix, add the smallest deterministic regression at the owning layer,
then repeat only the affected trace pair.

## Cleanup

Stop tracked processes, escalate only if bounded waits fail, and remove the
private runtime directory:

```sh
kill "$ours_pid" "$control_pid" 2>/dev/null || true
for pid in "$ours_pid" "$control_pid"; do
    timeout 5s tail --pid="$pid" -f /dev/null 2>/dev/null || \
        kill -KILL "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
done
rm -rf "$work"
exit
```

Back on the host, shut down the named VM:

```sh
VM=trace ./vm/vmctl.sh down
```

Keep trace logs only when they are needed as review evidence, and remove client
data that is unrelated to the protocol under review.
